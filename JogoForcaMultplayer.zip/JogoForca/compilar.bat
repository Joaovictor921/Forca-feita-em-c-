@echo off
g++ jogo_forca_multiplayer.cpp -std=c++11 -O2 -o forca.exe -lws2_32
pause
