/*
    JOGO DA FORCA MULTIPLAYER
    Baseado no jogo da forca original de Joao Victor Dalbem e Guilherme Duque.

    Modo:
      - 1 servidor + 1 cliente
      - Pode funcionar em dois terminais no mesmo PC (127.0.0.1)
      - Pode funcionar em dois PCs na mesma rede (LAN)
      - O SERVIDOR guarda o estado compartilhado:
          palavra secreta, letras usadas, erros, pontuacao e turno.
      - Cada time joga UMA letra por turno.

    Compilacao:
      Windows (MinGW):
        g++ jogo_forca_multiplayer.cpp -std=c++17 -O2 -o forca.exe -lws2_32

      Linux:
        g++ jogo_forca_multiplayer.cpp -std=c++17 -O2 -o forca

    Como jogar em dois PCs:
      PC 1:
        forca.exe
        escolha 1 - Servidor

      PC 2:
        forca.exe
        escolha 2 - Cliente
        informe o IP do PC 1.

    Para testar no mesmo PC:
      abra dois terminais e use 127.0.0.1 no cliente.
*/

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <random>
#include <cctype>
#include <cstring>
#include <sstream>
#include <limits>
#include <chrono>

#ifdef _WIN32
    #define NOMINMAX
    #include <winsock2.h>
    #include <ws2tcpip.h>
    #pragma comment(lib, "ws2_32.lib")
    using socket_t = SOCKET;
    const socket_t INVALID_SOCKET_VALUE = INVALID_SOCKET;
#else
    #include <sys/types.h>
    #include <sys/socket.h>
    #include <arpa/inet.h>
    #include <netinet/in.h>
    #include <unistd.h>
    using socket_t = int;
    const socket_t INVALID_SOCKET_VALUE = -1;
#endif

using namespace std;

constexpr int PORTA = 54000;
constexpr int MAX_TENTATIVAS = 8;
constexpr int TAMANHO_MAX = 100;
constexpr int MAX_NOME = 49;

#ifdef _WIN32
void fecharSocket(socket_t s) {
    if (s != INVALID_SOCKET) closesocket(s);
}
#else
void fecharSocket(socket_t s) {
    if (s >= 0) close(s);
}
#endif

void limparTela() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

void inicializarSockets() {
#ifdef _WIN32
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        cerr << "Erro ao iniciar Winsock.\n";
        exit(1);
    }
#endif
}

void finalizarSockets() {
#ifdef _WIN32
    WSACleanup();
#endif
}

bool enviarTudo(socket_t s, const string& texto) {
    size_t enviado = 0;
    while (enviado < texto.size()) {
#ifdef _WIN32
        int n = send(s, texto.c_str() + enviado,
                     static_cast<int>(texto.size() - enviado), 0);
#else
        ssize_t n = send(s, texto.c_str() + enviado,
                         texto.size() - enviado, 0);
#endif
        if (n <= 0) return false;
        enviado += static_cast<size_t>(n);
    }
    return true;
}

// Todas as mensagens terminam com '\n'.
// Isso deixa o protocolo simples e funciona tanto no Windows quanto no Linux.
bool enviarLinha(socket_t s, const string& linha) {
    return enviarTudo(s, linha + "\n");
}

bool receberLinha(socket_t s, string& linha) {
    linha.clear();
    char c;

    while (true) {
#ifdef _WIN32
        int n = recv(s, &c, 1, 0);
#else
        ssize_t n = recv(s, &c, 1, 0);
#endif
        if (n <= 0) return false;

        if (c == '\n') break;
        if (c != '\r') linha += c;

        if (linha.size() > 4096) return false;
    }

    return true;
}

string normalizar(const string& entrada) {
    string s;

    for (unsigned char c : entrada) {
        // O jogo usa palavras sem acentos para evitar problemas de
        // codificacao no terminal e na comunicacao entre PCs.
        if (isalnum(c)) {
            s += static_cast<char>(tolower(c));
        }
    }

    return s;
}

string mascararPalavra(const string& palavra, const string& usadas) {
    string resultado;

    for (char c : palavra) {
        if (usadas.find(c) != string::npos)
            resultado += c;
        else
            resultado += '_';

        resultado += ' ';
    }

    return resultado;
}

bool contem(const string& texto, char c) {
    return texto.find(c) != string::npos;
}

string lerNome(const string& mensagem) {
    string nome;
    cout << mensagem;
    getline(cin, nome);

    if (nome.empty()) nome = "Jogador";

    if (nome.size() > MAX_NOME)
        nome.resize(MAX_NOME);

    for (char& c : nome) {
        if (c == '|') c = '_';
    }

    return nome;
}

char lerLetraLocal() {
    while (true) {
        cout << "\nDigite UMA letra: ";
        string entrada;
        getline(cin, entrada);

        if (entrada.size() == 1 && isalpha(static_cast<unsigned char>(entrada[0]))) {
            return static_cast<char>(tolower(static_cast<unsigned char>(entrada[0])));
        }

        cout << "Digite somente uma letra.\n";
    }
}

const vector<string> listaPalavras = {
    "computador",
    "programacao",
    "linguagem",
    "teclado",
    "monitor",
    "internet",
    "jogo",
    "variavel",
    "ponteiro",
    "memoria",
    "palavra",
    "injogavel",
    "cs2",
    "minhoca",
    "nome",
    "duque",
    "bola",
    "cubo",
    "naruto",
    "goku",
    "nariz",
    "legal",
    "lapis",
    "visualg",
    "python",
    "elefante",
    "girafa",
    "canguru",
    "tubarao",
    "arara",
    "leao",
    "coruja",
    "camaleao",
    "abacaxi",
    "morango",
    "laranja",
    "uva",
    "banana",
    "manga",
    "kiwi",
    "melancia",
    "brasil",
    "canada",
    "japao",
    "franca",
    "india",
    "egito",
    "italia",
    "mexico",
    "medico",
    "professor",
    "engenheiro",
    "advogado",
    "enfermeiro",
    "arquiteto",
    "jornalista",
    "cozinheiro",
    "vermelho",
    "azul",
    "amarelo",
    "verde",
    "roxo",
    "preto",
    "branco"
};

string sortearPalavra() {
    static mt19937 gerador(
        static_cast<unsigned int>(
            chrono::high_resolution_clock::now().time_since_epoch().count()
        )
    );

    uniform_int_distribution<size_t> dist(0, listaPalavras.size() - 1);
    return listaPalavras[dist(gerador)];
}

struct EstadoJogo {
    string palavra;
    string letrasUsadas;
    int erros = 0;

    // 0 = Time 1, 1 = Time 2
    int turno = 0;

    int pontos[2] = {0, 0};
    bool terminou = false;
    bool venceu = false;
};

bool palavraCompleta(const EstadoJogo& estado) {
    for (char c : estado.palavra) {
        if (!contem(estado.letrasUsadas, c))
            return false;
    }
    return true;
}

void mostrarForca(int erros) {
    const char* desenho[] = {
        "  +---+\n"
        "  |   |\n"
        "      |\n"
        "      |\n"
        "      |\n"
        "=========",

        "  +---+\n"
        "  |   |\n"
        "  O   |\n"
        "      |\n"
        "      |\n"
        "=========",

        "  +---+\n"
        "  |   |\n"
        "  O   |\n"
        "  |   |\n"
        "      |\n"
        "=========",

        "  +---+\n"
        "  |   |\n"
        "  O   |\n"
        " /|   |\n"
        "      |\n"
        "=========",

        "  +---+\n"
        "  |   |\n"
        "  O   |\n"
        " /|\\  |\n"
        "      |\n"
        "=========",

        "  +---+\n"
        "  |   |\n"
        "  O   |\n"
        " /|\\  |\n"
        " /    |\n"
        "=========",

        "  +---+\n"
        "  |   |\n"
        "  O   |\n"
        " /|\\  |\n"
        " / \\  |\n"
        "=========",

        "  +---+\n"
        "  |   |\n"
        " _O   |\n"
        " /|\\  |\n"
        " / \\  |\n"
        "=========",

        "  +---+\n"
        "  |   |\n"
        "  X   |\n"
        " /|\\  |\n"
        " / \\  |\n"
        "========="
    };

    if (erros < 0) erros = 0;
    if (erros > MAX_TENTATIVAS) erros = MAX_TENTATIVAS;

    cout << desenho[erros] << "\n";
}

void mostrarEstadoCliente(const string& nome1,
                          const string& nome2,
                          const EstadoJogo& estado) {
    limparTela();

    cout << "=============================================\n";
    cout << "          JOGO DA FORCA ONLINE               \n";
    cout << "=============================================\n\n";

    mostrarForca(estado.erros);

    cout << "\nPalavra: " << estado.palavra << "\n";

    cout << "\nLetras usadas: ";
    if (estado.letrasUsadas.empty())
        cout << "(nenhuma)";
    else
        for (char c : estado.letrasUsadas) cout << c << ' ';

    cout << "\n\nTentativas restantes: "
         << MAX_TENTATIVAS - estado.erros << "\n";

    cout << "\nPLACAR\n";
    cout << nome1 << ": " << estado.pontos[0] << " pontos\n";
    cout << nome2 << ": " << estado.pontos[1] << " pontos\n";

    if (!estado.terminou) {
        cout << "\nTurno: "
             << (estado.turno == 0 ? nome1 : nome2)
             << "\n";
    }

    cout << "\n";
}

string serializarEstado(const EstadoJogo& e) {
    // Protocolo:
    // STATE|palavra|letras|erros|turno|p1|p2|terminou|venceu
    ostringstream out;

    out << "STATE|"
        << mascararPalavra(e.palavra, e.letrasUsadas) << "|"
        << e.letrasUsadas << "|"
        << e.erros << "|"
        << e.turno << "|"
        << e.pontos[0] << "|"
        << e.pontos[1] << "|"
        << (e.terminou ? 1 : 0) << "|"
        << (e.venceu ? 1 : 0);

    return out.str();
}

bool desserializarEstado(const string& linha, EstadoJogo& e) {
    vector<string> partes;
    string atual;

    for (char c : linha) {
        if (c == '|') {
            partes.push_back(atual);
            atual.clear();
        } else {
            atual += c;
        }
    }
    partes.push_back(atual);

    if (partes.size() != 9 || partes[0] != "STATE")
        return false;

    e.palavra = partes[1];
    e.letrasUsadas = partes[2];

    try {
        e.erros = stoi(partes[3]);
        e.turno = stoi(partes[4]);
        e.pontos[0] = stoi(partes[5]);
        e.pontos[1] = stoi(partes[6]);
        e.terminou = stoi(partes[7]) != 0;
        e.venceu = stoi(partes[8]) != 0;
    } catch (...) {
        return false;
    }

    return true;
}

bool enviarEstado(socket_t cliente, const EstadoJogo& estado) {
    return enviarLinha(cliente, serializarEstado(estado));
}

void anunciarResultado(const string& nome1,
                       const string& nome2,
                       const EstadoJogo& e) {
    cout << "\n=============================================\n";

    if (e.venceu) {
        cout << "PARABENS! A PALAVRA FOI DESCOBERTA!\n";
        cout << "Palavra: " << e.palavra << "\n";

        // Em uma rodada, o time que completa a palavra vence.
        // O placar continua registrando os pontos de cada letra.
        cout << "A rodada foi vencida pelo time que completou a palavra.\n";
    } else {
        cout << "FIM DE JOGO! A FORCA FOI COMPLETADA.\n";
        cout << "A palavra era: " << e.palavra << "\n";
    }

    cout << "\nPLACAR FINAL\n";
    cout << nome1 << ": " << e.pontos[0] << " pontos\n";
    cout << nome2 << ": " << e.pontos[1] << " pontos\n";

    if (e.pontos[0] > e.pontos[1])
        cout << "\nVencedor pelo placar: " << nome1 << "\n";
    else if (e.pontos[1] > e.pontos[0])
        cout << "\nVencedor pelo placar: " << nome2 << "\n";
    else
        cout << "\nEmpate no placar!\n";

    cout << "=============================================\n";
}

void servidor() {
    limparTela();

    cout << "=============================================\n";
    cout << "           SERVIDOR - JOGO DA FORCA          \n";
    cout << "=============================================\n\n";

    string nome1 = lerNome("Nome do Time 1: ");

    cout << "\nDigite o nome do Time 2 quando ele conectar.\n";

    EstadoJogo estado;
    estado.palavra = sortearPalavra();

    socket_t servidorSocket = socket(AF_INET, SOCK_STREAM, 0);

    if (servidorSocket == INVALID_SOCKET_VALUE) {
        cerr << "Erro ao criar socket do servidor.\n";
        return;
    }

#ifdef _WIN32
    BOOL reutilizar = TRUE;
    setsockopt(servidorSocket, SOL_SOCKET, SO_REUSEADDR,
               reinterpret_cast<const char*>(&reutilizar), sizeof(reutilizar));
#else
    int reutilizar = 1;
    setsockopt(servidorSocket, SOL_SOCKET, SO_REUSEADDR,
               &reutilizar, sizeof(reutilizar));
#endif

    sockaddr_in endereco{};
    endereco.sin_family = AF_INET;
    endereco.sin_addr.s_addr = htonl(INADDR_ANY);
    endereco.sin_port = htons(PORTA);

    if (bind(servidorSocket,
             reinterpret_cast<sockaddr*>(&endereco),
             sizeof(endereco)) < 0) {
        cerr << "Nao foi possivel abrir a porta " << PORTA << ".\n";
        fecharSocket(servidorSocket);
        return;
    }

    if (listen(servidorSocket, 1) < 0) {
        cerr << "Erro ao colocar servidor em espera.\n";
        fecharSocket(servidorSocket);
        return;
    }

    cout << "\nServidor iniciado na porta " << PORTA << ".\n";
    cout << "Aguardando o Time 2 conectar...\n";

    sockaddr_in clienteEndereco{};
#ifdef _WIN32
    int tamanhoEndereco = sizeof(clienteEndereco);
#else
    socklen_t tamanhoEndereco = sizeof(clienteEndereco);
#endif

    socket_t cliente = accept(
        servidorSocket,
        reinterpret_cast<sockaddr*>(&clienteEndereco),
        &tamanhoEndereco
    );

    if (cliente == INVALID_SOCKET_VALUE) {
        cerr << "Erro ao aceitar conexao.\n";
        fecharSocket(servidorSocket);
        return;
    }

    cout << "Time 2 conectado!\n";

    string hello;
    if (!receberLinha(cliente, hello) || hello.rfind("HELLO|", 0) != 0) {
        cerr << "O cliente nao enviou o nome corretamente.\\n";
        fecharSocket(cliente);
        fecharSocket(servidorSocket);
        return;
    }

    string nome2 = hello.substr(6);
    if (nome2.empty()) nome2 = "Time 2";
    if (nome2.size() > MAX_NOME) nome2.resize(MAX_NOME);

    // O cliente recebe apenas a palavra mascarada, nunca a palavra secreta.
    // O estado enviado contém a palavra para simplificar o protocolo.
    // A tela do cliente nunca imprime o campo secreto diretamente.
    if (!enviarLinha(cliente, "NAMES|" + nome1 + "|" + nome2)) {
        cerr << "Erro ao enviar nomes.\n";
        fecharSocket(cliente);
        fecharSocket(servidorSocket);
        return;
    }

    enviarEstado(cliente, estado);

    bool conexaoAtiva = true;

    while (conexaoAtiva && !estado.terminou) {
        // O servidor controla o estado compartilhado.
        // Quando for a vez do Time 1, a entrada vem deste terminal.
        // Quando for a vez do Time 2, a entrada vem pela rede.
        char letra = '\0';

        if (estado.turno == 0) {
            mostrarEstadoCliente(nome1, nome2, estado);

            cout << "\nSua vez, " << nome1 << "!\n";
            letra = lerLetraLocal();
        } else {
            cout << "\nAguardando a jogada do " << nome2 << "...\n";

            string mensagem;

            if (!receberLinha(cliente, mensagem)) {
                cout << "\nO outro jogador desconectou.\n";
                conexaoAtiva = false;
                break;
            }

            if (mensagem.rfind("GUESS|", 0) != 0 || mensagem.size() < 7)
                continue;

            letra = static_cast<char>(
                tolower(static_cast<unsigned char>(mensagem[6]))
            );
        }

        if (!isalpha(static_cast<unsigned char>(letra))) {
            if (estado.turno == 1) {
                enviarLinha(cliente, "INFO|Digite somente uma letra.");
                enviarEstado(cliente, estado);
            } else {
                cout << "\nDigite somente uma letra.\n";
            }
            continue;
        }

        int timeJogador = estado.turno;

        if (contem(estado.letrasUsadas, letra)) {
            string aviso = "INFO|A letra '" + string(1, letra) +
                           "' ja foi usada. Escolha outra letra.";

            if (timeJogador == 1)
                enviarLinha(cliente, aviso);
            else
                cout << "\n" << aviso.substr(5) << "\n";

            // Letra repetida nao consome o turno. O mesmo jogador tenta novamente.
            if (!enviarEstado(cliente, estado)) {
                conexaoAtiva = false;
                break;
            }

            continue;
        }

        estado.letrasUsadas += letra;

        bool acertou = contem(estado.palavra, letra);

        if (acertou) {
            estado.pontos[timeJogador] += 3;
        } else {
            estado.pontos[timeJogador] -= 1;
            estado.erros++;
        }

        if (palavraCompleta(estado)) {
            estado.terminou = true;
            estado.venceu = true;
        } else if (estado.erros >= MAX_TENTATIVAS) {
            estado.terminou = true;
            estado.venceu = false;
        } else {
            estado.turno = 1 - estado.turno;
        }

        string resultado = acertou
            ? "INFO|Time " + to_string(timeJogador + 1) +
              " acertou a letra '" + string(1, letra) + "'! +3 pontos."
            : "INFO|Time " + to_string(timeJogador + 1) +
              " errou com a letra '" + string(1, letra) + "'! -1 ponto.";

        if (timeJogador == 0)
            cout << "\n" << resultado.substr(5) << "\n";

        if (!enviarLinha(cliente, resultado) ||
            !enviarEstado(cliente, estado)) {
            conexaoAtiva = false;
            break;
        }

        if (estado.terminou) {
            mostrarEstadoCliente(nome1, nome2, estado);
            anunciarResultado(nome1, nome2, estado);

            // Revela a palavra somente quando a rodada terminou.
            enviarLinha(cliente, "RESULT|" + estado.palavra);
        }
    }

    fecharSocket(cliente);
    fecharSocket(servidorSocket);
}

void cliente() {
    limparTela();

    cout << "=============================================\n";
    cout << "            CLIENTE - JOGO DA FORCA          \n";
    cout << "=============================================\n\n";

    string nome2 = lerNome("Nome do seu time: ");

    string ip;
    cout << "IP do servidor (ex.: 192.168.0.10): ";
    getline(cin, ip);

    if (ip.empty())
        ip = "127.0.0.1";

    socket_t cliente = socket(AF_INET, SOCK_STREAM, 0);

    if (cliente == INVALID_SOCKET_VALUE) {
        cerr << "Erro ao criar socket do cliente.\n";
        return;
    }

    sockaddr_in endereco{};
    endereco.sin_family = AF_INET;
    endereco.sin_port = htons(PORTA);

    // inet_addr e usado para manter compatibilidade com MinGW/Dev-C++ 5.11.
    endereco.sin_addr.s_addr = inet_addr(ip.c_str());

    if (endereco.sin_addr.s_addr == INADDR_NONE) {
        cerr << "IP invalido.\n";
        fecharSocket(cliente);
        return;
    }

    cout << "\nConectando ao servidor...\n";

    if (connect(cliente,
                reinterpret_cast<sockaddr*>(&endereco),
                sizeof(endereco)) < 0) {
        cerr << "Nao foi possivel conectar ao servidor.\n";
        cerr << "Verifique o IP, a porta " << PORTA
             << " e o firewall do PC servidor.\n";
        fecharSocket(cliente);
        return;
    }

    cout << "Conectado!\\n";

    if (!enviarLinha(cliente, "HELLO|" + nome2)) {
        cerr << "Nao foi possivel enviar o nome ao servidor.\\n";
        fecharSocket(cliente);
        return;
    }

    string mensagem;

    if (!receberLinha(cliente, mensagem) ||
        mensagem.rfind("NAMES|", 0) != 0) {
        cerr << "Protocolo do servidor invalido.\n";
        fecharSocket(cliente);
        return;
    }

    vector<string> nomes;
    string parte;
    stringstream ss(mensagem);

    while (getline(ss, parte, '|'))
        nomes.push_back(parte);

    string nome1 = nomes.size() > 1 ? nomes[1] : "Time 1";
    string nomeDois = nome2;

    EstadoJogo estado;

    if (!receberLinha(cliente, mensagem) ||
        !desserializarEstado(mensagem, estado)) {
        cerr << "Nao foi possivel receber o estado inicial.\n";
        fecharSocket(cliente);
        return;
    }

    // O servidor envia somente a versao mascarada da palavra.
    // A palavra secreta permanece somente na memoria do servidor.
    bool ativo = true;

    while (ativo) {
        mostrarEstadoCliente(nome1, nomeDois, estado);

        if (estado.terminou) {
            anunciarResultado(nome1, nomeDois, estado);
            break;
        }

        if (estado.turno != 1) {
            cout << "Aguardando o Time 1 jogar...\n";

            if (!receberLinha(cliente, mensagem)) {
                cout << "\nO servidor encerrou a conexao.\n";
                break;
            }

            // O servidor pode enviar INFO antes do STATE. Continue lendo
            // ate receber o estado completo da partida.
            if (mensagem.rfind("INFO|", 0) == 0) {
                cout << "\n" << mensagem.substr(5) << "\n";
                if (!receberLinha(cliente, mensagem)) {
                    cout << "\nO servidor encerrou a conexao.\n";
                    break;
                }
            }

            if (mensagem.rfind("STATE|", 0) != 0 ||
                !desserializarEstado(mensagem, estado)) {
                cout << "\nEstado recebido invalido.\n";
                break;
            }

            continue;
        }

        char letra = lerLetraLocal();

        if (!enviarLinha(cliente, string("GUESS|") + letra)) {
            cout << "Conexao perdida.\n";
            break;
        }

        // O servidor responde com INFO (quando necessario) e depois STATE.
        if (!receberLinha(cliente, mensagem)) {
            cout << "\nO servidor encerrou a conexao.\n";
            break;
        }

        if (mensagem.rfind("INFO|", 0) == 0) {
            cout << "\n" << mensagem.substr(5) << "\n";
            if (!receberLinha(cliente, mensagem)) {
                cout << "\nO servidor encerrou a conexao.\n";
                break;
            }
        }

        if (mensagem.rfind("STATE|", 0) != 0 ||
            !desserializarEstado(mensagem, estado)) {
            cout << "\nEstado recebido invalido.\n";
            break;
        }

        if (estado.terminou) {
            string resultadoFinal;
            if (receberLinha(cliente, resultadoFinal) &&
                resultadoFinal.rfind("RESULT|", 0) == 0) {
                estado.palavra = resultadoFinal.substr(7);
            }

            mostrarEstadoCliente(nome1, nomeDois, estado);
            anunciarResultado(nome1, nomeDois, estado);
            break;
        }
    }

    fecharSocket(cliente);
}

int main() {
    setlocale(LC_ALL, "");

    inicializarSockets();

    while (true) {
        limparTela();

        cout << "=============================================\n";
        cout << "              JOGO DA FORCA                  \n";
        cout << "=============================================\n\n";

        cout << "1 - Criar servidor (Time 1)\n";
        cout << "2 - Entrar no servidor (Time 2)\n";
        cout << "3 - Sair\n\n";
        cout << "Escolha: ";

        string opcao;
        getline(cin, opcao);

        if (opcao == "1") {
            servidor();
        } else if (opcao == "2") {
            cliente();
        } else if (opcao == "3") {
            break;
        } else {
            cout << "Opcao invalida.\n";
        }

        cout << "\nPressione Enter para voltar ao menu...";
        getline(cin, opcao);
    }

    finalizarSockets();
    return 0;
}
