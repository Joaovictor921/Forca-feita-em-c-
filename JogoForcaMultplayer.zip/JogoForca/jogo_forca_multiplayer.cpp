/*
    JOGO DA FORCA MULTIPLAYER
    Baseado no jogo da forca original de Joao Victor Dalbem e Guilherme Duque.

    Modo:
      - 1 servidor + 1 cliente
      - Pode funcionar em dois terminais no mesmo PC (127.0.0.1)
      - Pode funcionar em dois PCs na mesma rede (LAN)
      - O SERVIDOR guarda o estado compartilhado:
          palavra secreta, letras usadas, erros, pontuacao e turno.
      - Cada time joga UMA letra por turno.

    Compilacao:
      Windows (MinGW):
        g++ jogo_forca_multiplayer.cpp -std=c++11 -O2 -o forca.exe -lws2_32

      Linux:
        g++ jogo_forca_multiplayer.cpp -std=c++11 -O2 -o forca

    Como jogar em dois PCs:
      PC 1:
        forca.exe
        escolha 1 - Servidor

      PC 2:
        forca.exe
        escolha 2 - Cliente
        informe o IP do PC 1.

    Para testar no mesmo PC:
      abra dois terminais e use 127.0.0.1 no cliente.
*/

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <random>
#include <cctype>
#include <cstring>
#include <sstream>
#include <limits>
#include <chrono>

#ifdef _WIN32
    #define NOMINMAX
    #include <winsock2.h>
    #include <ws2tcpip.h>
    using socket_t = SOCKET;
    const socket_t INVALID_SOCKET_VALUE = INVALID_SOCKET;
#else
    #include <sys/types.h>
    #include <sys/socket.h>
    #include <arpa/inet.h>
    #include <netinet/in.h>
    #include <unistd.h>
    using socket_t = int;
    const socket_t INVALID_SOCKET_VALUE = -1;
#endif

using namespace std;

constexpr int PORTA = 54000;
constexpr int MAX_TENTATIVAS = 8;
constexpr int TAMANHO_MAX = 100;
constexpr int MAX_NOME = 49;

#ifdef _WIN32
void fecharSocket(socket_t s) {
    if (s != INVALID_SOCKET) closesocket(s);
}
#else
void fecharSocket(socket_t s) {
    if (s >= 0) close(s);
}
#endif

void limparTela() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

void inicializarSockets() {
#ifdef _WIN32
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        cerr << "Erro ao iniciar Winsock.\n";
        exit(1);
    }
#endif
}

void finalizarSockets() {
#ifdef _WIN32
    WSACleanup();
#endif
}

bool enviarTudo(socket_t s, const string& texto) {
    size_t enviado = 0;
    while (enviado < texto.size()) {
#ifdef _WIN32
        int n = send(s, texto.c_str() + enviado,
                     static_cast<int>(texto.size() - enviado), 0);
#else
        ssize_t n = send(s, texto.c_str() + enviado,
                         texto.size() - enviado, 0);
#endif
        if (n <= 0) return false;
        enviado += static_cast<size_t>(n);
    }
    return true;
}

// Todas as mensagens terminam com '\n'.
// Isso deixa o protocolo simples e funciona tanto no Windows quanto no Linux.
bool enviarLinha(socket_t s, const string& linha) {
    return enviarTudo(s, linha + "\n");
}

bool receberLinha(socket_t s, string& linha) {
    linha.clear();
    char c;

    while (true) {
#ifdef _WIN32
        int n = recv(s, &c, 1, 0);
#else
        ssize_t n = recv(s, &c, 1, 0);
#endif
        if (n <= 0) return false;

        if (c == '\n') break;
        if (c != '\r') linha += c;

        if (linha.size() > 4096) return false;
    }

    return true;
}

string normalizar(const string& entrada) {
    string s;

    for (unsigned char c : entrada) {
        // O jogo usa palavras sem acentos para evitar problemas de
        // codificacao no terminal e na comunicacao entre PCs.
        if (isalnum(c)) {
            s += static_cast<char>(tolower(c));
        }
    }

    return s;
}

string mascararPalavra(const string& palavra, const string& usadas) {
    string resultado;

    for (char c : palavra) {
        if (usadas.find(c) != string::npos)
            resultado += c;
        else
            resultado += '_';

        resultado += ' ';
    }

    return resultado;
}

bool contem(const string& texto, char c) {
    return texto.find(c) != string::npos;
}

string lerNome(const string& mensagem) {
    string nome;
    cout << mensagem;
    getline(cin, nome);

    if (nome.empty()) nome = "Jogador";

    if (nome.size() > MAX_NOME)
        nome.resize(MAX_NOME);

    for (char& c : nome) {
        if (c == '|') c = '_';
    }

    return nome;
}

char lerLetraLocal() {
    while (true) {
        cout << "\nDigite UMA letra: ";
        string entrada;
        getline(cin, entrada);

        if (entrada.size() == 1 && isalpha(static_cast<unsigned char>(entrada[0]))) {
            return static_cast<char>(tolower(static_cast<unsigned char>(entrada[0])));
        }

        cout << "Digite somente uma letra.\n";
    }
}

char normalizarLetra(char c) {
    return static_cast<char>(tolower(static_cast<unsigned char>(c)));
}

string lerPalavraLocal() {
    while (true) {
        cout << "\nDigite a PALAVRA inteira: ";
        string entrada;
        getline(cin, entrada);
        string palavra = normalizar(entrada);
        if (!palavra.empty()) return palavra;
        cout << "Digite uma palavra valida.\n";
    }
}

const vector<string> listaPalavras = {
    "computador",
    "programacao",
    "linguagem",
    "teclado",
    "monitor",
    "internet",
    "jogo",
    "variavel",
    "ponteiro",
    "memoria",
    "palavra",
    "injogavel",
    "cs2",
    "minhoca",
    "nome",
    "duque",
    "bola",
    "cubo",
    "naruto",
    "goku",
    "nariz",
    "legal",
    "lapis",
    "visualg",
    "python",
    "elefante",
    "girafa",
    "canguru",
    "tubarao",
    "arara",
    "leao",
    "coruja",
    "camaleao",
    "abacaxi",
    "morango",
    "laranja",
    "uva",
    "banana",
    "manga",
    "kiwi",
    "melancia",
    "brasil",
    "canada",
    "japao",
    "franca",
    "india",
    "egito",
    "italia",
    "mexico",
    "medico",
    "professor",
    "engenheiro",
    "advogado",
    "enfermeiro",
    "arquiteto",
    "jornalista",
    "cozinheiro",
    "vermelho",
    "azul",
    "amarelo",
    "verde",
    "roxo",
    "preto",
    "branco"
};

string sortearPalavra() {
    static mt19937 gerador(
        static_cast<unsigned int>(
            chrono::high_resolution_clock::now().time_since_epoch().count()
        )
    );

    uniform_int_distribution<size_t> dist(0, listaPalavras.size() - 1);
    return listaPalavras[dist(gerador)];
}

struct EstadoJogo {
    string palavra;
    string letrasUsadas;
    int erros[2];

    // 0 = Time 1, 1 = Time 2
    int turno;

    int pontos[2];
    bool terminou;
    bool venceu;
    int vencedor;
    bool vitoriaPorPalavra;

    EstadoJogo() {
        erros[0] = 0;
        erros[1] = 0;
        turno = 0;
        pontos[0] = 0;
        pontos[1] = 0;
        terminou = false;
        venceu = false;
        vencedor = -1;
        vitoriaPorPalavra = false;
    }
};

const int ERROS_PARA_CHUTE_PALAVRA = 6;

bool podeChutarPalavra(const EstadoJogo& e) {
    int outro = 1 - e.turno;
    return e.erros[outro] >= ERROS_PARA_CHUTE_PALAVRA;
}

bool palavraCompleta(const EstadoJogo& estado) {
    for (char c : estado.palavra) {
        if (!contem(estado.letrasUsadas, c))
            return false;
    }
    return true;
}

void mostrarPersonagemTime1(int erros) {
    const char* desenho[] = {
        "  +---+\n  |   |\n      |\n      |\n      |\n=========",
        "  +---+\n  |   |\n  O   |\n      |\n      |\n=========",
        "  +---+\n  |   |\n  O   |\n  |   |\n      |\n=========",
        "  +---+\n  |   |\n  O   |\n /|   |\n      |\n=========",
        "  +---+\n  |   |\n  O   |\n /|\\  |\n      |\n=========",
        "  +---+\n  |   |\n  O   |\n /|\\  |\n /    |\n=========",
        "  +---+\n  |   |\n  O   |\n /|\\  |\n / \\  |\n=========",
        "  +---+\n  |   |\n _O   |\n /|\\  |\n / \\  |\n=========",
        "  +---+\n  |   |\n  X   |\n /|\\  |\n / \\  |\n========="
    };
    if (erros < 0) erros = 0;
    if (erros > MAX_TENTATIVAS) erros = MAX_TENTATIVAS;
    cout << desenho[erros] << "\n";
}

void mostrarPersonagemTime2(int erros) {
    const char* desenho[] = {
        "  .---.\n  |   |\n      |\n      |\n      |\n=========",
        "  .---.\n  |   |\n  O   |\n      |\n      |\n=========",
        "  .---.\n  |   |\n [O]  |\n      |\n      |\n=========",
        "  .---.\n  |   |\n [O]  |\n  |   |\n      |\n=========",
        "  .---.\n  |   |\n [O]  |\n /|   |\n      |\n=========",
        "  .---.\n  |   |\n [O]  |\n /|\\  |\n      |\n=========",
        "  .---.\n  |   |\n [O]  |\n /|\\  |\n /    |\n=========",
        "  .---.\n  |   |\n [O]  |\n /|\\  |\n / \\  |\n=========",
        "  .---.\n  |   |\n [X]  |\n /|\\  |\n / \\  |\n========="
    };
    if (erros < 0) erros = 0;
    if (erros > MAX_TENTATIVAS) erros = MAX_TENTATIVAS;
    cout << desenho[erros] << "\n";
}

void mostrarEstado(const string& nome1, const string& nome2, const EstadoJogo& estado, bool revelarPalavra) {
    limparTela();
    cout << "==================================================\n";
    cout << "          JOGO DA FORCA MULTIPLAYER               \n";
    cout << "==================================================\n\n";

    cout << "TIME 1 - " << nome1 << "\n";
    mostrarPersonagemTime1(estado.erros[0]);
    cout << "Erros: " << estado.erros[0] << "/" << MAX_TENTATIVAS << "\n\n";

    cout << "TIME 2 - " << nome2 << "\n";
    mostrarPersonagemTime2(estado.erros[1]);
    cout << "Erros: " << estado.erros[1] << "/" << MAX_TENTATIVAS << "\n\n";

    cout << "--------------------------------------------------\n";
    cout << "Palavra: ";
    if (revelarPalavra)
        cout << estado.palavra;
    else
        cout << mascararPalavra(estado.palavra, estado.letrasUsadas);
    cout << "\n";

    cout << "\nLetras usadas: ";
    if (estado.letrasUsadas.empty()) cout << "(nenhuma)";
    else for (size_t i = 0; i < estado.letrasUsadas.size(); ++i) cout << estado.letrasUsadas[i] << ' ';

    cout << "\n\nPLACAR\n";
    cout << nome1 << ": " << estado.pontos[0] << " pontos\n";
    cout << nome2 << ": " << estado.pontos[1] << " pontos\n";
    if (!estado.terminou)
        cout << "\nTurno: " << (estado.turno == 0 ? nome1 : nome2) << "\n";
}

string serializarEstado(const EstadoJogo& e) {
    // STATE|palavraMascarada|letras|erro1|erro2|turno|p1|p2|terminou|venceu|vencedor|vitoriaPalavra
    ostringstream out;
    out << "STATE|"
        << mascararPalavra(e.palavra, e.letrasUsadas) << "|"
        << e.letrasUsadas << "|"
        << e.erros[0] << "|"
        << e.erros[1] << "|"
        << e.turno << "|"
        << e.pontos[0] << "|"
        << e.pontos[1] << "|"
        << (e.terminou ? 1 : 0) << "|"
        << (e.venceu ? 1 : 0) << "|"
        << e.vencedor << "|"
        << (e.vitoriaPorPalavra ? 1 : 0);
    return out.str();
}

bool desserializarEstado(const string& linha, EstadoJogo& e) {
    vector<string> partes;
    string atual;
    for (size_t i = 0; i < linha.size(); ++i) {
        if (linha[i] == '|') { partes.push_back(atual); atual.clear(); }
        else atual += linha[i];
    }
    partes.push_back(atual);
    if (partes.size() != 12 || partes[0] != "STATE") return false;
    e.palavra = partes[1];
    e.letrasUsadas = partes[2];
    try {
        e.erros[0] = stoi(partes[3]);
        e.erros[1] = stoi(partes[4]);
        e.turno = stoi(partes[5]);
        e.pontos[0] = stoi(partes[6]);
        e.pontos[1] = stoi(partes[7]);
        e.terminou = stoi(partes[8]) != 0;
        e.venceu = stoi(partes[9]) != 0;
        e.vencedor = stoi(partes[10]);
        e.vitoriaPorPalavra = stoi(partes[11]) != 0;
    } catch (...) { return false; }
    return true;
}

bool enviarEstado(socket_t cliente, const EstadoJogo& estado) {
    return enviarLinha(cliente, serializarEstado(estado));
}

void anunciarResultado(const string& nome1, const string& nome2, const EstadoJogo& e) {
    cout << "\n==================================================\n";
    if (e.vitoriaPorPalavra) {
        cout << "PALAVRA INTEIRA ACERTADA!\n";
        cout << "Palavra: " << e.palavra << "\n";
        cout << "Vencedor da rodada: " << (e.vencedor == 0 ? nome1 : nome2) << "\n";
        cout << "Bonus: +5 pontos\n";
    } else if (e.venceu) {
        cout << "PARABENS! A PALAVRA FOI DESCOBERTA!\n";
        cout << "Palavra: " << e.palavra << "\n";
        cout << "Vencedor da rodada: " << (e.vencedor == 0 ? nome1 : nome2) << "\n";
    } else {
        cout << "FIM DE JOGO! OS PERSONAGENS FORAM COMPLETADOS.\n";
        cout << "A palavra era: " << e.palavra << "\n";
    }
    cout << "\nPLACAR FINAL\n";
    cout << nome1 << ": " << e.pontos[0] << " pontos\n";
    cout << nome2 << ": " << e.pontos[1] << " pontos\n";
    if (e.pontos[0] > e.pontos[1]) cout << "\nVencedor pelo placar: " << nome1 << "\n";
    else if (e.pontos[1] > e.pontos[0]) cout << "\nVencedor pelo placar: " << nome2 << "\n";
    else cout << "\nEmpate no placar!\n";
    cout << "==================================================\n";
}

void servidor() {
    limparTela();
    cout << "=============================================\n";
    cout << "           SERVIDOR - JOGO DA FORCA         \n";
    cout << "=============================================\n\n";

    string nome1 = lerNome("Nome do Time 1: ");
    EstadoJogo estado;
    estado.palavra = sortearPalavra();

    socket_t servidorSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (servidorSocket == INVALID_SOCKET_VALUE) { cerr << "Erro ao criar socket do servidor.\n"; return; }

#ifdef _WIN32
    BOOL reutilizar = TRUE;
    setsockopt(servidorSocket, SOL_SOCKET, SO_REUSEADDR, reinterpret_cast<const char*>(&reutilizar), sizeof(reutilizar));
#else
    int reutilizar = 1;
    setsockopt(servidorSocket, SOL_SOCKET, SO_REUSEADDR, &reutilizar, sizeof(reutilizar));
#endif

    sockaddr_in endereco;
    memset(&endereco, 0, sizeof(endereco));
    endereco.sin_family = AF_INET;
    endereco.sin_addr.s_addr = htonl(INADDR_ANY);
    endereco.sin_port = htons(PORTA);

    if (bind(servidorSocket, reinterpret_cast<sockaddr*>(&endereco), sizeof(endereco)) < 0) {
        cerr << "Nao foi possivel abrir a porta " << PORTA << ".\n";
        fecharSocket(servidorSocket); return;
    }
    if (listen(servidorSocket, 1) < 0) {
        cerr << "Erro ao colocar servidor em espera.\n";
        fecharSocket(servidorSocket); return;
    }

    cout << "Servidor iniciado na porta " << PORTA << ".\n";
    cout << "Aguardando o Time 2 conectar...\n";

    sockaddr_in clienteEndereco;
    memset(&clienteEndereco, 0, sizeof(clienteEndereco));
#ifdef _WIN32
    int tamanhoEndereco = sizeof(clienteEndereco);
#else
    socklen_t tamanhoEndereco = sizeof(clienteEndereco);
#endif
    socket_t cliente = accept(servidorSocket, reinterpret_cast<sockaddr*>(&clienteEndereco), &tamanhoEndereco);
    if (cliente == INVALID_SOCKET_VALUE) {
        cerr << "Erro ao aceitar conexao.\n";
        fecharSocket(servidorSocket); return;
    }

    string hello;
    if (!receberLinha(cliente, hello) || hello.rfind("HELLO|", 0) != 0) {
        cerr << "O cliente nao enviou o nome corretamente.\n";
        fecharSocket(cliente); fecharSocket(servidorSocket); return;
    }
    string nome2 = hello.substr(6);
    if (nome2.empty()) nome2 = "Time 2";
    if (nome2.size() > MAX_NOME) nome2.resize(MAX_NOME);

    if (!enviarLinha(cliente, "NAMES|" + nome1 + "|" + nome2) || !enviarEstado(cliente, estado)) {
        fecharSocket(cliente); fecharSocket(servidorSocket); return;
    }

    bool ativo = true;
    while (ativo && !estado.terminou) {
        int timeJogador = estado.turno;
        mostrarEstado(nome1, nome2, estado, false);
        char letra = '\0';
        string acao;

        if (timeJogador == 0) {
            cout << "\nSua vez, " << nome1 << "!\n";
            if (podeChutarPalavra(estado)) {
                cout << "\nA forca do outro time esta quase completa!\n";
                cout << "1 - Tentar a palavra inteira (+5 se acertar)\n";
                cout << "2 - Tentar uma letra\n";
                cout << "Escolha: ";
                string opcao; getline(cin, opcao);
                if (opcao == "1") {
                    string palpite = lerPalavraLocal();
                    if (palpite == estado.palavra) {
                        estado.pontos[0] += 5;
                        estado.terminou = true; estado.venceu = true;
                        estado.vencedor = 0; estado.vitoriaPorPalavra = true;
                        enviarLinha(cliente, "INFO|Time 1 acertou a palavra inteira! +5 pontos.");
                        enviarEstado(cliente, estado);
                        enviarLinha(cliente, "RESULT|" + estado.palavra);
                        mostrarEstado(nome1, nome2, estado, true);
                        anunciarResultado(nome1, nome2, estado);
                        continue;
                    }
                    estado.pontos[0] -= 1;
                    estado.erros[0]++;
                    cout << "\nPalavra errada! -1 ponto e +1 erro.\n";
                    if (estado.erros[0] >= MAX_TENTATIVAS && estado.erros[1] >= MAX_TENTATIVAS) {
                        estado.terminou = true; estado.venceu = false; estado.vencedor = -1;
                    } else estado.turno = 1;

                    enviarLinha(cliente, "INFO|Time 1 errou a palavra inteira! -1 ponto e +1 erro.");
                    enviarEstado(cliente, estado);
                    if (estado.terminou) {
                        enviarLinha(cliente, "RESULT|" + estado.palavra);
                        mostrarEstado(nome1, nome2, estado, true);
                        anunciarResultado(nome1, nome2, estado);
                    }
                    continue;
                }
            }
            letra = lerLetraLocal();
        } else {
            cout << "\nAguardando a jogada do " << nome2 << "...\n";
            if (!receberLinha(cliente, acao)) { cout << "\nO outro jogador desconectou.\n"; ativo = false; break; }
            if (acao.rfind("GUESSWORD|", 0) == 0) {
                string palpite = normalizar(acao.substr(10));
                if (palpite == estado.palavra) {
                    estado.pontos[1] += 5;
                    estado.terminou = true; estado.venceu = true;
                    estado.vencedor = 1; estado.vitoriaPorPalavra = true;
                    enviarLinha(cliente, "INFO|Time 2 acertou a palavra inteira! +5 pontos.");
                } else {
                    estado.pontos[1] -= 1; estado.erros[1]++;
                    if (estado.erros[0] >= MAX_TENTATIVAS && estado.erros[1] >= MAX_TENTATIVAS) {
                        estado.terminou = true; estado.venceu = false; estado.vencedor = -1;
                    } else estado.turno = 0;
                    enviarLinha(cliente, "INFO|Time 2 errou a palavra inteira! -1 ponto e +1 erro.");
                }
                enviarEstado(cliente, estado);
                if (estado.terminou) {
                    enviarLinha(cliente, "RESULT|" + estado.palavra);
                    mostrarEstado(nome1, nome2, estado, true);
                    anunciarResultado(nome1, nome2, estado);
                }
                continue;
            }
            if (acao.rfind("GUESS|", 0) != 0 || acao.size() < 7) continue;
            letra = normalizarLetra(acao[6]);
        }

        letra = normalizarLetra(letra);
        if (!isalpha(static_cast<unsigned char>(letra))) {
            if (timeJogador == 1) enviarLinha(cliente, "INFO|Digite somente uma letra.");
            continue;
        }
        if (contem(estado.letrasUsadas, letra)) {
            string aviso = "INFO|A letra '" + string(1, letra) + "' ja foi usada. Escolha outra letra.";
            if (timeJogador == 1) enviarLinha(cliente, aviso);
            else cout << "\n" << aviso.substr(5) << "\n";
            enviarEstado(cliente, estado);
            continue;
        }

        estado.letrasUsadas += letra;
        bool acertou = contem(estado.palavra, letra);
        if (acertou) estado.pontos[timeJogador] += 3;
        else { estado.pontos[timeJogador] -= 1; estado.erros[timeJogador]++; }

        if (palavraCompleta(estado)) {
            estado.terminou = true; estado.venceu = true; estado.vencedor = timeJogador;
        } else if (estado.erros[0] >= MAX_TENTATIVAS && estado.erros[1] >= MAX_TENTATIVAS) {
            estado.terminou = true; estado.venceu = false; estado.vencedor = -1;
        } else estado.turno = 1 - estado.turno;

        string resultado = acertou ? "INFO|Time " + to_string(timeJogador + 1) + " acertou a letra '" + string(1, letra) + "'! +3 pontos."
                                   : "INFO|Time " + to_string(timeJogador + 1) + " errou com a letra '" + string(1, letra) + "'! -1 ponto.";
        if (timeJogador == 0) cout << "\n" << resultado.substr(5) << "\n";

        if (!enviarLinha(cliente, resultado) || !enviarEstado(cliente, estado)) { ativo = false; break; }
        if (estado.terminou) {
            mostrarEstado(nome1, nome2, estado, true);
            anunciarResultado(nome1, nome2, estado);
            enviarLinha(cliente, "RESULT|" + estado.palavra);
        }
    }
    fecharSocket(cliente); fecharSocket(servidorSocket);
}

void cliente() {
    limparTela();
    cout << "=============================================\n";
    cout << "            CLIENTE - JOGO DA FORCA         \n";
    cout << "=============================================\n\n";

    string nome2 = lerNome("Nome do seu time: ");
    string ip;
    cout << "IP do servidor (ex.: 192.168.0.10): ";
    getline(cin, ip);
    if (ip.empty()) ip = "127.0.0.1";

    socket_t cliente = socket(AF_INET, SOCK_STREAM, 0);
    if (cliente == INVALID_SOCKET_VALUE) { cerr << "Erro ao criar socket do cliente.\n"; return; }

    sockaddr_in endereco;
    memset(&endereco, 0, sizeof(endereco));
    endereco.sin_family = AF_INET;
    endereco.sin_port = htons(PORTA);
    endereco.sin_addr.s_addr = inet_addr(ip.c_str());
    if (endereco.sin_addr.s_addr == INADDR_NONE) { cerr << "IP invalido.\n"; fecharSocket(cliente); return; }

    cout << "\nConectando ao servidor...\n";
    if (connect(cliente, reinterpret_cast<sockaddr*>(&endereco), sizeof(endereco)) < 0) {
        cerr << "Nao foi possivel conectar ao servidor.\n";
        fecharSocket(cliente); return;
    }

    if (!enviarLinha(cliente, "HELLO|" + nome2)) { fecharSocket(cliente); return; }
    string mensagem;
    if (!receberLinha(cliente, mensagem) || mensagem.rfind("NAMES|", 0) != 0) { fecharSocket(cliente); return; }
    vector<string> nomes;
    stringstream ss(mensagem), parte;
    string x;
    while (getline(ss, x, '|')) nomes.push_back(x);
    string nome1 = nomes.size() > 1 ? nomes[1] : "Time 1";

    EstadoJogo estado;
    if (!receberLinha(cliente, mensagem) || !desserializarEstado(mensagem, estado)) { fecharSocket(cliente); return; }

    while (true) {
        mostrarEstado(nome1, nome2, estado, estado.terminou);
        if (estado.terminou) {
            if (receberLinha(cliente, mensagem) && mensagem.rfind("RESULT|", 0) == 0) estado.palavra = mensagem.substr(7);
            mostrarEstado(nome1, nome2, estado, true);
            anunciarResultado(nome1, nome2, estado);
            break;
        }

        if (estado.turno != 1) {
            cout << "Aguardando o Time 1 jogar...\n";
            if (!receberLinha(cliente, mensagem)) break;
            if (mensagem.rfind("INFO|", 0) == 0) cout << "\n" << mensagem.substr(5) << "\n";
            if (!receberLinha(cliente, mensagem)) break;
            if (!desserializarEstado(mensagem, estado)) break;
            continue;
        }

        cout << "\nSua vez, " << nome2 << "!\n";
        if (podeChutarPalavra(estado)) {
            cout << "\nA forca de um dos times esta quase completa!\n";
            cout << "1 - Tentar a palavra inteira (+5 se acertar)\n";
            cout << "2 - Tentar uma letra\n";
            cout << "Escolha: ";
            string opcao; getline(cin, opcao);
            if (opcao == "1") {
                string palpite = lerPalavraLocal();
                if (!enviarLinha(cliente, "GUESSWORD|" + palpite)) break;
            } else {
                char letra = lerLetraLocal();
                if (!enviarLinha(cliente, string("GUESS|") + letra)) break;
            }
        } else {
            char letra = lerLetraLocal();
            if (!enviarLinha(cliente, string("GUESS|") + letra)) break;
        }

        if (!receberLinha(cliente, mensagem)) break;
        if (mensagem.rfind("INFO|", 0) == 0) cout << "\n" << mensagem.substr(5) << "\n";
        if (!receberLinha(cliente, mensagem)) break;
        if (!desserializarEstado(mensagem, estado)) break;

        if (estado.terminou) {
            if (!receberLinha(cliente, mensagem)) break;
            if (mensagem.rfind("RESULT|", 0) == 0) estado.palavra = mensagem.substr(7);
            mostrarEstado(nome1, nome2, estado, true);
            anunciarResultado(nome1, nome2, estado);
            break;
        }
    }
    fecharSocket(cliente);
}

int main() {
    setlocale(LC_ALL, "");

    inicializarSockets();

    while (true) {
        limparTela();

        cout << "=============================================\n";
        cout << "              JOGO DA FORCA                  \n";
        cout << "=============================================\n\n";

        cout << "1 - Criar servidor (Time 1)\n";
        cout << "2 - Entrar no servidor (Time 2)\n";
        cout << "3 - Sair\n\n";
        cout << "Escolha: ";

        string opcao;
        getline(cin, opcao);

        if (opcao == "1") {
            servidor();
        } else if (opcao == "2") {
            cliente();
        } else if (opcao == "3") {
            break;
        } else {
            cout << "Opcao invalida.\n";
        }

        cout << "\nPressione Enter para voltar ao menu...";
        getline(cin, opcao);
    }

    finalizarSockets();
    return 0;
}
