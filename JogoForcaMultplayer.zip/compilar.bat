@echo off
g++ jogo_forca_multiplayer.cpp -std=c++11 -O2 -o forca.exe -lws2_32
if %errorlevel% neq 0 (
  echo.
  echo ERRO na compilacao.
) else (
  echo.
  echo Compilacao concluida com sucesso: forca.exe
)
pause
