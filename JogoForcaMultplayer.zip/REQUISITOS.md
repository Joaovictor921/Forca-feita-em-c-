# Requisitos do projeto

## 1. Memória compartilhada

No Windows, o projeto implementa memória compartilhada entre processos usando:

- `CreateFileMappingA()`
- `MapViewOfFile()`
- `OpenFileMappingA()`
- `CreateMutexA()` / `OpenMutexA()`
- `WaitForSingleObject()` / `ReleaseMutex()`

A área compartilhada contém o estado público da partida, como palavra mascarada,
letras utilizadas, turno, pontuação, erros e nomes.

### Mesmo computador

Quando o Time 1 cria o servidor e o Time 2 roda no mesmo computador, o cliente
abre a mesma área nomeada de memória criada pelo servidor. O cliente usa essa área
para ler o estado local da partida.

### Dois computadores

Memória compartilhada não atravessa computadores fisicamente. Nesse cenário, cada
PC possui sua própria área de memória compartilhada local, enquanto o TCP/IP
sincroniza o estado entre os dois PCs.

## 2. Comunicação entre processos

O projeto usa TCP/IP com Winsock para comunicação cliente/servidor:

- `socket()`
- `bind()`
- `listen()`
- `accept()`
- `connect()`
- `send()`
- `recv()`

O processo servidor mantém o estado oficial da partida e recebe as jogadas do
cliente. O cliente recebe as atualizações e exibe o mesmo estado público.

## 3. Por que o projeto usa as duas técnicas?

A combinação demonstra os dois conceitos do trabalho:

```text
            PROCESSO SERVIDOR
                   │
          ┌────────┴────────┐
          │ MEMÓRIA SHARED  │
          └────────┬────────┘
                   │
               TCP/IP
                   │
          ┌────────┴────────┐
          │ MEMÓRIA LOCAL   │
          └────────┬────────┘
                   │
            PROCESSO CLIENTE
```

Assim, o código possui uma implementação explícita de **memória compartilhada**
e uma implementação explícita de **comunicação entre processos por sockets**.
