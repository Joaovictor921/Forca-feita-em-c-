/*
    JOGO DA FORCA MULTIPLAYER
    Baseado no jogo da forca original de Joao Victor Dalbem e Guilherme Duque.

    REQUISITOS ATENDIDOS:
      1) Memoria compartilhada entre processos no mesmo computador (Windows)
         usando CreateFileMapping / MapViewOfFile + mutex nomeado.
      2) Comunicacao entre processos pela rede usando TCP/IP + Winsock.

    MODELO HIBRIDO:
      - Mesmo PC: o servidor e o cliente compartilham o estado atraves de memoria
        compartilhada. O TCP tambem e usado para transportar as jogadas.
      - Dois PCs: cada PC possui sua propria memoria compartilhada local e o
        estado entre os PCs e sincronizado por TCP/IP.

    REGRAS:
      - 2 jogadores: Time 1 (servidor) e Time 2 (cliente)
      - uma jogada por turno
      - letra maiuscula e convertida para minuscula
      - letra repetida nao gasta turno
      - acerto normal: +3 pontos
      - erro: -1 ponto e +1 erro para o time da jogada
      - cada time possui seu proprio desenho e contador de erros
      - quando restam 2 letras diferentes ou menos, o jogador da vez pode
        chutar a palavra inteira ou uma letra
      - na fase final, letra correta vale +5
      - chute correto da palavra vale +5
      - ao final, os dois podem jogar novamente

    Windows (MinGW / Dev-C++):
      g++ jogo_forca_multiplayer.cpp -std=c++11 -O2 -o forca.exe -lws2_32
*/

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <random>
#include <cctype>
#include <cstring>
#include <sstream>
#include <chrono>
#include <cstdlib>
#include <stdint.h>

#ifdef _WIN32
    #define WIN32_LEAN_AND_MEAN
    #include <windows.h>
    #include <winsock2.h>
    #include <ws2tcpip.h>
    using socket_t = SOCKET;
    const socket_t INVALID_SOCKET_VALUE = INVALID_SOCKET;
#else
    #include <sys/types.h>
    #include <sys/socket.h>
    #include <arpa/inet.h>
    #include <netinet/in.h>
    #include <unistd.h>
    using socket_t = int;
    const socket_t INVALID_SOCKET_VALUE = -1;
#endif

using namespace std;

const int PORTA = 54000;
const int MAX_TENTATIVAS = 8;
const int MAX_NOME = 49;
const int MAX_PALAVRA = 255;
const int LETRAS_PARA_FASE_FINAL = 2;
const int BONUS_ACERTO_LETRA_FINAL = 5;
const int BONUS_ACERTO_PALAVRA = 5;

#ifdef _WIN32
const char* SHARED_MEMORY_NAME = "JogoDaForca_SharedMemory_v2";
const char* SHARED_MUTEX_NAME  = "JogoDaForca_SharedMutex_v2";

struct SharedGameMemory {
    char assinatura[16];
    int32_t versao;
    int32_t atualizado;
    int32_t erros[2];
    int32_t turno;
    int32_t pontos[2];
    int32_t terminou;
    int32_t venceu;
    int32_t vencedor;
    int32_t letrasRestantes;
    int32_t vitoriaPorPalavra;
    char palavraMascarada[MAX_PALAVRA + 1];
    char letrasUsadas[128];
    char nome1[64];
    char nome2[64];
};

class MemoriaCompartilhada {
private:
    HANDLE mapa;
    HANDLE mutex;
    SharedGameMemory* memoria;
    bool disponivel;
    bool criouMapa;

public:
    MemoriaCompartilhada() : mapa(NULL), mutex(NULL), memoria(NULL), disponivel(false), criouMapa(false) {}

    ~MemoriaCompartilhada() { fechar(); }

    bool criarComoServidor() {
        mapa = CreateFileMappingA(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE,
                                  0, static_cast<DWORD>(sizeof(SharedGameMemory)),
                                  SHARED_MEMORY_NAME);
        if (!mapa) return false;
        criouMapa = (GetLastError() != ERROR_ALREADY_EXISTS);

        memoria = static_cast<SharedGameMemory*>(MapViewOfFile(mapa, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(SharedGameMemory)));
        if (!memoria) {
            fechar();
            return false;
        }

        mutex = CreateMutexA(NULL, FALSE, SHARED_MUTEX_NAME);
        if (!mutex) {
            fechar();
            return false;
        }

        disponivel = true;
        if (criouMapa) {
            zerar();
        }
        return true;
    }

    bool abrirComoClienteMesmoPC() {
        mapa = OpenFileMappingA(FILE_MAP_ALL_ACCESS, FALSE, SHARED_MEMORY_NAME);
        if (!mapa) return false;

        memoria = static_cast<SharedGameMemory*>(MapViewOfFile(mapa, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(SharedGameMemory)));
        if (!memoria) {
            fechar();
            return false;
        }

        mutex = OpenMutexA(SYNCHRONIZE | MUTEX_MODIFY_STATE, FALSE, SHARED_MUTEX_NAME);
        if (!mutex) {
            fechar();
            return false;
        }

        disponivel = true;
        return true;
    }

    bool criarEspelhoLocal() {
        mapa = CreateFileMappingA(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE,
                                  0, static_cast<DWORD>(sizeof(SharedGameMemory)),
                                  SHARED_MEMORY_NAME);
        if (!mapa) return false;

        memoria = static_cast<SharedGameMemory*>(MapViewOfFile(mapa, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(SharedGameMemory)));
        if (!memoria) {
            fechar();
            return false;
        }

        mutex = CreateMutexA(NULL, FALSE, SHARED_MUTEX_NAME);
        if (!mutex) {
            fechar();
            return false;
        }

        disponivel = true;
        return true;
    }

    bool ativa() const { return disponivel && memoria != NULL && mutex != NULL; }

    bool escrever(const SharedGameMemory& dados) {
        if (!ativa()) return false;
        if (WaitForSingleObject(mutex, 5000) != WAIT_OBJECT_0) return false;
        memcpy(memoria, &dados, sizeof(SharedGameMemory));
        ReleaseMutex(mutex);
        return true;
    }

    bool ler(SharedGameMemory& dados) {
        if (!ativa()) return false;
        if (WaitForSingleObject(mutex, 5000) != WAIT_OBJECT_0) return false;
        memcpy(&dados, memoria, sizeof(SharedGameMemory));
        ReleaseMutex(mutex);
        return true;
    }

    void zerar() {
        if (!memoria) return;
        memset(memoria, 0, sizeof(SharedGameMemory));
        strcpy(memoria->assinatura, "FORCA-SHM");
        memoria->versao = 2;
    }

    void fechar() {
        disponivel = false;
        if (memoria) {
            UnmapViewOfFile(memoria);
            memoria = NULL;
        }
        if (mutex) {
            CloseHandle(mutex);
            mutex = NULL;
        }
        if (mapa) {
            CloseHandle(mapa);
            mapa = NULL;
        }
    }
};
#else
class MemoriaCompartilhada {
public:
    bool criarComoServidor() { return false; }
    bool abrirComoClienteMesmoPC() { return false; }
    bool criarEspelhoLocal() { return false; }
    bool ativa() const { return false; }
};
#endif

#ifdef _WIN32
void fecharSocket(socket_t s) {
    if (s != INVALID_SOCKET) closesocket(s);
}
#else
void fecharSocket(socket_t s) {
    if (s >= 0) close(s);
}
#endif

void limparTela() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

void pausar() {
    cout << "\nPressione Enter para continuar...";
    string lixo;
    getline(cin, lixo);
}

void inicializarSockets() {
#ifdef _WIN32
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        cerr << "Erro ao iniciar o Winsock.\n";
        exit(1);
    }
#endif
}

void finalizarSockets() {
#ifdef _WIN32
    WSACleanup();
#endif
}

bool enviarTudo(socket_t s, const string& texto) {
    size_t enviado = 0;
    while (enviado < texto.size()) {
#ifdef _WIN32
        int n = send(s, texto.c_str() + enviado, static_cast<int>(texto.size() - enviado), 0);
#else
        ssize_t n = send(s, texto.c_str() + enviado, texto.size() - enviado, 0);
#endif
        if (n <= 0) return false;
        enviado += static_cast<size_t>(n);
    }
    return true;
}

bool enviarLinha(socket_t s, const string& linha) {
    return enviarTudo(s, linha + "\n");
}

bool receberLinha(socket_t s, string& linha) {
    linha.clear();
    char c;

    while (true) {
#ifdef _WIN32
        int n = recv(s, &c, 1, 0);
#else
        ssize_t n = recv(s, &c, 1, 0);
#endif
        if (n <= 0) return false;
        if (c == '\n') break;
        if (c != '\r') linha += c;
        if (linha.size() > 4096) return false;
    }
    return true;
}

string normalizar(const string& entrada) {
    string s;
    for (size_t i = 0; i < entrada.size(); ++i) {
        unsigned char c = static_cast<unsigned char>(entrada[i]);
        if (isalnum(c)) s += static_cast<char>(tolower(c));
    }
    return s;
}

char normalizarLetra(char c) {
    return static_cast<char>(tolower(static_cast<unsigned char>(c)));
}

string lerNome(const string& mensagem) {
    string nome;
    cout << mensagem;
    getline(cin, nome);
    if (nome.empty()) nome = "Jogador";
    if (nome.size() > MAX_NOME) nome.resize(MAX_NOME);
    for (size_t i = 0; i < nome.size(); ++i) {
        if (nome[i] == '|') nome[i] = '_';
    }
    return nome;
}

char lerLetraLocal() {
    while (true) {
        cout << "\nDigite UMA letra: ";
        string entrada;
        getline(cin, entrada);
        if (entrada.size() == 1 && isalpha(static_cast<unsigned char>(entrada[0])))
            return normalizarLetra(entrada[0]);
        cout << "Digite somente uma letra.\n";
    }
}

string lerPalavraLocal() {
    while (true) {
        cout << "\nDigite a PALAVRA inteira: ";
        string entrada;
        getline(cin, entrada);
        string palavra = normalizar(entrada);
        if (!palavra.empty()) return palavra;
        cout << "Digite uma palavra valida.\n";
    }
}

bool lerSimNaoLocal(const string& mensagem) {
    while (true) {
        cout << "\n" << mensagem << "\n";
        cout << "1 - Sim\n";
        cout << "2 - Nao\n";
        cout << "Escolha: ";
        string opcao;
        getline(cin, opcao);
        if (opcao == "1") return true;
        if (opcao == "2") return false;
        cout << "Escolha invalida. Digite 1 ou 2.\n";
    }
}

const vector<string> listaPalavras = {
    "computador", "programacao", "linguagem", "teclado", "monitor",
    "internet", "jogo", "variavel", "ponteiro", "memoria", "palavra",
    "injogavel", "cs2", "minhoca", "nome", "duque", "bola", "cubo",
    "naruto", "goku", "nariz", "legal", "lapis", "visualg", "python",
    "elefante", "girafa", "canguru", "tubarao", "arara", "leao", "coruja",
    "camaleao", "abacaxi", "morango", "laranja", "uva", "banana", "manga",
    "kiwi", "melancia", "brasil", "canada", "japao", "franca", "india",
    "egito", "italia", "mexico", "medico", "professor", "engenheiro",
    "advogado", "enfermeiro", "arquiteto", "jornalista", "cozinheiro",
    "vermelho", "azul", "amarelo", "verde", "roxo", "preto", "branco"
};

string sortearPalavra() {
    static mt19937 gerador(static_cast<unsigned int>(
        chrono::high_resolution_clock::now().time_since_epoch().count()));
    uniform_int_distribution<size_t> dist(0, listaPalavras.size() - 1);
    return listaPalavras[dist(gerador)];
}

struct EstadoJogo {
    string palavra;             // no servidor = real; no cliente = mascarada
    string letrasUsadas;
    int erros[2];
    int turno;
    int pontos[2];
    bool terminou;
    bool venceu;
    int vencedor;
    int letrasRestantes;
    bool vitoriaPorPalavra;

    EstadoJogo() {
        erros[0] = 0;
        erros[1] = 0;
        turno = 0;
        pontos[0] = 0;
        pontos[1] = 0;
        terminou = false;
        venceu = false;
        vencedor = -1;
        letrasRestantes = 0;
        vitoriaPorPalavra = false;
    }
};

bool contem(const string& texto, char c) {
    return texto.find(c) != string::npos;
}

string letrasUnicas(const string& texto) {
    string resultado;
    for (size_t i = 0; i < texto.size(); ++i) {
        char c = normalizarLetra(texto[i]);
        if (isalpha(static_cast<unsigned char>(c)) && !contem(resultado, c)) {
            resultado += c;
        }
    }
    return resultado;
}

string mascararPalavra(const string& palavra, const string& usadas) {
    // A mascara e armazenada SEM espacos.
    // Os espacos sao adicionados somente na hora de desenhar a tela.
    // Isso impede que o estado recebido pelo PC 2 seja formatado duas vezes.
    string resultado;
    for (size_t i = 0; i < palavra.size(); ++i) {
        char c = palavra[i];
        if (contem(usadas, c)) resultado += c;
        else resultado += '_';
    }
    return resultado;
}

string compactarPalavraVisivel(const string& texto) {
    string resultado;
    for (size_t i = 0; i < texto.size(); ++i) {
        if (texto[i] != ' ' && texto[i] != '\t' && texto[i] != '\r' && texto[i] != '\n') {
            resultado += texto[i];
        }
    }
    return resultado;
}

void imprimirPalavraFormatada(const string& palavraCompacta) {
    string palavra = compactarPalavraVisivel(palavraCompacta);
    for (size_t i = 0; i < palavra.size(); ++i) {
        if (i > 0) cout << ' ';
        cout << palavra[i];
    }
}

int letrasRestantesDiferentes(const string& palavra, const string& usadas) {
    string faltando;
    for (size_t i = 0; i < palavra.size(); ++i) {
        char c = palavra[i];
        if (!contem(usadas, c) && !contem(faltando, c)) faltando += c;
    }
    return static_cast<int>(faltando.size());
}

bool palavraCompleta(const EstadoJogo& e) {
    return letrasRestantesDiferentes(e.palavra, e.letrasUsadas) == 0;
}

bool faseFinal(const EstadoJogo& e) {
    return e.letrasRestantes > 0 && e.letrasRestantes <= LETRAS_PARA_FASE_FINAL;
}

void mostrarPersonagemTime1(int erros) {
    const char* desenho[] = {
        "  +---+\n  |   |\n      |\n      |\n      |\n=========",
        "  +---+\n  |   |\n  O   |\n      |\n      |\n=========",
        "  +---+\n  |   |\n  O   |\n  |   |\n      |\n=========",
        "  +---+\n  |   |\n  O   |\n /|   |\n      |\n=========",
        "  +---+\n  |   |\n  O   |\n /|\\  |\n      |\n=========",
        "  +---+\n  |   |\n  O   |\n /|\\  |\n /    |\n=========",
        "  +---+\n  |   |\n  O   |\n /|\\  |\n / \\  |\n=========",
        "  +---+\n  |   |\n _O   |\n /|\\  |\n / \\  |\n=========",
        "  +---+\n  |   |\n  X   |\n /|\\  |\n / \\  |\n========="
    };
    if (erros < 0) erros = 0;
    if (erros > MAX_TENTATIVAS) erros = MAX_TENTATIVAS;
    cout << desenho[erros] << "\n";
}

void mostrarPersonagemTime2(int erros) {
    const char* desenho[] = {
        "  .---.\n  |   |\n      |\n      |\n      |\n=========",
        "  .---.\n  |   |\n  o   |\n      |\n      |\n=========",
        "  .---.\n  |   |\n [o]  |\n      |\n      |\n=========",
        "  .---.\n  |   |\n [o]  |\n  |   |\n      |\n=========",
        "  .---.\n  |   |\n [o]  |\n /|   |\n      |\n=========",
        "  .---.\n  |   |\n [o]  |\n /|\\  |\n      |\n=========",
        "  .---.\n  |   |\n [o]  |\n /|\\  |\n /    |\n=========",
        "  .---.\n  |   |\n [o]  |\n /|\\  |\n / \\  |\n=========",
        "  .---.\n  |   |\n [x]  |\n /|\\  |\n / \\  |\n========="
    };
    if (erros < 0) erros = 0;
    if (erros > MAX_TENTATIVAS) erros = MAX_TENTATIVAS;
    cout << desenho[erros] << "\n";
}

void mostrarEstado(const string& nome1, const string& nome2, const EstadoJogo& e,
                   bool revelarPalavra) {
    limparTela();
    cout << "==================================================\n";
    cout << "          JOGO DA FORCA MULTIPLAYER              \n";
    cout << "==================================================\n\n";

    cout << "TIME 1 - " << nome1 << "\n";
    mostrarPersonagemTime1(e.erros[0]);
    cout << "Erros: " << e.erros[0] << "/" << MAX_TENTATIVAS << "\n\n";

    cout << "TIME 2 - " << nome2 << "\n";
    mostrarPersonagemTime2(e.erros[1]);
    cout << "Erros: " << e.erros[1] << "/" << MAX_TENTATIVAS << "\n\n";

    cout << "--------------------------------------------------\n";
    cout << "Palavra: ";
    if (revelarPalavra) {
        cout << e.palavra;
    } else {
        // O estado mascarado e normalizado antes de exibir.
        // Assim, cada posicao aparece exatamente uma vez no PC 1 e no PC 2.
        imprimirPalavraFormatada(e.palavra);
    }
    cout << "\n";

    cout << "Letras usadas: ";
    if (e.letrasUsadas.empty()) cout << "(nenhuma)";
    else for (size_t i = 0; i < e.letrasUsadas.size(); ++i) cout << e.letrasUsadas[i] << ' ';

    cout << "\n\nPLACAR\n";
    cout << nome1 << ": " << e.pontos[0] << " pontos\n";
    cout << nome2 << ": " << e.pontos[1] << " pontos\n";

    if (!e.terminou) {
        cout << "\nTurno: " << (e.turno == 0 ? nome1 : nome2) << "\n";
        if (faseFinal(e)) {
            cout << "\n*** FASE FINAL: restam " << e.letrasRestantes
                 << " letras diferentes! ***\n";
            cout << "O jogador da vez pode chutar a palavra inteira ou uma letra.\n";
        }
    }
}

string estadoMascaradoDoServidor(const EstadoJogo& e) {
    return mascararPalavra(e.palavra, e.letrasUsadas);
}

string serializarEstado(const EstadoJogo& e, const string& palavraVisivel) {
    // STATE|palavraVisivel|letras|err1|err2|turno|p1|p2|fim|venceu|vencedor|restantes|vitoriaPalavra
    ostringstream out;
    out << "STATE|"
        << palavraVisivel << "|"
        << e.letrasUsadas << "|"
        << e.erros[0] << "|"
        << e.erros[1] << "|"
        << e.turno << "|"
        << e.pontos[0] << "|"
        << e.pontos[1] << "|"
        << (e.terminou ? 1 : 0) << "|"
        << (e.venceu ? 1 : 0) << "|"
        << e.vencedor << "|"
        << e.letrasRestantes << "|"
        << (e.vitoriaPorPalavra ? 1 : 0);
    return out.str();
}

bool dividir(const string& linha, vector<string>& partes) {
    partes.clear();
    string atual;
    for (size_t i = 0; i < linha.size(); ++i) {
        if (linha[i] == '|') {
            partes.push_back(atual);
            atual.clear();
        } else atual += linha[i];
    }
    partes.push_back(atual);
    return true;
}

bool desserializarEstado(const string& linha, EstadoJogo& e) {
    vector<string> partes;
    dividir(linha, partes);
    if (partes.size() != 13 || partes[0] != "STATE") return false;

    e.palavra = compactarPalavraVisivel(partes[1]);
    e.letrasUsadas = letrasUnicas(partes[2]);
    e.erros[0] = atoi(partes[3].c_str());
    e.erros[1] = atoi(partes[4].c_str());
    e.turno = atoi(partes[5].c_str());
    e.pontos[0] = atoi(partes[6].c_str());
    e.pontos[1] = atoi(partes[7].c_str());
    e.terminou = atoi(partes[8].c_str()) != 0;
    e.venceu = atoi(partes[9].c_str()) != 0;
    e.vencedor = atoi(partes[10].c_str());
    e.letrasRestantes = atoi(partes[11].c_str());
    e.vitoriaPorPalavra = atoi(partes[12].c_str()) != 0;
    return true;
}

bool enviarEstado(socket_t cliente, const EstadoJogo& e) {
    return enviarLinha(cliente, serializarEstado(e, estadoMascaradoDoServidor(e)));
}

#ifdef _WIN32
void escreverMemoria(MemoriaCompartilhada& mem, const EstadoJogo& e,
                     const string& nome1, const string& nome2, LONG contador) {
    if (!mem.ativa()) return;
    SharedGameMemory dados;
    memset(&dados, 0, sizeof(dados));
    strcpy(dados.assinatura, "FORCA-SHM");
    dados.versao = 2;
    dados.atualizado = contador;
    dados.erros[0] = e.erros[0];
    dados.erros[1] = e.erros[1];
    dados.turno = e.turno;
    dados.pontos[0] = e.pontos[0];
    dados.pontos[1] = e.pontos[1];
    dados.terminou = e.terminou ? 1 : 0;
    dados.venceu = e.venceu ? 1 : 0;
    dados.vencedor = e.vencedor;
    dados.letrasRestantes = e.letrasRestantes;
    dados.vitoriaPorPalavra = e.vitoriaPorPalavra ? 1 : 0;
    strncpy(dados.palavraMascarada, estadoMascaradoDoServidor(e).c_str(), MAX_PALAVRA);
    strncpy(dados.letrasUsadas, e.letrasUsadas.c_str(), sizeof(dados.letrasUsadas) - 1);
    strncpy(dados.nome1, nome1.c_str(), sizeof(dados.nome1) - 1);
    strncpy(dados.nome2, nome2.c_str(), sizeof(dados.nome2) - 1);
    mem.escrever(dados);
}

bool lerMemoria(MemoriaCompartilhada& mem, EstadoJogo& e, string& nome1, string& nome2) {
    if (!mem.ativa()) return false;
    SharedGameMemory dados;
    if (!mem.ler(dados)) return false;
    if (strcmp(dados.assinatura, "FORCA-SHM") != 0) return false;

    e.palavra = compactarPalavraVisivel(dados.palavraMascarada);
    e.letrasUsadas = letrasUnicas(dados.letrasUsadas);
    e.erros[0] = dados.erros[0];
    e.erros[1] = dados.erros[1];
    e.turno = dados.turno;
    e.pontos[0] = dados.pontos[0];
    e.pontos[1] = dados.pontos[1];
    e.terminou = dados.terminou != 0;
    e.venceu = dados.venceu != 0;
    e.vencedor = dados.vencedor;
    e.letrasRestantes = dados.letrasRestantes;
    e.vitoriaPorPalavra = dados.vitoriaPorPalavra != 0;
    nome1 = dados.nome1;
    nome2 = dados.nome2;
    return true;
}
#else
void escreverMemoria(MemoriaCompartilhada&, const EstadoJogo&, const string&, const string&, long) {}
bool lerMemoria(MemoriaCompartilhada&, EstadoJogo&, string&, string&) { return false; }
#endif

void prepararNovaRodada(EstadoJogo& e, bool comecaTime2) {
    int pontos1 = e.pontos[0];
    int pontos2 = e.pontos[1];
    e = EstadoJogo();
    e.pontos[0] = pontos1;
    e.pontos[1] = pontos2;
    e.turno = comecaTime2 ? 1 : 0;
}

void anunciarResultado(const string& nome1, const string& nome2, const EstadoJogo& e) {
    cout << "\n==================================================\n";
    if (e.vitoriaPorPalavra) {
        cout << "PALAVRA INTEIRA ACERTADA!\n";
        cout << "Palavra: " << e.palavra << "\n";
        cout << "Vencedor da rodada: " << (e.vencedor == 0 ? nome1 : nome2) << "\n";
        cout << "Bonus: +" << BONUS_ACERTO_PALAVRA << " pontos\n";
    } else if (e.venceu) {
        cout << "PARABENS! A PALAVRA FOI DESCOBERTA!\n";
        cout << "Palavra: " << e.palavra << "\n";
        cout << "Vencedor da rodada: " << (e.vencedor == 0 ? nome1 : nome2) << "\n";
    } else {
        cout << "FIM DE JOGO! OS PERSONAGENS FORAM COMPLETADOS.\n";
        cout << "A palavra era: " << e.palavra << "\n";
    }
    cout << "\nPLACAR\n";
    cout << nome1 << ": " << e.pontos[0] << " pontos\n";
    cout << nome2 << ": " << e.pontos[1] << " pontos\n";
    if (e.pontos[0] > e.pontos[1]) cout << "\nLider: " << nome1 << "\n";
    else if (e.pontos[1] > e.pontos[0]) cout << "\nLider: " << nome2 << "\n";
    else cout << "\nEmpate no placar!\n";
    cout << "==================================================\n";
}

bool processarLetra(EstadoJogo& e, int jogador, char letra, bool* acertou, int* pontosGanhos) {
    letra = normalizarLetra(letra);
    if (!isalpha(static_cast<unsigned char>(letra))) return false;
    if (contem(e.letrasUsadas, letra)) return false;

    bool fase = faseFinal(e);
    e.letrasUsadas += letra;
    e.letrasRestantes = letrasRestantesDiferentes(e.palavra, e.letrasUsadas);
    *acertou = contem(e.palavra, letra);
    *pontosGanhos = 0;

    if (*acertou) {
        *pontosGanhos = fase ? BONUS_ACERTO_LETRA_FINAL : 3;
        e.pontos[jogador] += *pontosGanhos;
    } else {
        e.pontos[jogador] -= 1;
        e.erros[jogador]++;
    }

    if (palavraCompleta(e)) {
        e.terminou = true;
        e.venceu = true;
        e.vencedor = jogador;
        e.vitoriaPorPalavra = false;
    } else if (e.erros[0] >= MAX_TENTATIVAS || e.erros[1] >= MAX_TENTATIVAS) {
        // O time cujo personagem foi completado perde a rodada.
        e.terminou = true;
        e.venceu = false;
        e.vencedor = (e.erros[0] >= MAX_TENTATIVAS) ? 1 : 0;
    } else {
        e.turno = 1 - e.turno;
    }
    return true;
}

void enviarFimERematch(socket_t cliente, const EstadoJogo& e) {
    enviarEstado(cliente, e);
    enviarLinha(cliente, "RESULT|" + e.palavra);
    enviarLinha(cliente, "REMATCH_PROMPT|Deseja jogar outra rodada?");
}

bool servidorEsperarRematch(socket_t cliente, bool querRematchLocal, bool& querRematchCliente) {
    string linha;
    querRematchCliente = false;
    if (!receberLinha(cliente, linha)) return false;
    if (linha.rfind("REMATCH|", 0) != 0) return false;
    querRematchCliente = (linha.substr(8) == "1");
    if (querRematchLocal && querRematchCliente) {
        enviarLinha(cliente, "REMATCH_RESULT|1");
        return true;
    }
    enviarLinha(cliente, "REMATCH_RESULT|0");
    return false;
}

void servidor() {
    limparTela();
    cout << "=============================================\n";
    cout << "           SERVIDOR - JOGO DA FORCA         \n";
    cout << "=============================================\n\n";

    string nome1 = lerNome("Nome do Time 1: ");
    EstadoJogo estado;
    estado.palavra = sortearPalavra();
    estado.letrasRestantes = letrasRestantesDiferentes(estado.palavra, estado.letrasUsadas);

    MemoriaCompartilhada memoria;
#ifdef _WIN32
    if (memoria.criarComoServidor()) {
        cout << "Memoria compartilhada: ATIVA.\n";
    } else {
        cout << "Memoria compartilhada: nao foi possivel ativar.\n";
    }
#endif

    socket_t servidorSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (servidorSocket == INVALID_SOCKET_VALUE) {
        cerr << "Erro ao criar socket do servidor.\n";
        return;
    }

#ifdef _WIN32
    BOOL reutilizar = TRUE;
    setsockopt(servidorSocket, SOL_SOCKET, SO_REUSEADDR,
               reinterpret_cast<const char*>(&reutilizar), sizeof(reutilizar));
#else
    int reutilizar = 1;
    setsockopt(servidorSocket, SOL_SOCKET, SO_REUSEADDR, &reutilizar, sizeof(reutilizar));
#endif

    sockaddr_in endereco;
    memset(&endereco, 0, sizeof(endereco));
    endereco.sin_family = AF_INET;
    endereco.sin_addr.s_addr = htonl(INADDR_ANY);
    endereco.sin_port = htons(PORTA);

    if (bind(servidorSocket, reinterpret_cast<sockaddr*>(&endereco), sizeof(endereco)) < 0) {
        cerr << "Nao foi possivel abrir a porta " << PORTA << ".\n";
        fecharSocket(servidorSocket);
        return;
    }
    if (listen(servidorSocket, 1) < 0) {
        cerr << "Erro ao colocar o servidor em espera.\n";
        fecharSocket(servidorSocket);
        return;
    }

    cout << "Servidor iniciado na porta " << PORTA << ".\n";
    cout << "Aguardando o Time 2 conectar...\n";

    sockaddr_in clienteEndereco;
    memset(&clienteEndereco, 0, sizeof(clienteEndereco));
#ifdef _WIN32
    int tamanhoEndereco = sizeof(clienteEndereco);
#else
    socklen_t tamanhoEndereco = sizeof(clienteEndereco);
#endif

    socket_t cliente = accept(servidorSocket,
                              reinterpret_cast<sockaddr*>(&clienteEndereco),
                              &tamanhoEndereco);
    if (cliente == INVALID_SOCKET_VALUE) {
        cerr << "Erro ao aceitar conexao.\n";
        fecharSocket(servidorSocket);
        return;
    }

    string hello;
    if (!receberLinha(cliente, hello) || hello.rfind("HELLO|", 0) != 0) {
        cerr << "O cliente nao enviou o nome corretamente.\n";
        fecharSocket(cliente);
        fecharSocket(servidorSocket);
        return;
    }

    string nome2 = hello.substr(6);
    if (nome2.empty()) nome2 = "Time 2";
    if (nome2.size() > MAX_NOME) nome2.resize(MAX_NOME);

    if (!enviarLinha(cliente, "NAMES|" + nome1 + "|" + nome2) || !enviarEstado(cliente, estado)) {
        fecharSocket(cliente);
        fecharSocket(servidorSocket);
        return;
    }

#ifdef _WIN32
    LONG contadorMemoria = 1;
    escreverMemoria(memoria, estado, nome1, nome2, contadorMemoria);
#endif

    bool conectado = true;
    bool proximoComecaTime2 = false;

    while (conectado) {
        while (!estado.terminou) {
            int jogador = estado.turno;
            string visual = estadoMascaradoDoServidor(estado);
            EstadoJogo tela = estado;
            tela.palavra = visual;
            mostrarEstado(nome1, nome2, tela, false);

            char letra = '\0';
            bool acertou = false;
            int pontosGanhos = 0;

            if (jogador == 0) {
                cout << "\nSua vez, " << nome1 << "!\n";

                if (faseFinal(estado)) {
                    cout << "\nFASE FINAL! Restam " << estado.letrasRestantes << " letras diferentes.\n";
                    cout << "1 - Chutar a palavra inteira (+5 se acertar)\n";
                    cout << "2 - Chutar uma letra (+5 se acertar)\n";
                    string opcao;
                    do {
                        cout << "Escolha: ";
                        getline(cin, opcao);
                    } while (opcao != "1" && opcao != "2");

                    if (opcao == "1") {
                        string palpite = lerPalavraLocal();
                        if (palpite == estado.palavra) {
                            estado.pontos[0] += BONUS_ACERTO_PALAVRA;
                            estado.terminou = true;
                            estado.venceu = true;
                            estado.vencedor = 0;
                            estado.vitoriaPorPalavra = true;
                            enviarLinha(cliente, "INFO|Time 1 acertou a palavra inteira! +5 pontos.");
                            enviarFimERematch(cliente, estado);
                        } else {
                            estado.pontos[0] -= 1;
                            estado.erros[0]++;
                            enviarLinha(cliente, "INFO|Time 1 errou a palavra inteira! -1 ponto e +1 erro.");
                            if (estado.erros[0] >= MAX_TENTATIVAS) {
                                estado.terminou = true;
                                estado.venceu = false;
                                estado.vencedor = 1;
                                enviarFimERematch(cliente, estado);
                            } else {
                                estado.turno = 1;
                                enviarEstado(cliente, estado);
                            }
                        }
#ifdef _WIN32
                        ++contadorMemoria;
                        escreverMemoria(memoria, estado, nome1, nome2, contadorMemoria);
#endif
                        continue;
                    }
                }

                letra = lerLetraLocal();
            } else {
                cout << "\nAguardando a jogada do " << nome2 << "...\n";
                string acao;
                if (!receberLinha(cliente, acao)) {
                    cout << "\nO outro jogador desconectou.\n";
                    conectado = false;
                    break;
                }

                if (acao.rfind("GUESSWORD|", 0) == 0) {
                    string palpite = normalizar(acao.substr(10));
                    if (faseFinal(estado) && palpite == estado.palavra) {
                        estado.pontos[1] += BONUS_ACERTO_PALAVRA;
                        estado.terminou = true;
                        estado.venceu = true;
                        estado.vencedor = 1;
                        estado.vitoriaPorPalavra = true;
                        enviarLinha(cliente, "INFO|Time 2 acertou a palavra inteira! +5 pontos.");
                        enviarFimERematch(cliente, estado);
                    } else {
                        estado.pontos[1] -= 1;
                        estado.erros[1]++;
                        enviarLinha(cliente, "INFO|Time 2 errou a palavra inteira! -1 ponto e +1 erro.");
                        if (estado.erros[1] >= MAX_TENTATIVAS) {
                            estado.terminou = true;
                            estado.venceu = false;
                            estado.vencedor = 0;
                            enviarFimERematch(cliente, estado);
                        } else {
                            estado.turno = 0;
                            enviarEstado(cliente, estado);
                        }
                    }
#ifdef _WIN32
                    ++contadorMemoria;
                    escreverMemoria(memoria, estado, nome1, nome2, contadorMemoria);
#endif
                    continue;
                }

                if (acao.rfind("GUESS|", 0) != 0 || acao.size() < 7) {
                    enviarLinha(cliente, "INFO|Jogada invalida.");
                    enviarEstado(cliente, estado);
                    continue;
                }
                letra = normalizarLetra(acao[6]);
            }

            letra = normalizarLetra(letra);
            if (!isalpha(static_cast<unsigned char>(letra))) {
                if (jogador == 1) enviarLinha(cliente, "INFO|Digite somente uma letra.");
                else cout << "Digite somente uma letra.\n";
                continue;
            }

            if (contem(estado.letrasUsadas, letra)) {
                string aviso = "A letra '" + string(1, letra) + "' ja foi usada. Escolha outra letra.";
                if (jogador == 1) {
                    enviarLinha(cliente, "INFO|" + aviso);
                    enviarEstado(cliente, estado);
                } else cout << "\n" << aviso << "\n";
                continue;
            }

            processarLetra(estado, jogador, letra, &acertou, &pontosGanhos);
            string resultado;
            if (acertou) {
                resultado = "INFO|Time " + to_string(jogador + 1) +
                            " acertou a letra '" + string(1, letra) +
                            "'! +" + to_string(pontosGanhos) + " pontos.";
            } else {
                resultado = "INFO|Time " + to_string(jogador + 1) +
                            " errou com a letra '" + string(1, letra) +
                            "'! -1 ponto.";
            }

            if (jogador == 0) cout << "\n" << resultado.substr(5) << "\n";

            if (!enviarLinha(cliente, resultado) || !enviarEstado(cliente, estado)) {
                conectado = false;
                break;
            }

#ifdef _WIN32
            ++contadorMemoria;
            escreverMemoria(memoria, estado, nome1, nome2, contadorMemoria);
#endif
        }

        if (!conectado) break;

        // Mostra o resultado ao servidor.
        EstadoJogo tela = estado;
        tela.palavra = estado.palavra;
        mostrarEstado(nome1, nome2, tela, true);
        anunciarResultado(nome1, nome2, estado);

        bool querDeNovo1 = lerSimNaoLocal("Deseja jogar novamente?");
        bool querDeNovo2 = false;
        if (!servidorEsperarRematch(cliente, querDeNovo1, querDeNovo2)) {
            cout << "\nPartida encerrada.\n";
            break;
        }

        proximoComecaTime2 = !proximoComecaTime2;
        prepararNovaRodada(estado, proximoComecaTime2);
        estado.palavra = sortearPalavra();
        estado.letrasRestantes = letrasRestantesDiferentes(estado.palavra, estado.letrasUsadas);
        enviarLinha(cliente, "NEW_ROUND|Nova rodada iniciada!");
        enviarEstado(cliente, estado);
#ifdef _WIN32
        ++contadorMemoria;
        escreverMemoria(memoria, estado, nome1, nome2, contadorMemoria);
#endif
    }

    fecharSocket(cliente);
    fecharSocket(servidorSocket);
}

bool clienteReceberFimERematch(socket_t cliente, EstadoJogo& estado,
                                string& nome1, string& nome2,
                                MemoriaCompartilhada& memoria) {
    string mensagem;

    if (!receberLinha(cliente, mensagem)) return false;
    if (mensagem.rfind("RESULT|", 0) == 0) estado.palavra = mensagem.substr(7);

    mostrarEstado(nome1, nome2, estado, true);
    anunciarResultado(nome1, nome2, estado);

    if (!receberLinha(cliente, mensagem)) return false;
    if (mensagem.rfind("REMATCH_PROMPT|", 0) != 0) return false;

    bool quer = lerSimNaoLocal("Deseja jogar novamente?");
    if (!enviarLinha(cliente, string("REMATCH|") + (quer ? "1" : "0"))) return false;

    if (!receberLinha(cliente, mensagem)) return false;
    if (mensagem != "REMATCH_RESULT|1") return false;

    if (!receberLinha(cliente, mensagem)) return false;
    if (mensagem.rfind("NEW_ROUND|", 0) != 0) return false;

    if (!receberLinha(cliente, mensagem)) return false;
    if (!desserializarEstado(mensagem, estado)) return false;

#ifdef _WIN32
    string n1 = nome1, n2 = nome2;
    EstadoJogo sh = estado;
    escreverMemoria(memoria, sh, n1, n2, GetTickCount());
#endif
    return true;
}

void cliente() {
    limparTela();
    cout << "=============================================\n";
    cout << "            CLIENTE - JOGO DA FORCA         \n";
    cout << "=============================================\n\n";

    string nome2 = lerNome("Nome do Time 2: ");
    string ip;
    cout << "IP do servidor (ex.: 192.168.0.10): ";
    getline(cin, ip);
    if (ip.empty()) ip = "127.0.0.1";

    MemoriaCompartilhada memoria;
#ifdef _WIN32
    bool mesmaMaquina = memoria.abrirComoClienteMesmoPC();
    if (!mesmaMaquina) {
        if (memoria.criarEspelhoLocal()) {
            cout << "Memoria compartilhada local: ATIVA (espelho para conexao remota).\n";
        }
    } else {
        cout << "Memoria compartilhada: ATIVA ENTRE OS DOIS PROCESSOS (mesmo PC).\n";
    }
#endif

    socket_t clienteSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clienteSocket == INVALID_SOCKET_VALUE) {
        cerr << "Erro ao criar socket do cliente.\n";
        return;
    }

    sockaddr_in endereco;
    memset(&endereco, 0, sizeof(endereco));
    endereco.sin_family = AF_INET;
    endereco.sin_port = htons(PORTA);

#ifdef _WIN32
    endereco.sin_addr.s_addr = inet_addr(ip.c_str());
    if (endereco.sin_addr.s_addr == INADDR_NONE) {
        cerr << "IP invalido.\n";
        fecharSocket(clienteSocket);
        return;
    }
#else
    if (inet_pton(AF_INET, ip.c_str(), &endereco.sin_addr) <= 0) {
        cerr << "IP invalido.\n";
        fecharSocket(clienteSocket);
        return;
    }
#endif

    cout << "\nConectando ao servidor...\n";
    if (connect(clienteSocket, reinterpret_cast<sockaddr*>(&endereco), sizeof(endereco)) < 0) {
        cerr << "Nao foi possivel conectar ao servidor.\n";
        fecharSocket(clienteSocket);
        return;
    }

    if (!enviarLinha(clienteSocket, "HELLO|" + nome2)) {
        fecharSocket(clienteSocket);
        return;
    }

    string mensagem;
    if (!receberLinha(clienteSocket, mensagem) || mensagem.rfind("NAMES|", 0) != 0) {
        fecharSocket(clienteSocket);
        return;
    }

    vector<string> nomes;
    dividir(mensagem, nomes);
    string nome1 = nomes.size() > 1 ? nomes[1] : "Time 1";

    EstadoJogo estado;
    if (!receberLinha(clienteSocket, mensagem) || !desserializarEstado(mensagem, estado)) {
        fecharSocket(clienteSocket);
        return;
    }

#ifdef _WIN32
    if (memoria.ativa()) escreverMemoria(memoria, estado, nome1, nome2, GetTickCount());
#endif

    bool conectado = true;
    while (conectado) {
#ifdef _WIN32
        // Quando os dois processos estao no mesmo PC, a memoria compartilhada
        // e a fonte local do estado exibido pelo cliente.
        if (memoria.ativa()) {
            string n1 = nome1, n2 = nome2;
            EstadoJogo copia;
            if (lerMemoria(memoria, copia, n1, n2)) {
                if (!copia.palavra.empty()) estado = copia;
                if (!n1.empty()) nome1 = n1;
                if (!n2.empty()) nome2 = n2;
            }
        }
#endif

        if (estado.terminou) {
            if (!clienteReceberFimERematch(clienteSocket, estado, nome1, nome2, memoria)) {
                conectado = false;
                break;
            }
            continue;
        }

        mostrarEstado(nome1, nome2, estado, false);

        if (estado.turno != 1) {
            cout << "Aguardando o Time 1 jogar...\n";
            if (!receberLinha(clienteSocket, mensagem)) {
                conectado = false;
                break;
            }

            if (mensagem.rfind("INFO|", 0) == 0) cout << "\n" << mensagem.substr(5) << "\n";
            if (!receberLinha(clienteSocket, mensagem)) {
                conectado = false;
                break;
            }
            if (!desserializarEstado(mensagem, estado)) {
                conectado = false;
                break;
            }
#ifdef _WIN32
            if (memoria.ativa()) escreverMemoria(memoria, estado, nome1, nome2, GetTickCount());
#endif
            continue;
        }

        cout << "\nSua vez, " << nome2 << "!\n";

        if (faseFinal(estado)) {
            cout << "\nFASE FINAL! Restam " << estado.letrasRestantes << " letras diferentes.\n";
            cout << "1 - Chutar a palavra inteira (+5 se acertar)\n";
            cout << "2 - Chutar uma letra (+5 se acertar)\n";
            string opcao;
            do {
                cout << "Escolha: ";
                getline(cin, opcao);
            } while (opcao != "1" && opcao != "2");

            if (opcao == "1") {
                string palpite = lerPalavraLocal();
                if (!enviarLinha(clienteSocket, "GUESSWORD|" + palpite)) {
                    conectado = false;
                    break;
                }
            } else {
                char letra = lerLetraLocal();
                if (!enviarLinha(clienteSocket, string("GUESS|") + letra)) {
                    conectado = false;
                    break;
                }
            }
        } else {
            char letra = lerLetraLocal();
            if (!enviarLinha(clienteSocket, string("GUESS|") + letra)) {
                conectado = false;
                break;
            }
        }

        if (!receberLinha(clienteSocket, mensagem)) {
            conectado = false;
            break;
        }
        if (mensagem.rfind("INFO|", 0) == 0) cout << "\n" << mensagem.substr(5) << "\n";

        if (!receberLinha(clienteSocket, mensagem)) {
            conectado = false;
            break;
        }
        if (!desserializarEstado(mensagem, estado)) {
            conectado = false;
            break;
        }
#ifdef _WIN32
        if (memoria.ativa()) escreverMemoria(memoria, estado, nome1, nome2, GetTickCount());
#endif
    }

    fecharSocket(clienteSocket);
}

int main() {
    setlocale(LC_ALL, "");
    inicializarSockets();

    while (true) {
        limparTela();
        cout << "=============================================\n";
        cout << "              JOGO DA FORCA                 \n";
        cout << "=============================================\n\n";
        cout << "1 - Criar servidor (Time 1)\n";
        cout << "2 - Entrar no servidor (Time 2)\n";
        cout << "3 - Sair\n\n";
        cout << "Escolha: ";

        string opcao;
        getline(cin, opcao);

        if (opcao == "1") servidor();
        else if (opcao == "2") cliente();
        else if (opcao == "3") break;
        else {
            cout << "Opcao invalida.\n";
            pausar();
        }
    }

    finalizarSockets();
    return 0;
}
