/*
    JOGO DA FORCA MULTIPLAYER  -  versao 3.0 (threads + mutex)
    Baseado no jogo da forca original de Joao Victor Dalbem e Guilherme Duque.

    Recursos:
      - Salas com CODIGO (ex.: K7QD), publicas ou privadas, de 2 a 6 jogadores
      - Ranking global salvo em arquivo (ranking.txt) e chat na sala
      - 13 categorias, 650+ palavras COM ACENTO e arquivo opcional palavras.txt
      - Interface colorida em modo texto, sons (beeps) e animacoes

    Comunicacao entre processos (Trabalho 02 - Sistemas Operacionais):
      - Sockets TCP (Winsock2 no Windows) entre os processos jogadores e o servidor.
      - Servidor concorrente com pthreads: 1 thread por jogador + thread de aceite
        + thread de relogio, todas sobre o MESMO estado de jogo em memoria
        compartilhada (salas, "turno"/vez, palavra, pontos, ranking).
      - Exclusao mutua com pthread_mutex_t: todo acesso ao estado compartilhado
        ocorre dentro da regiao critica (classe Trava, ver "MODELO DE CONCORRENCIA").
      - Protocolo de mensagens proprio (ver comentario "SERVIDOR"); a "vez" e
        replicada no cliente por meio da mensagem STATE|...|turno|...

    Novidades da 2.2:
      - Chutar a palavra inteira a QUALQUER momento (acerto vale mais quanto
        mais letras faltam; erro antes da fase final custa -3 pontos e +2 erros)
      - Tempo por jogada (quem estoura perde a vez)
      - Partida em rodadas: "melhor de N" ou "primeiro a X pontos", com tela de campeao
      - Modo "palavra do jogador" (um jogador escolhe a palavra, os outros adivinham)
      - Dificuldade por tamanho da palavra
      - Modo equipes (2x2 ou 3x3) com pontos somados
      - Espectadores, expulsar jogador e transferir o dono da sala
      - Reconexao: quem cai volta para a mesma sala sem perder pontos
      - Palavras acentuadas exibidas corretamente
      - Reacoes rapidas (/gg, /boa ...) e historico de chat maior

    Regras de pontuacao:
      - Letra correta: +3 (+5 na FASE FINAL, quando restam 2 letras diferentes ou menos)
      - Letra errada: -1 ponto e +1 erro
      - Palavra inteira correta: +5, mais +2 por letra diferente que ainda faltava
        alem de 2. Palavra errada: -1 e +1 erro na fase final, -3 e +2 erros antes dela.
      - Quem chega a 8 erros e eliminado da rodada.

    Compilar no Windows (MinGW / Dev-C++ 5.11):
      g++ jogo_forca_multiplayer.cpp -std=c++11 -O2 -static -static-libgcc -static-libstdc++ -pthread -o forca.exe -lws2_32

    Compilar no Linux/macOS:
      g++ jogo_forca_multiplayer.cpp -std=c++11 -O2 -pthread -o forca

    Este arquivo esta em UTF-8 (por causa das palavras com acento).
*/

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <deque>
#include <algorithm>
#include <sstream>
#include <fstream>
#include <random>
#include <chrono>
#include <cctype>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <clocale>
#include <pthread.h>   // threads POSIX (winpthreads no MinGW): uma thread por jogador conectado

#ifdef _WIN32
    #ifndef _WIN32_WINNT
        #define _WIN32_WINNT 0x0501
    #endif
    #ifndef WIN32_LEAN_AND_MEAN
        #define WIN32_LEAN_AND_MEAN
    #endif
    #ifndef NOMINMAX
        #define NOMINMAX
    #endif
    #include <winsock2.h>
    #include <ws2tcpip.h>
    #include <windows.h>
    #include <conio.h>
    typedef SOCKET socket_t;
    static const socket_t SOCK_INVALIDO = INVALID_SOCKET;
#else
    #include <sys/types.h>
    #include <sys/socket.h>
    #include <sys/select.h>
    #include <arpa/inet.h>
    #include <netinet/in.h>
    #include <netdb.h>
    #include <unistd.h>
    #include <fcntl.h>
    #include <termios.h>
    #include <signal.h>
    #include <errno.h>
    #include <sys/ioctl.h>
    typedef int socket_t;
    static const socket_t SOCK_INVALIDO = -1;
#endif

using namespace std;

// ============================================================================
//  CONSTANTES E CONFIGURACAO
// ============================================================================

static int g_porta = 54000;

static const int VERSAO_PROTOCOLO = 3;
static const int MAX_ERROS        = 8;
static const int MIN_JOGADORES    = 2;
static const int MAX_JOGADORES    = 6;
static const int PADRAO_JOGADORES = 4;
static const int MAX_NOME         = 16;
static const int FASE_FINAL_LETRAS = 2;
static const int PTS_LETRA        = 3;
static const int PTS_LETRA_FINAL  = 5;
static const int PTS_PALAVRA      = 5;
static const int PTS_ERRO         = 1;
static const int PTS_ERRO_PALAVRA_CEDO = 3;      // chute de palavra errado antes da fase final
static const int ERROS_PALAVRA_CEDO    = 2;
static const int PTS_BONUS_LETRA_FALTANDO = 2;   // por letra diferente alem da fase final
static const int PTS_MESTRE_VENCEU     = 10;     // mestre quando ninguem acerta
static const int MAX_ESPECTADORES = 8;
static const int MAX_INATIVO      = 3;           // tempos esgotados seguidos = eliminado
static const long long TOLERANCIA_QUEDA_MS = 120000;   // tempo para o jogador reconectar
static const long long PING_INTERVALO_MS   = 10000;
static const long long PING_LIMITE_MS      = 45000;
static const int TEMPO_PADRAO = 30;              // segundos por jogada (0 = sem limite)
static const int MAX_HISTORICO_SALA = 40;

struct Config {
    bool som, anim, cor, acentos;
    int chatLinhas;
    Config() : som(true), anim(true), cor(true), acentos(true), chatLinhas(6) {}
};
static Config cfg;

static bool g_ansi  = false;   // terminal aceita sequencias ANSI (cores, cursor)
static bool g_eof   = false;   // entrada padrao fechada
static bool g_ttyIn = false;   // entrada padrao e um terminal de verdade

// ============================================================================
//  UTILITARIOS DE TEXTO
// ============================================================================

static string itos(long v) {
    ostringstream o;
    o << v;
    return o.str();
}

static string paraMinusculas(const string& s) {
    string r = s;
    for (size_t i = 0; i < r.size(); ++i)
        r[i] = static_cast<char>(tolower(static_cast<unsigned char>(r[i])));
    return r;
}

static string paraMaiusculas(const string& s) {
    string r = s;
    for (size_t i = 0; i < r.size(); ++i)
        r[i] = static_cast<char>(toupper(static_cast<unsigned char>(r[i])));
    return r;
}

static string aparar(const string& s) {
    size_t a = 0, b = s.size();
    while (a < b && isspace(static_cast<unsigned char>(s[a]))) ++a;
    while (b > a && isspace(static_cast<unsigned char>(s[b - 1]))) --b;
    return s.substr(a, b - a);
}

static vector<string> dividir(const string& s, char sep) {
    vector<string> partes;
    string atual;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == sep) {
            partes.push_back(atual);
            atual.clear();
        } else {
            atual += s[i];
        }
    }
    partes.push_back(atual);
    return partes;
}

static bool contem(const string& texto, char c) {
    return texto.find(c) != string::npos;
}

// Converte um codigo Unicode Latin-1 (acentuado) na letra base. 0 = nao e acentuada.
static char letraBaseLatin1(int cp) {
    if (cp >= 0xC0 && cp <= 0xDE && cp != 0xD7) cp += 0x20;   // maiuscula -> minuscula
    if (cp >= 0xE0 && cp <= 0xE5) return 'a';
    if (cp == 0xE7) return 'c';
    if (cp >= 0xE8 && cp <= 0xEB) return 'e';
    if (cp >= 0xEC && cp <= 0xEF) return 'i';
    if (cp == 0xF1) return 'n';
    if (cp >= 0xF2 && cp <= 0xF6) return 'o';
    if (cp >= 0xF9 && cp <= 0xFC) return 'u';
    if (cp == 0xFD || cp == 0xFF) return 'y';
    return 0;
}

#ifdef _WIN32
// Letra base de um caractere do console do Windows em portugues (CP850). 0 = nao e letra acentuada.
static char letraBaseOEM850(int c) {
    switch (c) {
        case 0x80: case 0x87: return 'c';
        case 0x81: case 0x96: case 0x97: case 0x9A: case 0xA3: case 0xEA: case 0xE9: case 0xEB: return 'u';
        case 0x82: case 0x88: case 0x89: case 0x8A: case 0x90: case 0xD2: case 0xD3: case 0xD4: return 'e';
        case 0x83: case 0x84: case 0x85: case 0x86: case 0x8E: case 0x8F: case 0xA0:
        case 0xB5: case 0xB6: case 0xB7: case 0xC6: case 0xC7: return 'a';
        case 0x8B: case 0x8C: case 0x8D: case 0xA1: case 0xD6: case 0xD7: case 0xD8: case 0xDE: return 'i';
        case 0x93: case 0x94: case 0x95: case 0x99: case 0xA2: case 0xE0: case 0xE2: case 0xE3:
        case 0xE4: case 0xE5: return 'o';
        case 0xA4: case 0xA5: return 'n';
        default: return 0;
    }
}

#endif

// Remove acentos (UTF-8) e descarta qualquer byte nao-ASCII restante.
static string dobrarAcentos(const string& s) {
    string r;
    for (size_t i = 0; i < s.size(); ++i) {
        unsigned char c = static_cast<unsigned char>(s[i]);
        if (c < 0x80) {
            r += static_cast<char>(c);
        } else if (c == 0xC3 && i + 1 < s.size()) {
            unsigned char d = static_cast<unsigned char>(s[i + 1]);
            char b = letraBaseLatin1(0xC0 | (d & 0x3F));
            if (b) {
                // preserva maiuscula/minuscula original
                bool maiuscula = (d < 0xA0);
                r += maiuscula ? static_cast<char>(toupper(b)) : b;
            }
            ++i;
        }
        // demais bytes >= 0x80 sao descartados
    }
    return r;
}

// Texto seguro para trafegar na rede e aparecer na tela: ASCII imprimivel, sem '|'.
static string sanitizarTexto(const string& entrada, size_t maximo) {
    string base = dobrarAcentos(entrada);
    string r;
    for (size_t i = 0; i < base.size(); ++i) {
        unsigned char c = static_cast<unsigned char>(base[i]);
        if (c < 32 || c > 126) continue;
        if (c == '|') c = '/';
        r += static_cast<char>(c);
    }
    r = aparar(r);
    if (r.size() > maximo) r.resize(maximo);
    return aparar(r);
}

static string sanitizarNome(const string& entrada) {
    string r = sanitizarTexto(entrada, MAX_NOME);
    string limpo;
    for (size_t i = 0; i < r.size(); ++i)
        if (r[i] != '>' && r[i] != '<') limpo += r[i];
    return aparar(limpo);
}

// Somente letras a-z minusculas (acentos removidos).
static string normalizarPalavra(const string& entrada) {
    string base = dobrarAcentos(entrada);
    string r;
    for (size_t i = 0; i < base.size(); ++i) {
        unsigned char c = static_cast<unsigned char>(base[i]);
        if (isalpha(c)) r += static_cast<char>(tolower(c));
    }
    return r;
}


// ---- UTF-8 / acentos -----------------------------------------------------------

// Divide um texto UTF-8 em caracteres (cada item pode ter 1 a 4 bytes).
static vector<string> glifosUtf8(const string& s) {
    vector<string> r;
    for (size_t i = 0; i < s.size();) {
        unsigned char c = static_cast<unsigned char>(s[i]);
        size_t n = 1;
        if (c >= 0xF0) n = 4;
        else if (c >= 0xE0) n = 3;
        else if (c >= 0xC0) n = 2;
        if (i + n > s.size()) n = s.size() - i;
        r.push_back(s.substr(i, n));
        i += n;
    }
    return r;
}

// Letra base minuscula (a-z) de um caractere; 0 se nao for letra.
static char baseDoGlifo(const string& g) {
    string f = dobrarAcentos(g);
    if (f.size() == 1 && isalpha(static_cast<unsigned char>(f[0])))
        return static_cast<char>(tolower(static_cast<unsigned char>(f[0])));
    return 0;
}

static string maiusculaGlifo(const string& g) {
    if (g.size() == 1) return string(1, static_cast<char>(toupper(static_cast<unsigned char>(g[0]))));
    if (g.size() == 2 && static_cast<unsigned char>(g[0]) == 0xC3) {
        unsigned char b = static_cast<unsigned char>(g[1]);
        if (b >= 0xA0 && b <= 0xBE && b != 0xB7) return string("\xC3") + static_cast<char>(b - 0x20);
    }
    return g;
}

static string maiusculaUtf8(const string& s) {
    vector<string> v = glifosUtf8(s);
    string r;
    for (size_t i = 0; i < v.size(); ++i) r += maiusculaGlifo(v[i]);
    return r;
}

static string minusculaUtf8(const string& s) {
    vector<string> v = glifosUtf8(s);
    string r;
    for (size_t i = 0; i < v.size(); ++i) {
        const string& g = v[i];
        if (g.size() == 1) r += static_cast<char>(tolower(static_cast<unsigned char>(g[0])));
        else if (g.size() == 2 && static_cast<unsigned char>(g[0]) == 0xC3 &&
                 static_cast<unsigned char>(g[1]) >= 0x80 && static_cast<unsigned char>(g[1]) <= 0x9E &&
                 static_cast<unsigned char>(g[1]) != 0x97)
            r += string("\xC3") + static_cast<char>(static_cast<unsigned char>(g[1]) + 0x20);
        else r += g;
    }
    return r;
}

// Palavra para EXIBIR: letras (com acento), espaco e hifen, em minuscula.
// Remove tudo o mais e limita o tamanho.
static string sanitizarExibicao(const string& entrada, size_t maximoGlifos) {
    vector<string> v = glifosUtf8(minusculaUtf8(entrada));
    string r;
    size_t n = 0;
    bool ultimoEspaco = true;
    for (size_t i = 0; i < v.size() && n < maximoGlifos; ++i) {
        const string& g = v[i];
        if (g == " " || g == "\t") {
            if (!ultimoEspaco) { r += ' '; ++n; ultimoEspaco = true; }
        } else if (g == "-") {
            if (!ultimoEspaco) { r += '-'; ++n; ultimoEspaco = true; }
        } else if (baseDoGlifo(g) != 0) {
            r += g; ++n; ultimoEspaco = false;
        }
    }
    while (!r.empty() && (r[r.size() - 1] == ' ' || r[r.size() - 1] == '-')) r.erase(r.size() - 1);
    return r;
}

// ============================================================================
//  ALEATORIO
// ============================================================================

static mt19937& gerador() {
    static mt19937 g(static_cast<unsigned int>(
        chrono::high_resolution_clock::now().time_since_epoch().count()));
    return g;
}

static int sortear(int n) {   // 0 .. n-1
    if (n <= 1) return 0;
    uniform_int_distribution<int> d(0, n - 1);
    return d(gerador());
}

// ============================================================================
//  TERMINAL: tempo, tela, cores, teclado nao-bloqueante, sons
// ============================================================================


static long long agoMs() {
    return static_cast<long long>(chrono::duration_cast<chrono::milliseconds>(
        chrono::steady_clock::now().time_since_epoch()).count());
}

static void dormir(int ms) {
#ifdef _WIN32
    Sleep(static_cast<DWORD>(ms));
#else
    usleep(static_cast<useconds_t>(ms) * 1000);
#endif
}

#ifndef _WIN32
static struct termios g_termiosOriginal;
static bool g_termiosSalvo = false;

static void restaurarTerminal() {
    if (g_termiosSalvo) tcsetattr(0, TCSANOW, &g_termiosOriginal);
}

static void aoReceberSinal(int sig) {
    restaurarTerminal();
    if (g_ansi) {
        const char* r = "\x1b[0m\n";
        ssize_t ignorado = write(1, r, strlen(r));
        (void)ignorado;
    }
    _exit(128 + sig);
}
#endif

static void iniciarTerminal() {
#ifdef _WIN32
    g_ttyIn = true;
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD modo = 0;
    if (h != INVALID_HANDLE_VALUE && GetConsoleMode(h, &modo)) {
        // 0x0004 = ENABLE_VIRTUAL_TERMINAL_PROCESSING (Windows 10+)
        if (SetConsoleMode(h, modo | 0x0004)) g_ansi = true;
    }
    if (g_ansi) SetConsoleOutputCP(65001);   // UTF-8: palavras acentuadas
    cfg.acentos = g_ansi;                     // consoles antigos nao mostram UTF-8 direito
#else
    g_ttyIn = isatty(0) != 0;
    g_ansi = isatty(1) != 0;
    if (getenv("FORCA_ANSI")) g_ansi = true;
    if (g_ttyIn && tcgetattr(0, &g_termiosOriginal) == 0) {
        g_termiosSalvo = true;
        struct termios raw = g_termiosOriginal;
        raw.c_lflag &= ~(ICANON | ECHO);
        raw.c_cc[VMIN] = 1;
        raw.c_cc[VTIME] = 0;
        tcsetattr(0, TCSANOW, &raw);
        atexit(restaurarTerminal);
    }
    signal(SIGINT, aoReceberSinal);
    signal(SIGTERM, aoReceberSinal);
    signal(SIGPIPE, SIG_IGN);
    cfg.acentos = true;
#endif
    if (getenv("FORCA_SEM_COR")) cfg.cor = false;
    if (getenv("FORCA_SEM_ACENTO")) cfg.acentos = false;
}

// Aplica estilo ANSI ("1;31" = negrito vermelho). Sem ANSI devolve o texto puro.
static string estilo(const string& s, const char* codigos) {
    if (!g_ansi || !cfg.cor) return s;
    return string("\x1b[") + codigos + "m" + s + "\x1b[0m";
}

static const char* COR_JOGADOR[MAX_JOGADORES] = {
    "1;36", "1;33", "1;35", "1;32", "1;34", "1;37"
};

// Preenche/corta para largura fixa (somente texto sem escapes!)
static string pad(const string& s, size_t largura) {
    if (s.size() >= largura) return s.substr(0, largura);
    return s + string(largura - s.size(), ' ');
}

static string centralizar(const string& s, size_t largura) {
    if (s.size() >= largura) return s;
    size_t esq = (largura - s.size()) / 2;
    return string(esq, ' ') + s;
}

// Desenha um quadro completo. Com ANSI sobrescreve a tela sem piscar.
static void desenhar(const string& quadro) {
    if (g_ansi) {
        string saida = "\x1b[H";
        for (size_t i = 0; i < quadro.size(); ++i) {
            if (quadro[i] == '\n') saida += "\x1b[K\n";
            else saida += quadro[i];
        }
        saida += "\x1b[J";
        cout << saida << flush;
    } else {
#ifdef _WIN32
        system("cls");
#else
        cout << "\n--------------------------------------------------\n";
#endif
        cout << quadro << flush;
    }
}

static void limparTelaTotal() {
    if (g_ansi) cout << "\x1b[2J\x1b[H" << flush;
    else {
#ifdef _WIN32
        system("cls");
#endif
    }
}

// Altura (linhas) da janela do terminal.
static int alturaTerminal() {
#ifdef _WIN32
    CONSOLE_SCREEN_BUFFER_INFO info;
    if (GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &info))
        return info.srWindow.Bottom - info.srWindow.Top + 1;
    return 38;
#else
    struct winsize ws;
    if (ioctl(1, TIOCGWINSZ, &ws) == 0 && ws.ws_row > 0) return ws.ws_row;
    return 38;
#endif
}

// ---- Sons ------------------------------------------------------------------

enum TipoSom { SOM_ACERTO, SOM_ERRO, SOM_VEZ, SOM_VITORIA, SOM_DERROTA, SOM_CHAT, SOM_ENTRAR };

static void tom(int freq, int ms) {
#ifdef _WIN32
    Beep(static_cast<DWORD>(freq), static_cast<DWORD>(ms));
#else
    (void)freq; (void)ms;
#endif
}

static void tocarSom(TipoSom t) {
    if (!cfg.som) return;
    switch (t) {
        case SOM_ACERTO:  tom(880, 70); tom(1175, 90); break;
        case SOM_ERRO:    tom(220, 160); break;
        case SOM_VEZ:     tom(1000, 60); break;
        case SOM_VITORIA: tom(784, 90); tom(988, 90); tom(1175, 90); tom(1568, 200); break;
        case SOM_DERROTA: tom(392, 150); tom(330, 150); tom(262, 300); break;
        case SOM_CHAT:    tom(1400, 40); break;
        case SOM_ENTRAR:  tom(660, 60); tom(880, 60); break;
    }
#ifndef _WIN32
    if (g_ansi) { cout << '\a' << flush; }   // sino do terminal
#endif
}

// ---- Teclado nao-bloqueante ---------------------------------------------------

class Teclado {
public:
    string buf;
    bool oculto;     // true: mostra * no lugar do que e digitado (palavra secreta)

    Teclado() : oculto(false) {}

    // Texto do que foi digitado, como deve aparecer na tela.
    string visivel() const {
        if (!oculto) return buf;
        return string(glifosUtf8(buf).size(), '*');
    }

    void ecoar(char c) {
        if (oculto) {
            if ((static_cast<unsigned char>(c) & 0xC0) == 0x80) return;   // continuacao de UTF-8
            cout << '*' << flush;
        } else {
            cout << c << flush;
        }
    }

    // Devolve true quando o usuario apertou Enter (linha em 'linha').
    bool poll(string& linha) {
#ifdef _WIN32
        while (_kbhit()) {
            int c = _getch();
            if (c == 0 || c == 0xE0) { _getch(); continue; }   // teclas especiais (setas, F1...)
            if (c == 13) {
                cout << "\n" << flush;
                linha = buf;
                buf.clear();
                return true;
            }
            if (c == 8) {
                if (!buf.empty()) { buf.erase(buf.size() - 1); cout << "\b \b" << flush; }
                continue;
            }
            if (c == 3 || c == 26) { g_eof = true; return false; }   // Ctrl+C / Ctrl+Z
            if (c >= 32 && c < 127) {
                buf += static_cast<char>(c);
                ecoar(static_cast<char>(c));
            } else if (c >= 128) {
                char b = 0;
                if (c == 0xC3 && _kbhit()) b = letraBaseLatin1(0xC0 | (_getch() & 0x3F));  // console UTF-8
                else b = letraBaseOEM850(c);                                              // console CP850
                if (b) { buf += b; ecoar(b); }
            }
        }
        return false;
#else
        while (true) {
            fd_set f;
            FD_ZERO(&f);
            FD_SET(0, &f);
            timeval tv;
            tv.tv_sec = 0;
            tv.tv_usec = 0;
            if (select(1, &f, NULL, NULL, &tv) <= 0) break;

            unsigned char c;
            ssize_t n = read(0, &c, 1);
            if (n == 0) { g_eof = true; break; }
            if (n < 0) break;

            if (c == '\n' || c == '\r') {
                if (g_ttyIn) cout << "\n" << flush;
                linha = dobrarAcentos(buf);
                buf.clear();
                return true;
            }
            if (c == 127 || c == 8) {
                if (!buf.empty()) {
                    while (!buf.empty() && (static_cast<unsigned char>(buf[buf.size() - 1]) & 0xC0) == 0x80)
                        buf.erase(buf.size() - 1);
                    if (!buf.empty()) buf.erase(buf.size() - 1);
                    if (g_ttyIn) cout << "\b \b" << flush;
                }
                continue;
            }
            if (c == 4) { if (buf.empty()) g_eof = true; continue; }   // Ctrl+D
            if (c == 27) {                                              // sequencia de escape (setas etc.)
                unsigned char d;
                fd_set f2;
                timeval tv2;
                tv2.tv_sec = 0; tv2.tv_usec = 20000;
                FD_ZERO(&f2); FD_SET(0, &f2);
                if (select(1, &f2, NULL, NULL, &tv2) > 0 && read(0, &d, 1) == 1 && (d == '[' || d == 'O')) {
                    while (true) {
                        FD_ZERO(&f2); FD_SET(0, &f2);
                        tv2.tv_sec = 0; tv2.tv_usec = 20000;
                        if (select(1, &f2, NULL, NULL, &tv2) <= 0) break;
                        if (read(0, &d, 1) != 1) break;
                        if (d >= 0x40 && d <= 0x7E) break;
                    }
                }
                continue;
            }
            if (c >= 32) {
                buf += static_cast<char>(c);
                if (g_ttyIn) ecoar(static_cast<char>(c));
            }
        }
        return false;
#endif
    }
};

static Teclado g_teclado;

// Leitura simples (bloqueante) usada nos menus fora da partida.
static bool lerLinhaSimples(const string& prompt, string& saida) {
    cout << prompt << flush;
    while (!g_eof) {
        if (g_teclado.poll(saida)) return true;
        dormir(15);
    }
    return false;
}

// ============================================================================
//  REDE: utilitarios comuns
// ============================================================================

static void inicializarSockets() {
#ifdef _WIN32
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        cerr << "Erro ao iniciar o Winsock.\n";
        exit(1);
    }
#endif
}

static void finalizarSockets() {
#ifdef _WIN32
    WSACleanup();
#endif
}

static void fecharSocket(socket_t s) {
#ifdef _WIN32
    if (s != INVALID_SOCKET) closesocket(s);
#else
    if (s >= 0) close(s);
#endif
}

static void tornarNaoBloqueante(socket_t s) {
#ifdef _WIN32
    u_long modo = 1;
    ioctlsocket(s, FIONBIO, &modo);
#else
    int flags = fcntl(s, F_GETFL, 0);
    if (flags >= 0) fcntl(s, F_SETFL, flags | O_NONBLOCK);
#endif
}

static bool erroTemporario() {
#ifdef _WIN32
    return WSAGetLastError() == WSAEWOULDBLOCK;
#else
    return errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR;
#endif
}

static int enviarBytes(socket_t s, const char* dados, int tamanho) {
#if defined(MSG_NOSIGNAL)
    return static_cast<int>(send(s, dados, tamanho, MSG_NOSIGNAL));
#else
    return static_cast<int>(send(s, dados, tamanho, 0));
#endif
}

// Lista os IPv4 desta maquina (para o dono da sala informar aos amigos).
static string listarIPsLocais() {
    char nome[256];
    if (gethostname(nome, sizeof(nome)) != 0) return "";
    struct hostent* h = gethostbyname(nome);
    if (!h || h->h_addrtype != AF_INET) return "";
    string r;
    for (char** p = h->h_addr_list; *p != NULL; ++p) {
        struct in_addr a;
        memcpy(&a, *p, sizeof(a));
        string ip = inet_ntoa(a);
        if (ip.compare(0, 4, "127.") == 0) continue;
        if (!r.empty()) r += "  ";
        r += ip;
    }
    return r;
}

// ============================================================================
//  BANCO DE PALAVRAS (por categoria, com acentos)
// ============================================================================

struct CategoriaPadrao {
    const char* nome;
    const char* palavras;   // separadas por virgula; podem ter espaco e hifen
};

static const CategoriaPadrao BANCO_PADRAO[] = {
    { "Animais",
      "cachorro,gato,cavalo,vaca,porco,ovelha,cabra,galinha,pato,ganso,peru,coelho,elefante,"
      "girafa,leão,tigre,onça,zebra,rinoceronte,hipopótamo,macaco,gorila,chimpanzé,urso,panda,"
      "canguru,coala,tubarão,baleia,golfinho,foca,pinguim,tartaruga,jacaré,crocodilo,cobra,"
      "lagarto,camaleão,sapo,arara,papagaio,coruja,águia,falcão,borboleta,abelha,formiga,"
      "aranha,escorpião,minhoca,caramujo,lesma,polvo,lula,caranguejo,camarão,tamanduá,preguiça,"
      "capivara,tatu,lobo,raposa,morcego,esquilo,avestruz,flamingo,tucano,pavão,gaivota" },
    { "Frutas",
      "abacaxi,morango,laranja,uva,banana,manga,kiwi,melancia,melão,maçã,pera,pêssego,ameixa,"
      "cereja,goiaba,mamão,maracujá,limão,tangerina,caju,acerola,jabuticaba,pitanga,jaca,coco,"
      "abacate,framboesa,amora,figo,caqui,carambola,graviola,pitaya,tamarindo,cupuaçu,açaí,"
      "umbu,lichia,nectarina,damasco,groselha,mirtilo,bergamota,cajarana,seriguela,mangaba,"
      "bacuri,buriti" },
    { "Paises",
      "brasil,canadá,japão,frança,índia,egito,itália,méxico,argentina,chile,uruguai,paraguai,"
      "bolívia,peru,colômbia,venezuela,equador,portugal,espanha,alemanha,inglaterra,rússia,"
      "china,coreia,tailândia,vietnã,indonésia,austrália,suécia,noruega,dinamarca,finlândia,"
      "polônia,grécia,turquia,iraque,israel,marrocos,nigéria,angola,moçambique,quênia,etiópia,"
      "cuba,jamaica,panama,suíça,holanda,bélgica,irlanda,ucrânia,filipinas,singapura,paquistão,"
      "nepal,mongólia,hungria,romênia,croácia,islândia,tunísia,senegal" },
    { "Profissoes",
      "médico,professor,engenheiro,advogado,enfermeiro,arquiteto,jornalista,cozinheiro,"
      "dentista,pedreiro,eletricista,encanador,motorista,piloto,policial,bombeiro,padeiro,"
      "açougueiro,pintor,carpinteiro,mecânico,farmacêutico,veterinário,psicólogo,contador,"
      "programador,designer,fotógrafo,ator,cantor,músico,escritor,garçom,barbeiro,cabeleireiro,"
      "soldador,marceneiro,jardineiro,costureiro,vendedor,gerente,secretário,astronauta,"
      "cientista,biólogo,químico,físico,geólogo,economista,bibliotecário,juiz,promotor,"
      "delegado,cartorário" },
    { "Tecnologia",
      "computador,programação,linguagem,teclado,monitor,internet,variável,ponteiro,memória,"
      "algoritmo,processador,servidor,navegador,software,hardware,aplicativo,roteador,"
      "impressora,notebook,smartphone,tablet,mouse,download,upload,compilador,depurador,"
      "biblioteca,framework,protocolo,criptografia,senha,firewall,vírus,backup,nuvem,"
      "inteligência,robô,sensor,bluetooth,pixel,código,script,python,visualg,java,linux,"
      "windows,banco,recursão,função,vetor,matriz,laço,condição,interface,teclas,webcam,"
      "microfone" },
    { "Esportes",
      "futebol,basquete,voleibol,natação,atletismo,ginástica,handebol,tênis,golfe,boxe,judo,"
      "karatê,capoeira,surfe,skate,ciclismo,corrida,maratona,remo,esgrima,hipismo,rugby,"
      "beisebol,criquete,badminton,escalada,triatlo,paraquedismo,patinação,hockey,sinuca,bocha,"
      "peteca,futsal,halterofilismo,taekwondo,velejar,mergulho,arco,lançamento,salto,pentatlo,"
      "biatlo,curling,polo,parkour" },
    { "Comidas",
      "feijoada,macarrão,lasanha,pizza,hambúrguer,churrasco,coxinha,pastel,brigadeiro,pamonha,"
      "tapioca,acarajé,moqueca,farofa,omelete,salada,sopa,risoto,strogonoff,empada,esfiha,"
      "sushi,sorvete,bolo,torta,pudim,mousse,chocolate,sanduíche,panqueca,pipoca,batata,arroz,"
      "feijão,carne,frango,peixe,queijo,presunto,salsicha,linguiça,canjica,cuscuz,bolacha,"
      "biscoito,pão,croissant,waffle,nhoque,ravioli,tempura,quindim,beijinho,paçoca,rapadura" },
    { "Corpo Humano",
      "cabeça,cabelo,testa,sobrancelha,olho,nariz,boca,língua,dente,orelha,pescoço,ombro,braço,"
      "cotovelo,punho,mão,dedo,unha,peito,costas,barriga,umbigo,cintura,quadril,perna,joelho,"
      "tornozelo,calcanhar,coração,pulmão,fígado,rim,estômago,intestino,cérebro,esqueleto,"
      "músculo,osso,pele,sangue,veia,garganta,bochecha,queixo,coxa,panturrilha,cílios,pupila,"
      "retina" },
    { "Natureza",
      "montanha,floresta,oceano,rio,lago,cachoeira,vulcão,deserto,praia,ilha,caverna,pântano,"
      "savana,tundra,geleira,campo,vale,planície,nuvem,chuva,trovão,raio,vento,tempestade,"
      "furacão,arco-íris,sol,lua,estrela,planeta,cometa,galáxia,árvore,flor,folha,raiz,semente,"
      "grama,musgo,cacto,bambu,samambaia,orquídea,girassol,jasmim,margarida,tulipa,manguezal,"
      "cerrado,pampa,caatinga" },
    { "Cidades do Brasil",
      "brasília,salvador,fortaleza,recife,manaus,belém,curitiba,goiânia,natal,maceió,aracaju,"
      "teresina,florianópolis,vitória,cuiabá,campinas,santos,niterói,petrópolis,olinda,paraty,"
      "gramado,blumenau,joinville,londrina,maringá,uberlândia,ribeirão,sorocaba,osasco,"
      "guarulhos,palmas,macapá,são paulo,rio de janeiro,porto alegre,belo horizonte,"
      "campo grande,joão pessoa,são luís,porto velho,rio branco,boa vista,bonito" },
    { "Objetos",
      "cadeira,mesa,sofá,cama,armário,geladeira,fogão,micro-ondas,televisão,ventilador,lâmpada,"
      "espelho,relógio,chave,porta,janela,tapete,cortina,travesseiro,cobertor,panela,"
      "frigideira,colher,garfo,faca,prato,copo,xícara,garrafa,mochila,carteira,óculos,escova,"
      "pente,sabonete,toalha,vassoura,balde,martelo,parafuso,lanterna,bicicleta,caderno,caneta,"
      "lápis,borracha,tesoura,régua,guarda-chuva,chaveiro,abajur" },
    { "Games e Animes",
      "naruto,goku,minecraft,fortnite,pokémon,mario,zelda,sonic,tetris,pacman,luffy,sasuke,"
      "vegeta,ichigo,eren,mikasa,pikachu,charizard,kirby,link,steve,creeper,zumbi,dragonball,"
      "onepiece,bleach,valorant,overwatch,roblox,terraria,undertale,injogável,playstation,xbox,"
      "nintendo,counterstrike,leagueoflegends,amongus,fifa,gta,eldenring,hollowknight,celeste,"
      "doom,skyrim" },
    { "Cores",
      "vermelho,azul,amarelo,verde,roxo,preto,branco,laranja,rosa,marrom,cinza,dourado,"
      "prateado,bege,violeta,turquesa,magenta,ciano,lilás,vinho,salmão,carmesim,anil,grafite,"
      "creme" }
};

struct Entrada {
    string disp;   // como aparece na tela (UTF-8: acentos, espaco, hifen)
    string base;   // somente letras a-z, sem acento (usada na logica do jogo)
};

enum Nivel { NIVEL_TODOS = 0, NIVEL_FACIL = 1, NIVEL_MEDIO = 2, NIVEL_DIFICIL = 3 };

static int nivelDaPalavra(size_t letras) {
    return letras <= 6 ? NIVEL_FACIL : (letras <= 9 ? NIVEL_MEDIO : NIVEL_DIFICIL);
}

static string nomeNivel(int n) {
    switch (n) {
        case NIVEL_FACIL:   return "Facil (3 a 6 letras)";
        case NIVEL_MEDIO:   return "Medio (7 a 9 letras)";
        case NIVEL_DIFICIL: return "Dificil (10 ou mais letras)";
        default:            return "Todos os tamanhos";
    }
}

class BancoPalavras {
public:
    vector<string> categorias;
    map<string, vector<Entrada> > palavras;

    void carregarPadrao() {
        size_t n = sizeof(BANCO_PADRAO) / sizeof(BANCO_PADRAO[0]);
        for (size_t i = 0; i < n; ++i) {
            vector<string> itens = dividir(BANCO_PADRAO[i].palavras, ',');
            for (size_t j = 0; j < itens.size(); ++j) adicionar(BANCO_PADRAO[i].nome, itens[j]);
        }
    }

    // Formato:  Categoria;palavra1, palavra2, palavra tres
    //       ou  Categoria;palavra1 palavra2 palavra3   (sem virgula = separadas por espaco)
    // Linhas iniciadas com # sao comentarios. Acentos sao mantidos na exibicao.
    int carregarArquivo(const string& caminho) {
        ifstream f(caminho.c_str());
        if (!f) return 0;
        int total = 0;
        string linha;
        while (getline(f, linha)) {
            linha = aparar(linha);
            if (linha.size() >= 3 && static_cast<unsigned char>(linha[0]) == 0xEF &&
                static_cast<unsigned char>(linha[1]) == 0xBB && static_cast<unsigned char>(linha[2]) == 0xBF)
                linha = aparar(linha.substr(3));   // BOM do bloco de notas
            if (linha.empty() || linha[0] == '#') continue;
            size_t pv = linha.find(';');
            if (pv == string::npos) continue;
            string cat = sanitizarTexto(linha.substr(0, pv), 24);
            string resto = linha.substr(pv + 1);
            vector<string> itens;
            if (resto.find(',') != string::npos) {
                itens = dividir(resto, ',');
            } else {
                istringstream in(resto);
                string p;
                while (in >> p) itens.push_back(p);
            }
            for (size_t i = 0; i < itens.size(); ++i)
                if (adicionar(cat, itens[i])) ++total;
        }
        return total;
    }

    bool adicionar(const string& categoria, const string& bruta) {
        Entrada e;
        e.disp = sanitizarExibicao(bruta, 24);
        e.base = normalizarPalavra(e.disp);
        if (categoria.empty() || e.base.size() < 3 || e.base.size() > 16) return false;
        vector<Entrada>& lista = palavras[categoria];
        for (size_t i = 0; i < lista.size(); ++i)
            if (lista[i].base == e.base) return false;
        if (find(categorias.begin(), categorias.end(), categoria) == categorias.end())
            categorias.push_back(categoria);
        lista.push_back(e);
        return true;
    }

    int total() const {
        int t = 0;
        for (map<string, vector<Entrada> >::const_iterator it = palavras.begin(); it != palavras.end(); ++it)
            t += static_cast<int>(it->second.size());
        return t;
    }

    // Procura categoria ignorando maiusculas. Vazio se nao existe.
    string acharCategoria(const string& nome) const {
        string alvo = paraMinusculas(aparar(nome));
        for (size_t i = 0; i < categorias.size(); ++i)
            if (paraMinusculas(categorias[i]) == alvo) return categorias[i];
        return "";
    }

    // Sorteia uma palavra ainda nao usada na sala. categoria vazia = qualquer uma.
    // nivel 0 = qualquer tamanho. relaxou = true quando nao havia palavra no nivel pedido.
    Entrada sortearPalavra(const string& categoria, int nivel, set<string>& usadas,
                           string& categoriaSorteada, bool& relaxou) {
        relaxou = false;
        int nv = nivel;
        for (int tentativa = 0; tentativa < 2; ++tentativa) {
            vector<pair<string, const Entrada*> > todas, livres;
            for (size_t i = 0; i < categorias.size(); ++i) {
                if (!categoria.empty() && categorias[i] != categoria) continue;
                const vector<Entrada>& lista = palavras[categorias[i]];
                for (size_t j = 0; j < lista.size(); ++j) {
                    if (nv != 0 && nivelDaPalavra(lista[j].base.size()) != nv) continue;
                    todas.push_back(make_pair(categorias[i], &lista[j]));
                    if (usadas.find(lista[j].base) == usadas.end())
                        livres.push_back(make_pair(categorias[i], &lista[j]));
                }
            }
            if (todas.empty()) {
                if (nv == 0) break;
                relaxou = true;
                nv = 0;
                continue;
            }
            if (livres.empty()) {      // acabaram as palavras: recomeca o ciclo
                for (size_t k = 0; k < todas.size(); ++k) usadas.erase(todas[k].second->base);
                livres = todas;
            }
            pair<string, const Entrada*> p = livres[sortear(static_cast<int>(livres.size()))];
            usadas.insert(p.second->base);
            categoriaSorteada = p.first;
            return *p.second;
        }
        Entrada e;
        e.disp = "forca";
        e.base = "forca";
        categoriaSorteada = "Diversos";
        return e;
    }
};

// ============================================================================
//  RANKING GLOBAL (persistente)
// ============================================================================

struct RankEntrada {
    string nome;
    long pontos;
    int vitorias;
    int rodadas;
    RankEntrada() : pontos(0), vitorias(0), rodadas(0) {}
};

class Ranking {
public:
    explicit Ranking(const string& arq = "ranking.txt") : arquivo(arq) {}

    void carregar() {
        ifstream f(arquivo.c_str());
        if (!f) return;
        string linha;
        while (getline(f, linha)) {
            vector<string> p = dividir(linha, '|');
            if (p.size() != 4) continue;
            RankEntrada e;
            e.nome = p[0];
            e.pontos = atol(p[1].c_str());
            e.vitorias = atoi(p[2].c_str());
            e.rodadas = atoi(p[3].c_str());
            if (!e.nome.empty()) dados[paraMinusculas(e.nome)] = e;
        }
    }

    void salvar() const {
        ofstream f(arquivo.c_str());
        if (!f) return;
        for (map<string, RankEntrada>::const_iterator it = dados.begin(); it != dados.end(); ++it)
            f << it->second.nome << '|' << it->second.pontos << '|'
              << it->second.vitorias << '|' << it->second.rodadas << '\n';
    }

    void registrar(const string& nome, int pontosRodada, bool venceu) {
        RankEntrada& e = dados[paraMinusculas(nome)];
        e.nome = nome;
        e.pontos += pontosRodada;
        e.rodadas += 1;
        if (venceu) e.vitorias += 1;
    }

    static bool melhorQue(const RankEntrada& a, const RankEntrada& b) {
        if (a.pontos != b.pontos) return a.pontos > b.pontos;
        if (a.vitorias != b.vitorias) return a.vitorias > b.vitorias;
        return a.nome < b.nome;
    }

    vector<RankEntrada> top(size_t n) const {
        vector<RankEntrada> v;
        for (map<string, RankEntrada>::const_iterator it = dados.begin(); it != dados.end(); ++it)
            v.push_back(it->second);
        sort(v.begin(), v.end(), melhorQue);
        if (v.size() > n) v.resize(n);
        return v;
    }

    size_t total() const { return dados.size(); }

private:
    string arquivo;
    map<string, RankEntrada> dados;
};

// ============================================================================
//  SERVIDOR
//
//  Protocolo (texto, uma mensagem por linha, campos separados por '|'), versao 3:
//
//   Cliente -> Servidor
//     HELLO|nome|versao[|token]   PONG   LIST   RANKING
//     CREATE|max|categoria|pub    JOIN|codigo[|1=assistir]   LEAVE
//     START   CONFIG|chave|valor  CHAT|texto
//     LETTER|x   WORD|palavra   SETWORD|palavra   SPEC|0/1   TEAM|0/1
//     KICK|nome   HOST|nome
//
//   Servidor -> Cliente
//     WELCOME|nome|token   NOSESSION   CATS|c1|c2|...   ERROR|texto   SYS|texto   PING
//     JOINED|codigo|reconectou   LEFT   KICKED|texto
//     ROOMINFO|cod|cat|max|pub|dono|dif|tempo|partidaTipo|partidaValor|equipes|modo|nEsp
//     ROSTER|n  + n linhas  M|nome|pontos|vitorias|dono|espectador|equipe|offline
//     STATE|cod|cat|mascara|usadas|certas|turno|restantes|faseFinal|parado|fim|vencedor|
//           palavraFinal|rodada|n|fase|tempoRest|tempoLimite|mestre|comprimento|fimPartida|pausada
//        + n linhas  P|slot|nome|erros|pontos|status|vitorias|pontosRodada|equipe|offline
//     CHAMP|campeao|n|titulo + n linhas  CH|pos|nome|pontos|vitorias
//     EVENT|tipo|slot|letra|texto   CHATMSG|nome|texto   CHATHIST|nome|texto
//     ROOM|cod|dono|n|max|cat|emJogo|nEsp ... ROOMS_END
//     RANK|pos|nome|pontos|vitorias|rodadas ... RANK_END|total
// ============================================================================

enum TipoPartida { PART_LIVRE = 0, PART_MELHOR = 1, PART_PONTOS = 2 };
enum FaseSala    { FASE_ESPERA = 0, FASE_MESTRE = 1, FASE_JOGANDO = 2 };

static const int TEMPO_MESTRE_SEG = 90;

struct Conn {
    socket_t sock;
    string entrada, saida;
    int id;
    string nome, token;
    bool logado, morto;
    string sala;   // codigo da sala atual ("" = nenhuma)
    long long ultimoRx, ultimoPing;
    pthread_t th;            // thread dedicada a esta conexao (um jogador = uma thread)
    bool threadIniciada;     // th e valido
    bool threadSaiu;         // a thread terminou e nao toca mais neste Conn (so entao ele pode ser apagado)
    Conn() : sock(SOCK_INVALIDO), id(0), logado(false), morto(false), ultimoRx(0), ultimoPing(0),
             threadIniciada(false), threadSaiu(false) {}
};

struct Membro {
    int connId;
    string nome, token;
    int pontos, vitorias, erros, pontosRodada, equipe, inativo;
    bool eliminado, presente, desconectado, mestre;
    long long desconectadoEm;
    Membro() : connId(0), pontos(0), vitorias(0), erros(0), pontosRodada(0), equipe(0), inativo(0),
               eliminado(false), presente(true), desconectado(false), mestre(false), desconectadoEm(0) {}
};

struct Espec {
    int connId;
    string nome;
    bool voluntario;   // true = escolheu so assistir; false = esta na fila esperando vaga
    Espec() : connId(0), voluntario(false) {}
};

struct Sala {
    string codigo;
    vector<Membro> membros;
    vector<Espec> espec;
    set<string> banidos;           // nomes em minusculas
    string hostLc;                 // nome do dono (minusculas)

    // configuracao
    int max;
    string categoria;              // "" = aleatoria
    bool publica;
    int dificuldade;               // 0 todos, 1 facil, 2 medio, 3 dificil
    int tempo;                     // segundos por jogada (0 = sem limite)
    int partidaTipo, partidaValor;
    bool equipes;
    int modoPalavra;               // 0 sorteada, 1 jogador escolhe

    // rodada
    int fase;
    string palavra, disp, palavraCat, usadas;   // palavra = a-z; disp = com acentos
    vector<string> glifos;
    vector<char> bases;            // letra base de cada glifo (0 = espaco/hifen)
    vector<int> ordem;             // ordem dos turnos (indices em membros)
    int turno, restantes, fim, vencedor, rodada, mestreIdx;
    bool pausada;
    long long prazo;

    // partida
    int vitEquipe[2], pontosSaidos[2];
    bool fimPartida;
    string champBloco;

    set<string> palavrasUsadas;
    deque<string> historico;

    Sala() : max(PADRAO_JOGADORES), publica(true), dificuldade(0), tempo(TEMPO_PADRAO),
             partidaTipo(PART_LIVRE), partidaValor(0), equipes(false), modoPalavra(0),
             fase(FASE_ESPERA), turno(0), restantes(0), fim(0), vencedor(-1), rodada(0),
             mestreIdx(-1), pausada(false), prazo(0), fimPartida(false) {
        vitEquipe[0] = vitEquipe[1] = 0;
        pontosSaidos[0] = pontosSaidos[1] = 0;
    }
};

static int contarLetrasRestantes(const string& palavra, const string& usadas) {
    string faltando;
    for (size_t i = 0; i < palavra.size(); ++i)
        if (!contem(usadas, palavra[i]) && !contem(faltando, palavra[i])) faltando += palavra[i];
    return static_cast<int>(faltando.size());
}

static string textoPartida(int tipo, int valor) {
    if (tipo == PART_MELHOR) return "Melhor de " + itos(valor);
    if (tipo == PART_PONTOS) return "Primeiro a " + itos(valor) + " pontos";
    return "Livre";
}

// Trava RAII: entra na REGIAO CRITICA no construtor e sai no destrutor (mesmo com return/excecao).
class Trava {
public:
    explicit Trava(pthread_mutex_t* m) : mtx(m) { pthread_mutex_lock(mtx); }
    ~Trava() { pthread_mutex_unlock(mtx); }
private:
    pthread_mutex_t* mtx;
    Trava(const Trava&);
    Trava& operator=(const Trava&);
};

// ----------------------------------------------------------------------------
//  MODELO DE CONCORRENCIA DO SERVIDOR (memoria compartilhada + exclusao mutua)
//
//   - Todo o ESTADO DO JOGO (lista de conexoes, salas, jogadores, "turno"/vez,
//     palavra, pontos, ranking) fica em UMA area de memoria compartilhada entre
//     as threads do servidor: os objetos Servidor::conns / Servidor::salas.
//   - Cada jogador conectado e atendido por uma THREAD propria (laco da conexao),
//     que recebe mensagens do socket e as executa sobre o estado compartilhado.
//   - Uma THREAD de ACEITE recebe novas conexoes e cria a thread do jogador.
//   - Uma THREAD DE RELOGIO cuida do tempo por jogada, ping e quedas.
//   - Como varias threads leem/escrevem o mesmo estado, TODO acesso a ele e feito
//     dentro da REGIAO CRITICA protegida por um unico mutex (pthread_mutex_t).
//     So uma thread por vez altera o estado: assim duas jogadas simultaneas
//     nunca corrompem a "vez" nem a pontuacao, e o resultado e o mesmo de uma
//     execucao sequencial. O mutex NAO e mantido durante select()/espera de
//     rede, apenas durante o processamento da mensagem (rapido).
// ----------------------------------------------------------------------------
class Servidor;
struct ArgThread { Servidor* srv; Conn* c; };
static void* threadConexaoEntrada(void* arg);
static void* threadAceiteEntrada(void* arg);
static void* threadRelogioEntrada(void* arg);

class Servidor {
public:
    Servidor() : paradaSolicitada(false), ouvindo(SOCK_INVALIDO), proxId(1), verboso(false),
                 ranking("ranking.txt"), proximaRotina(0), rodando(false), threadsIniciadas(false) {
        pthread_mutex_init(&mtx, NULL);
    }

    ~Servidor() { encerrar(); pthread_mutex_destroy(&mtx); }

    bool iniciar(int porta, bool verbose, string& erro) {
        verboso = verbose;
        banco.carregarPadrao();
        int extras = banco.carregarArquivo("palavras.txt");
        ranking.carregar();
        if (verboso) {
            log("Banco de palavras: " + itos(banco.total()) + " palavras em " +
                itos(static_cast<long>(banco.categorias.size())) + " categorias" +
                (extras > 0 ? " (" + itos(extras) + " vindas de palavras.txt)" : ""));
            log("Ranking carregado: " + itos(static_cast<long>(ranking.total())) + " jogadores");
        }

        ouvindo = socket(AF_INET, SOCK_STREAM, 0);
        if (ouvindo == SOCK_INVALIDO) { erro = "Erro ao criar o socket do servidor."; return false; }
#ifdef _WIN32
        BOOL reutilizar = TRUE;
        setsockopt(ouvindo, SOL_SOCKET, SO_REUSEADDR,
                   reinterpret_cast<const char*>(&reutilizar), sizeof(reutilizar));
#else
        int reutilizar = 1;
        setsockopt(ouvindo, SOL_SOCKET, SO_REUSEADDR, &reutilizar, sizeof(reutilizar));
#endif
        sockaddr_in end;
        memset(&end, 0, sizeof(end));
        end.sin_family = AF_INET;
        end.sin_addr.s_addr = htonl(INADDR_ANY);
        end.sin_port = htons(static_cast<unsigned short>(porta));

        if (bind(ouvindo, reinterpret_cast<sockaddr*>(&end), sizeof(end)) < 0) {
            erro = "Nao foi possivel abrir a porta " + itos(porta) +
                   ". Ela ja esta em uso (outro servidor aberto?).";
            fecharSocket(ouvindo);
            ouvindo = SOCK_INVALIDO;
            return false;
        }
        if (listen(ouvindo, 16) < 0) {
            erro = "Erro ao colocar o servidor em espera.";
            fecharSocket(ouvindo);
            ouvindo = SOCK_INVALIDO;
            return false;
        }
        tornarNaoBloqueante(ouvindo);

        // Sobe as threads do servidor: aceite de conexoes + relogio do jogo.
        rodando = true;
        if (pthread_create(&thAceite, NULL, threadAceiteEntrada, this) != 0) {
            rodando = false;
            erro = "Erro ao criar a thread de aceite do servidor.";
            fecharSocket(ouvindo);
            ouvindo = SOCK_INVALIDO;
            return false;
        }
        if (pthread_create(&thRelogio, NULL, threadRelogioEntrada, this) != 0) {
            rodando = false;
            pthread_join(thAceite, NULL);
            erro = "Erro ao criar a thread de relogio do servidor.";
            fecharSocket(ouvindo);
            ouvindo = SOCK_INVALIDO;
            return false;
        }
        threadsIniciadas = true;
        return true;
    }

    void encerrar() {
        // 1) pede para todas as threads pararem e espera cada uma terminar (sem o mutex preso)
        rodando = false;
        if (threadsIniciadas) {
            pthread_join(thAceite, NULL);
            pthread_join(thRelogio, NULL);
            threadsIniciadas = false;
        }
        for (size_t i = 0; i < conns.size(); ++i)
            if (conns[i]->threadIniciada) { pthread_join(conns[i]->th, NULL); conns[i]->threadIniciada = false; }
        // 2) com todas as threads paradas, libera a memoria compartilhada
        for (size_t i = 0; i < conns.size(); ++i) {
            fecharSocket(conns[i]->sock);
            delete conns[i];
        }
        conns.clear();
        for (map<string, Sala*>::iterator it = salas.begin(); it != salas.end(); ++it) delete it->second;
        salas.clear();
        if (ouvindo != SOCK_INVALIDO) { fecharSocket(ouvindo); ouvindo = SOCK_INVALIDO; }
    }

    // ---- corpo das threads (chamados pelas funcoes de entrada acima) ----

    // THREAD DE ACEITE: espera novas conexoes; para cada uma, cria a thread do jogador.
    void loopAceite() {
        while (rodando) {
            fd_set rd;
            FD_ZERO(&rd);
            FD_SET(ouvindo, &rd);
            timeval tv;
            tv.tv_sec = 0;
            tv.tv_usec = 100000;
            int r = select(static_cast<int>(ouvindo) + 1, &rd, NULL, NULL, &tv);
            if (r > 0 && FD_ISSET(ouvindo, &rd)) {
                Trava t(&mtx);              // REGIAO CRITICA: altera a lista de conexoes
                aceitar();
            }
        }
    }

    // THREAD DO JOGADOR: le as mensagens do socket deste jogador e as aplica ao estado compartilhado.
    void loopConexao(Conn* c) {
        socket_t meu = c->sock;             // imutavel enquanto a thread vive
        while (rodando) {
            fd_set rd;
            FD_ZERO(&rd);
            FD_SET(meu, &rd);
            timeval tv;
            tv.tv_sec = 0;
            tv.tv_usec = 50000;
            int r = select(static_cast<int>(meu) + 1, &rd, NULL, NULL, &tv);   // fora da regiao critica
            Trava t(&mtx);                  // REGIAO CRITICA
            if (c->morto) break;
            if (r > 0 && FD_ISSET(meu, &rd)) ler(c);    // tratarLinha() altera salas/turno/pontos
            descarregarTodos();             // envia as respostas aos jogadores afetados
            if (c->morto) break;
        }
        // 'Trava t' ja foi liberada; marca o fim sob o mutex e nunca mais toca em 'c'
        pthread_mutex_lock(&mtx);
        c->threadSaiu = true;
        pthread_mutex_unlock(&mtx);
    }

    // THREAD DE RELOGIO: tempo por jogada, ping, quedas de conexao, limpeza de conexoes encerradas.
    void loopRelogio() {
        while (rodando) {
            dormir(20);
            Trava t(&mtx);                  // REGIAO CRITICA
            long long agora = agoMs();
            if (agora >= proximaRotina) {
                proximaRotina = agora + 100;
                rotinas(agora);
            }
            descarregarTodos();
            removerMortos();
            descarregarTodos();
        }
    }

    // Modo "so servidor": mostra o log e roda ate o usuario digitar q (o jogo em si roda nas threads).
    void executarDedicado() {
        cout << "\n  Servidor dedicado rodando na porta " << g_porta << ".\n";
        string ips = listarIPsLocais();
        if (!ips.empty()) cout << "  Peca aos jogadores para usar um destes IPs: " << ips << "\n";
        cout << "  Digite q e Enter para encerrar.\n\n";
        string linha;
        while (!g_eof) {
            dormir(50);
            if (g_teclado.poll(linha)) {
                if (paraMinusculas(aparar(linha)) == "q") break;
            }
        }
        // EOF em stdin (ex.: rodando como servico) nao encerra o servidor
        while (g_eof && !paradaSolicitada) dormir(200);
    }

    bool paradaSolicitada;

private:
    socket_t ouvindo;
    vector<Conn*> conns;
    map<string, Sala*> salas;
    int proxId;
    bool verboso;
    BancoPalavras banco;
    Ranking ranking;
    long long proximaRotina;

    // concorrencia
    pthread_mutex_t mtx;               // protege TODO o estado compartilhado acima (conns, salas, ranking...)
    pthread_t thAceite, thRelogio;
    volatile bool rodando;
    bool threadsIniciadas;

    // ---------------------------------------------------------------- util ---

    void log(const string& s) {
        if (!verboso) return;
        time_t agora = time(NULL);
        char hora[16];
        strftime(hora, sizeof(hora), "%H:%M:%S", localtime(&agora));
        cout << "[" << hora << "] " << s << "\n" << flush;
    }

    Conn* porId(int id) {
        if (id <= 0) return NULL;
        for (size_t i = 0; i < conns.size(); ++i)
            if (conns[i]->id == id && !conns[i]->morto) return conns[i];
        return NULL;
    }

    Sala* acharSala(const string& codigo) {
        map<string, Sala*>::iterator it = salas.find(codigo);
        return it == salas.end() ? NULL : it->second;
    }

    Sala* salaDe(Conn* c) {
        if (c->sala.empty()) return NULL;
        Sala* s = acharSala(c->sala);
        if (!s) c->sala.clear();
        return s;
    }

    int idxMembro(Sala* s, const string& nome) {
        string alvo = paraMinusculas(nome);
        for (size_t i = 0; i < s->membros.size(); ++i)
            if (s->membros[i].presente && paraMinusculas(s->membros[i].nome) == alvo) return static_cast<int>(i);
        return -1;
    }

    int idxEspec(Sala* s, const string& nome) {
        string alvo = paraMinusculas(nome);
        for (size_t i = 0; i < s->espec.size(); ++i)
            if (paraMinusculas(s->espec[i].nome) == alvo) return static_cast<int>(i);
        return -1;
    }

    bool ehHost(Sala* s, Conn* c) { return paraMinusculas(c->nome) == s->hostLc; }

    int contarPresentes(Sala* s) {
        int n = 0;
        for (size_t i = 0; i < s->membros.size(); ++i) if (s->membros[i].presente) ++n;
        return n;
    }

    bool nomeEmUso(const string& nome) {
        string alvo = paraMinusculas(nome);
        for (size_t i = 0; i < conns.size(); ++i)
            if (conns[i]->logado && !conns[i]->morto && paraMinusculas(conns[i]->nome) == alvo) return true;
        for (map<string, Sala*>::iterator it = salas.begin(); it != salas.end(); ++it) {
            Sala* s = it->second;
            for (size_t i = 0; i < s->membros.size(); ++i)
                if (s->membros[i].presente && paraMinusculas(s->membros[i].nome) == alvo) return true;
        }
        return false;
    }

    string gerarCodigo() {
        static const char alfabeto[] = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        while (true) {
            string c;
            for (int i = 0; i < 4; ++i) c += alfabeto[sortear(static_cast<int>(sizeof(alfabeto)) - 1)];
            if (!acharSala(c)) return c;
        }
    }

    string gerarToken() {
        static const char alfabeto[] = "abcdefghijkmnpqrstuvwxyz23456789";
        string t;
        for (int i = 0; i < 12; ++i) t += alfabeto[sortear(static_cast<int>(sizeof(alfabeto)) - 1)];
        return t;
    }

    bool faseFinal(Sala* s) { return s->restantes > 0 && s->restantes <= FASE_FINAL_LETRAS; }

    bool ativo(const Membro& m) { return m.presente && !m.eliminado && !m.desconectado && !m.mestre; }

    // ---------------------------------------------------------------- envio ---

    void enviar(Conn* c, const string& linha) {
        if (c && !c->morto) c->saida += linha + "\n";
    }

    void paraSala(Sala* s, const string& linha, int exceto = -1) {
        for (size_t i = 0; i < s->membros.size(); ++i) {
            const Membro& m = s->membros[i];
            if (!m.presente || m.desconectado || m.connId == exceto) continue;
            enviar(porId(m.connId), linha);
        }
        for (size_t i = 0; i < s->espec.size(); ++i)
            if (s->espec[i].connId != exceto) enviar(porId(s->espec[i].connId), linha);
    }

    void evento(Sala* s, const string& tipo, int slot, char letra, const string& texto) {
        string l = letra ? string(1, letra) : string("");
        paraSala(s, "EVENT|" + tipo + "|" + itos(slot) + "|" + l + "|" + texto);
    }

    void sys(Sala* s, const string& texto) { paraSala(s, "SYS|" + texto); }

    void descarregar(Conn* c) {
        while (!c->saida.empty() && !c->morto) {
            int n = enviarBytes(c->sock, c->saida.data(), static_cast<int>(c->saida.size()));
            if (n > 0) {
                c->saida.erase(0, static_cast<size_t>(n));
            } else if (n < 0 && erroTemporario()) {
                break;
            } else {
                c->morto = true;
            }
        }
    }

    void descarregarTodos() {
        for (size_t i = 0; i < conns.size(); ++i)
            if (!conns[i]->saida.empty() && !conns[i]->morto) descarregar(conns[i]);
    }

    string catsMsg() {
        string cats = "CATS";
        for (size_t i = 0; i < banco.categorias.size(); ++i) cats += "|" + banco.categorias[i];
        return cats;
    }

    string nomeDoDono(Sala* s) {
        for (size_t i = 0; i < s->membros.size(); ++i)
            if (s->membros[i].presente && paraMinusculas(s->membros[i].nome) == s->hostLc) return s->membros[i].nome;
        for (size_t i = 0; i < s->espec.size(); ++i)
            if (paraMinusculas(s->espec[i].nome) == s->hostLc) return s->espec[i].nome;
        return "?";
    }

    void enviarRoomInfo(Sala* s, Conn* so = NULL) {
        string msg = "ROOMINFO|" + s->codigo + "|" + s->categoria + "|" + itos(s->max) + "|" +
                     (s->publica ? "1" : "0") + "|" + nomeDoDono(s) + "|" + itos(s->dificuldade) + "|" +
                     itos(s->tempo) + "|" + itos(s->partidaTipo) + "|" + itos(s->partidaValor) + "|" +
                     (s->equipes ? "1" : "0") + "|" + itos(s->modoPalavra) + "|" +
                     itos(static_cast<long>(s->espec.size()));
        if (so) enviar(so, msg); else paraSala(s, msg);
    }

    void enviarRoster(Sala* s, Conn* so = NULL) {
        vector<string> linhas;
        for (size_t i = 0; i < s->membros.size(); ++i) {
            const Membro& m = s->membros[i];
            if (!m.presente) continue;
            linhas.push_back("M|" + m.nome + "|" + itos(m.pontos) + "|" + itos(m.vitorias) + "|" +
                             (paraMinusculas(m.nome) == s->hostLc ? "1" : "0") + "|0|" + itos(m.equipe) + "|" +
                             (m.desconectado ? "1" : "0"));
        }
        for (size_t i = 0; i < s->espec.size(); ++i)
            linhas.push_back("M|" + s->espec[i].nome + "|0|0|" +
                             (paraMinusculas(s->espec[i].nome) == s->hostLc ? "1" : "0") + "|1|0|0");
        string bloco = "ROSTER|" + itos(static_cast<long>(linhas.size()));
        for (size_t i = 0; i < linhas.size(); ++i) bloco += "\n" + linhas[i];
        if (so) enviar(so, bloco); else paraSala(s, bloco);
    }

    // ---- palavra da rodada ----

    string montarMascara(Sala* s) {
        string r;
        for (size_t i = 0; i < s->glifos.size(); ++i) {
            if (i) r += ' ';
            char b = s->bases[i];
            if (b == 0) r += (s->glifos[i] == " " ? string("/") : s->glifos[i]);
            else if (contem(s->usadas, b)) r += s->glifos[i];
            else r += '_';
        }
        return r;
    }

    string letrasCertas(Sala* s) {
        string r;
        for (size_t i = 0; i < s->usadas.size(); ++i)
            if (contem(s->palavra, s->usadas[i])) r += s->usadas[i];
        return r;
    }

    int tempoRestante(Sala* s) {
        if (s->prazo <= 0 || s->pausada) return -1;
        if (s->fase != FASE_JOGANDO && s->fase != FASE_MESTRE) return -1;
        long long ms = s->prazo - agoMs();
        if (ms < 0) ms = 0;
        return static_cast<int>((ms + 999) / 1000);
    }

    void enviarEstado(Sala* s, Conn* so = NULL) {
        bool jogando = (s->fase == FASE_JOGANDO);
        bool terminou = (s->fase == FASE_ESPERA);
        string bloco = "STATE|" + s->codigo + "|" +
                       (s->fase == FASE_MESTRE ? string("?") : s->palavraCat) + "|" +
                       (jogando || terminou ? montarMascara(s) : string("")) + "|" +
                       (jogando || terminou ? s->usadas : string("")) + "|" +
                       (jogando || terminou ? letrasCertas(s) : string("")) + "|" +
                       itos(s->turno) + "|" + itos(s->restantes) + "|" +
                       (jogando && faseFinal(s) ? "1" : "0") + "|" + (jogando ? "0" : "1") + "|" +
                       itos(s->fim) + "|" + itos(s->vencedor) + "|" +
                       (terminou ? s->disp : string("")) + "|" + itos(s->rodada) + "|" +
                       itos(static_cast<long>(s->membros.size())) + "|" + itos(s->fase) + "|" +
                       itos(tempoRestante(s)) + "|" + itos(s->fase == FASE_MESTRE ? TEMPO_MESTRE_SEG : s->tempo) + "|" +
                       itos(s->mestreIdx) + "|" + itos(static_cast<long>(s->palavra.size())) + "|" +
                       (s->fimPartida ? "1" : "0") + "|" + (s->pausada ? "1" : "0");
        for (size_t i = 0; i < s->membros.size(); ++i) {
            const Membro& m = s->membros[i];
            int status = !m.presente ? 2 : (m.mestre ? 3 : (m.eliminado ? 1 : 0));
            bloco += "\nP|" + itos(static_cast<long>(i)) + "|" + m.nome + "|" + itos(m.erros) + "|" +
                     itos(m.pontos) + "|" + itos(status) + "|" + itos(m.vitorias) + "|" +
                     itos(m.pontosRodada) + "|" + itos(m.equipe) + "|" + (m.desconectado ? "1" : "0");
        }
        if (so) enviar(so, bloco); else paraSala(s, bloco);
    }

    void enviarHistorico(Sala* s, Conn* c) {
        for (size_t i = 0; i < s->historico.size(); ++i) enviar(c, "CHATHIST|" + s->historico[i]);
    }

    // ---------------------------------------------------------------- rede ---

    void aceitar() {
        while (true) {
            sockaddr_in end;
            memset(&end, 0, sizeof(end));
#ifdef _WIN32
            int tam = sizeof(end);
#else
            socklen_t tam = sizeof(end);
#endif
            socket_t novo = accept(ouvindo, reinterpret_cast<sockaddr*>(&end), &tam);
            if (novo == SOCK_INVALIDO) break;
            tornarNaoBloqueante(novo);
            Conn* c = new Conn();
            c->sock = novo;
            c->id = proxId++;
            c->ultimoRx = agoMs();
            c->ultimoPing = agoMs();
            conns.push_back(c);
            ArgThread* arg = new ArgThread();
            arg->srv = this;
            arg->c = c;
            if (pthread_create(&c->th, NULL, threadConexaoEntrada, arg) == 0) {
                c->threadIniciada = true;
            } else {
                delete arg;
                c->morto = true;           // sem thread nao ha como atender: a conexao e descartada
            }
            log("Conexao #" + itos(c->id) + " aceita (thread propria)");
        }
    }

    void ler(Conn* c) {
        char buf[4096];
        int n = static_cast<int>(recv(c->sock, buf, sizeof(buf), 0));
        if (n == 0) { c->morto = true; return; }
        if (n < 0) {
            if (!erroTemporario()) c->morto = true;
            return;
        }
        c->ultimoRx = agoMs();
        c->entrada.append(buf, static_cast<size_t>(n));
        if (c->entrada.size() > 16384) { c->morto = true; return; }

        size_t pos;
        while (!c->morto && (pos = c->entrada.find('\n')) != string::npos) {
            string linha = c->entrada.substr(0, pos);
            c->entrada.erase(0, pos + 1);
            if (!linha.empty() && linha[linha.size() - 1] == '\r') linha.erase(linha.size() - 1);
            if (!linha.empty()) tratarLinha(c, linha);
        }
    }

    void removerMortos() {
        bool achou = true;
        while (achou) {
            achou = false;
            for (size_t i = 0; i < conns.size(); ++i) {
                if (!conns[i]->morto) continue;
                if (conns[i]->threadIniciada && !conns[i]->threadSaiu) continue;   // thread ainda encerrando
                Conn* c = conns[i];
                if (c->threadIniciada) { pthread_join(c->th, NULL); c->threadIniciada = false; }
                conns.erase(conns.begin() + static_cast<long>(i));
                log("Conexao #" + itos(c->id) + (c->nome.empty() ? "" : " (" + c->nome + ")") + " encerrada");
                aoDesconectar(c);
                fecharSocket(c->sock);
                delete c;
                achou = true;
                break;
            }
        }
    }

    // Verificacoes periodicas: ping, tempo por jogada, escolha da palavra, quedas de conexao.
    void rotinas(long long agora) {
        for (size_t i = 0; i < conns.size(); ++i) {
            Conn* c = conns[i];
            if (c->morto) continue;
            if (agora - c->ultimoRx > PING_LIMITE_MS) { c->morto = true; continue; }
            if (c->logado && agora - c->ultimoPing > PING_INTERVALO_MS) {
                enviar(c, "PING");
                c->ultimoPing = agora;
            }
        }
        vector<string> codigos;
        for (map<string, Sala*>::iterator it = salas.begin(); it != salas.end(); ++it) codigos.push_back(it->first);
        for (size_t k = 0; k < codigos.size(); ++k) {
            Sala* s = acharSala(codigos[k]);
            if (!s) continue;
            if (s->fase == FASE_MESTRE && s->prazo > 0 && agora >= s->prazo) { mestreDemorou(s); continue; }
            if (s->fase == FASE_JOGANDO && s->tempo > 0 && !s->pausada && s->prazo > 0 && agora >= s->prazo) {
                estourouTempo(s);
                continue;
            }
            for (size_t i = 0; i < s->membros.size(); ++i) {
                const Membro& m = s->membros[i];
                if (m.presente && m.desconectado && agora - m.desconectadoEm > TOLERANCIA_QUEDA_MS) {
                    string nome = m.nome;
                    removerMembro(s, static_cast<int>(i), nome + " nao voltou a tempo e saiu da sala.");
                    break;
                }
            }
        }
    }

    // ------------------------------------------------------------- comandos ---

    void tratarLinha(Conn* c, const string& linha) {
        vector<string> p = dividir(linha, '|');
        const string& cmd = p[0];

        if (cmd == "PONG") return;

        if (!c->logado) {
            if (cmd != "HELLO") { enviar(c, "ERROR|Envie HELLO primeiro."); return; }
            cmdHello(c, p);
            return;
        }

        if (cmd == "LIST")          cmdListar(c);
        else if (cmd == "RANKING")  cmdRanking(c);
        else if (cmd == "CREATE")   cmdCriar(c, p);
        else if (cmd == "JOIN")     cmdEntrar(c, p);
        else if (cmd == "LEAVE")    cmdSair(c);
        else if (cmd == "START")    cmdIniciar(c);
        else if (cmd == "CONFIG")   cmdConfig(c, p);
        else if (cmd == "CHAT")     cmdChat(c, linha);
        else if (cmd == "LETTER")   cmdLetra(c, p);
        else if (cmd == "WORD")     cmdPalavra(c, p);
        else if (cmd == "SETWORD")  cmdPalavraMestre(c, p);
        else if (cmd == "SPEC")     cmdEspectar(c, p);
        else if (cmd == "TEAM")     cmdEquipe(c, p);
        else if (cmd == "KICK")     cmdExpulsar(c, p);
        else if (cmd == "HOST")     cmdDono(c, p);
        else enviar(c, "ERROR|Comando desconhecido.");
    }

    bool acharPorToken(const string& token, const string& nome, Sala** sOut, int* idxOut) {
        string alvo = paraMinusculas(nome);
        for (map<string, Sala*>::iterator it = salas.begin(); it != salas.end(); ++it) {
            Sala* s = it->second;
            for (size_t i = 0; i < s->membros.size(); ++i) {
                const Membro& m = s->membros[i];
                if (m.presente && m.token == token && paraMinusculas(m.nome) == alvo) {
                    *sOut = s;
                    *idxOut = static_cast<int>(i);
                    return true;
                }
            }
        }
        return false;
    }

    void cmdHello(Conn* c, const vector<string>& p) {
        string nome = sanitizarNome(p.size() > 1 ? p[1] : "");
        int versao = p.size() > 2 ? atoi(p[2].c_str()) : 0;
        string token = p.size() > 3 ? p[3] : "";
        if (versao != VERSAO_PROTOCOLO) {
            enviar(c, "ERROR|Versao do jogo incompativel. Use a mesma versao do servidor.");
            return;
        }
        if (nome.empty()) { enviar(c, "ERROR|Digite um nome."); return; }

        if (!token.empty()) {
            Sala* s = NULL;
            int idx = -1;
            if (acharPorToken(token, nome, &s, &idx)) { reanexar(c, s, idx); return; }
            enviar(c, "NOSESSION");   // sessao antiga nao existe mais: segue como login normal
        }

        if (nomeEmUso(nome)) { enviar(c, "ERROR|O nome '" + nome + "' ja esta em uso neste servidor."); return; }
        c->nome = nome;
        c->logado = true;
        c->token = gerarToken();
        enviar(c, "WELCOME|" + nome + "|" + c->token);
        enviar(c, catsMsg());
        log(nome + " entrou no servidor");
    }

    // Jogador que caiu volta para a mesma vaga.
    void reanexar(Conn* c, Sala* s, int idx) {
        Conn* velha = porId(s->membros[idx].connId);
        if (velha && velha != c) { velha->sala.clear(); velha->morto = true; }

        Membro& m = s->membros[idx];
        m.connId = c->id;
        m.desconectado = false;
        c->nome = m.nome;
        c->logado = true;
        c->token = m.token;
        c->sala = s->codigo;
        string nome = m.nome;

        enviar(c, "WELCOME|" + nome + "|" + c->token);
        enviar(c, catsMsg());
        enviar(c, "JOINED|" + s->codigo + "|1");
        enviarRoomInfo(s, c);
        enviarHistorico(s, c);
        if (!s->champBloco.empty() && s->fase == FASE_ESPERA) enviar(c, s->champBloco);
        if (s->rodada > 0) enviarEstado(s, c);
        paraSala(s, "SYS|" + nome + " voltou para a sala.", c->id);
        enviarRoster(s);
        log(nome + " reconectou na sala " + s->codigo);

        if (s->fase == FASE_JOGANDO && s->pausada) {
            s->pausada = false;
            if (!ativo(s->membros[s->turno])) {
                if (avancarTurno(s) == 0) { fimRodada(s, 3, -1); return; }
            }
            iniciarPrazo(s);
            enviarEstado(s);
        } else if (s->fase == FASE_MESTRE && s->membros[idx].mestre) {
            enviar(c, "SYS|Voce voltou: ainda e a sua vez de escolher a palavra.");
            enviarEstado(s);
        }
    }

    void cmdListar(Conn* c) {
        for (map<string, Sala*>::iterator it = salas.begin(); it != salas.end(); ++it) {
            Sala* s = it->second;
            if (!s->publica) continue;
            enviar(c, "ROOM|" + s->codigo + "|" + nomeDoDono(s) + "|" + itos(contarPresentes(s)) + "|" +
                      itos(s->max) + "|" + (s->categoria.empty() ? string("Aleatoria") : s->categoria) + "|" +
                      (s->fase != FASE_ESPERA ? "1" : "0") + "|" + itos(static_cast<long>(s->espec.size())));
        }
        enviar(c, "ROOMS_END");
    }

    void cmdRanking(Conn* c) {
        vector<RankEntrada> t = ranking.top(10);
        for (size_t i = 0; i < t.size(); ++i)
            enviar(c, "RANK|" + itos(static_cast<long>(i + 1)) + "|" + t[i].nome + "|" + itos(t[i].pontos) +
                      "|" + itos(t[i].vitorias) + "|" + itos(t[i].rodadas));
        enviar(c, "RANK_END|" + itos(static_cast<long>(ranking.total())));
    }

    int proximaEquipe(Sala* s) {
        int a = 0, b = 0;
        for (size_t i = 0; i < s->membros.size(); ++i) {
            if (!s->membros[i].presente) continue;
            if (s->membros[i].equipe == 0) ++a; else ++b;
        }
        return a <= b ? 0 : 1;
    }

    void entrarNaSala(Conn* c, Sala* s) {
        Membro m;
        m.connId = c->id;
        m.nome = c->nome;
        m.token = c->token;
        m.equipe = proximaEquipe(s);
        s->membros.push_back(m);
        c->sala = s->codigo;
        enviar(c, "JOINED|" + s->codigo + "|0");
        enviarRoomInfo(s, c);
        enviarHistorico(s, c);
        paraSala(s, "SYS|" + c->nome + " entrou na sala.", c->id);
        enviarRoomInfo(s);
        enviarRoster(s);
        log(c->nome + " entrou na sala " + s->codigo);
    }

    void entrarComoEspectador(Conn* c, Sala* s, bool voluntario) {
        Espec e;
        e.connId = c->id;
        e.nome = c->nome;
        e.voluntario = voluntario;
        s->espec.push_back(e);
        c->sala = s->codigo;
        enviar(c, "JOINED|" + s->codigo + "|0");
        enviar(c, voluntario ? "SYS|Voce esta assistindo. Use /jogar quando quiser entrar na partida (se houver vaga)."
                             : "SYS|Voce esta na fila: entra como jogador quando o dono iniciar a proxima rodada (se houver vaga).");
        enviarRoomInfo(s, c);
        enviarHistorico(s, c);
        if (s->rodada > 0) {
            if (!s->champBloco.empty()) enviar(c, s->champBloco);
            enviarEstado(s, c);
        }
        paraSala(s, "SYS|" + c->nome + " esta assistindo.", c->id);
        enviarRoomInfo(s);
        enviarRoster(s);
        log(c->nome + " assiste a sala " + s->codigo);
    }

    void cmdCriar(Conn* c, const vector<string>& p) {
        if (!c->sala.empty()) { enviar(c, "ERROR|Voce ja esta em uma sala. Use /sair antes."); return; }
        int max = p.size() > 1 ? atoi(p[1].c_str()) : PADRAO_JOGADORES;
        if (max < MIN_JOGADORES) max = MIN_JOGADORES;
        if (max > MAX_JOGADORES) max = MAX_JOGADORES;
        string cat = p.size() > 2 ? aparar(p[2]) : "";
        if (!cat.empty()) {
            string achada = banco.acharCategoria(cat);
            if (achada.empty()) { enviar(c, "ERROR|Categoria desconhecida."); return; }
            cat = achada;
        }
        bool pub = !(p.size() > 3 && p[3] == "0");

        Sala* s = new Sala();
        s->codigo = gerarCodigo();
        s->max = max;
        s->categoria = cat;
        s->publica = pub;
        s->hostLc = paraMinusculas(c->nome);
        salas[s->codigo] = s;
        log(c->nome + " criou a sala " + s->codigo);
        entrarNaSala(c, s);
    }

    void cmdEntrar(Conn* c, const vector<string>& p) {
        if (!c->sala.empty()) { enviar(c, "ERROR|Voce ja esta em uma sala. Use /sair antes."); return; }
        string codigo = paraMaiusculas(aparar(p.size() > 1 ? p[1] : ""));
        bool querAssistir = p.size() > 2 && p[2] == "1";
        Sala* s = acharSala(codigo);
        if (!s) { enviar(c, "ERROR|Sala '" + codigo + "' nao encontrada."); return; }
        if (s->banidos.count(paraMinusculas(c->nome))) { enviar(c, "ERROR|Voce foi expulso da sala " + codigo + "."); return; }

        bool podeJogar = !querAssistir && s->fase == FASE_ESPERA && contarPresentes(s) < s->max;
        if (podeJogar) { entrarNaSala(c, s); return; }
        if (static_cast<int>(s->espec.size()) >= MAX_ESPECTADORES) {
            enviar(c, "ERROR|A sala " + codigo + " esta lotada (jogadores e espectadores).");
            return;
        }
        entrarComoEspectador(c, s, querAssistir);
    }

    void cmdSair(Conn* c) {
        Sala* s = salaDe(c);
        if (!s) { enviar(c, "ERROR|Voce nao esta em nenhuma sala."); return; }
        string nome = c->nome;
        c->sala.clear();
        sairVoluntario(s, nome);
        enviar(c, "LEFT");
    }

    void sairVoluntario(Sala* s, const string& nome) {
        int ie = idxEspec(s, nome);
        if (ie >= 0) { removerEspectador(s, ie, nome + " parou de assistir."); return; }
        int i = idxMembro(s, nome);
        if (i >= 0) removerMembro(s, i, nome + " saiu da sala.");
    }

    // ---------------------------------------------------------- configuracao ---

    void descricaoConfig(Sala* s, const string& chave) {
        (void)chave;
        string t = "Sala: ate " + itos(s->max) + " jogadores - " +
                   (s->categoria.empty() ? string("categoria aleatoria") : "categoria " + s->categoria) +
                   " - " + nomeNivel(s->dificuldade) + " - " +
                   (s->tempo > 0 ? itos(s->tempo) + "s por jogada" : string("sem limite de tempo")) + " - " +
                   textoPartida(s->partidaTipo, s->partidaValor) + (s->equipes ? " - EQUIPES" : "") +
                   (s->modoPalavra == 1 ? " - palavra do jogador" : "");
        sys(s, t);
    }

    void reequilibrarEquipes(Sala* s) {
        int k = 0;
        for (size_t i = 0; i < s->membros.size(); ++i)
            if (s->membros[i].presente) s->membros[i].equipe = (k++) % 2;
    }

    void cmdConfig(Conn* c, const vector<string>& p) {
        Sala* s = salaDe(c);
        if (!s) { enviar(c, "ERROR|Voce nao esta em uma sala."); return; }
        if (!ehHost(s, c)) { enviar(c, "ERROR|Somente o dono da sala pode mudar a configuracao."); return; }
        if (s->fase != FASE_ESPERA) { enviar(c, "ERROR|Nao da para mudar a configuracao no meio da rodada."); return; }
        string k = p.size() > 1 ? p[1] : "";
        string v = p.size() > 2 ? aparar(p[2]) : "";

        if (k == "max") {
            int n = atoi(v.c_str());
            if (n < MIN_JOGADORES || n > MAX_JOGADORES) { enviar(c, "ERROR|O maximo deve ser de 2 a 6 jogadores."); return; }
            if (n < contarPresentes(s)) { enviar(c, "ERROR|Ja ha " + itos(contarPresentes(s)) + " jogadores na sala."); return; }
            if (s->equipes && (n % 2 != 0 || n < 4)) { enviar(c, "ERROR|Com equipes use 4 ou 6 jogadores."); return; }
            s->max = n;
        } else if (k == "cat") {
            if (!v.empty()) {
                string achada = banco.acharCategoria(v);
                if (achada.empty()) { enviar(c, "ERROR|Categoria desconhecida."); return; }
                v = achada;
            }
            s->categoria = v;
        } else if (k == "pub") {
            s->publica = (v == "1");
        } else if (k == "dif") {
            int n = atoi(v.c_str());
            if (n < 0 || n > 3) { enviar(c, "ERROR|Dificuldade: 0 (todas), 1 (facil), 2 (medio) ou 3 (dificil)."); return; }
            s->dificuldade = n;
        } else if (k == "tempo") {
            int n = atoi(v.c_str());
            if (n != 0 && (n < 10 || n > 120)) { enviar(c, "ERROR|O tempo por jogada deve ser 0 (sem limite) ou de 10 a 120 segundos."); return; }
            s->tempo = n;
        } else if (k == "partida") {
            vector<string> q = dividir(v, ':');
            if (q[0] == "livre") {
                s->partidaTipo = PART_LIVRE;
                s->partidaValor = 0;
            } else if (q[0] == "melhor" && q.size() > 1) {
                int n = atoi(q[1].c_str());
                if (n < 1 || n > 15) { enviar(c, "ERROR|Melhor de quantas rodadas? Use de 1 a 15 (ex.: melhor 5)."); return; }
                s->partidaTipo = PART_MELHOR;
                s->partidaValor = n;
            } else if (q[0] == "pontos" && q.size() > 1) {
                int n = atoi(q[1].c_str());
                if (n < 10 || n > 500) { enviar(c, "ERROR|A meta deve ser de 10 a 500 pontos (ex.: pontos 50)."); return; }
                s->partidaTipo = PART_PONTOS;
                s->partidaValor = n;
            } else {
                enviar(c, "ERROR|Use: livre, melhor N ou pontos N.");
                return;
            }
        } else if (k == "equipes") {
            if (v == "1") {
                if (s->modoPalavra == 1) { s->modoPalavra = 0; sys(s, "Modo 'palavra do jogador' desligado (nao combina com equipes)."); }
                if (s->max < 4) s->max = 4;
                if (s->max % 2) s->max = 6;
                s->equipes = true;
                reequilibrarEquipes(s);
            } else {
                s->equipes = false;
            }
        } else if (k == "modo") {
            if (v == "1") {
                if (s->equipes) { s->equipes = false; sys(s, "Equipes desligadas (nao combinam com 'palavra do jogador')."); }
                s->modoPalavra = 1;
            } else {
                s->modoPalavra = 0;
            }
        } else {
            enviar(c, "ERROR|Opcao de configuracao desconhecida.");
            return;
        }
        descricaoConfig(s, k);
        enviarRoomInfo(s);
        enviarRoster(s);
    }

    void cmdEquipe(Conn* c, const vector<string>& p) {
        Sala* s = salaDe(c);
        if (!s) { enviar(c, "ERROR|Voce nao esta em uma sala."); return; }
        if (!s->equipes) { enviar(c, "ERROR|A sala nao esta no modo equipes (o dono usa /equipes on)."); return; }
        if (s->fase != FASE_ESPERA) { enviar(c, "ERROR|Nao da para trocar de time no meio da rodada."); return; }
        int i = idxMembro(s, c->nome);
        if (i < 0) { enviar(c, "ERROR|Espectadores nao tem time."); return; }
        int e = (p.size() > 1 && p[1] == "1") ? 1 : 0;
        s->membros[i].equipe = e;
        sys(s, c->nome + " foi para o Time " + (e == 0 ? "A" : "B") + ".");
        enviarRoster(s);
    }

    void cmdEspectar(Conn* c, const vector<string>& p) {
        Sala* s = salaDe(c);
        if (!s) { enviar(c, "ERROR|Voce nao esta em uma sala."); return; }
        if (s->fase != FASE_ESPERA) { enviar(c, "ERROR|So da para trocar entre jogar e assistir fora de uma rodada."); return; }
        bool assistir = (p.size() > 1 && p[1] == "1");
        int ie = idxEspec(s, c->nome);
        int im = idxMembro(s, c->nome);
        if (assistir) {
            if (ie >= 0) { enviar(c, "ERROR|Voce ja esta assistindo."); return; }
            if (im < 0) return;
            if (static_cast<int>(s->espec.size()) >= MAX_ESPECTADORES) { enviar(c, "ERROR|Nao ha vaga de espectador."); return; }
            if (s->membros[im].desconectado) return;
            bool eraHost = ehHost(s, c);
            string nome = c->nome;
            s->membros.erase(s->membros.begin() + im);
            Espec e;
            e.connId = c->id;
            e.nome = nome;
            e.voluntario = true;
            s->espec.push_back(e);
            sys(s, nome + " agora esta assistindo.");
            if (eraHost && contarPresentes(s) > 0) promoverHost(s);
            if (contarPresentes(s) == 0) {   // ninguem mais joga: quem assiste vira jogador
                promoverEspectadores(s, true);
                if (!ehHostPresente(s)) promoverHost(s);
            }
            enviarRoomInfo(s);
            enviarRoster(s);
        } else {
            if (im >= 0) { enviar(c, "ERROR|Voce ja e jogador."); return; }
            if (ie < 0) return;
            if (contarPresentes(s) >= s->max) { enviar(c, "ERROR|Nao ha vaga de jogador na sala."); return; }
            Membro m;
            m.connId = c->id;
            m.nome = c->nome;
            m.token = c->token;
            m.equipe = proximaEquipe(s);
            s->espec.erase(s->espec.begin() + ie);
            s->membros.push_back(m);
            sys(s, c->nome + " agora e jogador.");
            enviarRoomInfo(s);
            enviarRoster(s);
        }
    }

    bool ehHostPresente(Sala* s) {
        for (size_t i = 0; i < s->membros.size(); ++i)
            if (s->membros[i].presente && paraMinusculas(s->membros[i].nome) == s->hostLc) return true;
        return false;
    }

    void cmdExpulsar(Conn* c, const vector<string>& p) {
        Sala* s = salaDe(c);
        if (!s) { enviar(c, "ERROR|Voce nao esta em uma sala."); return; }
        if (!ehHost(s, c)) { enviar(c, "ERROR|Somente o dono da sala pode expulsar."); return; }
        string alvo = paraMinusculas(aparar(p.size() > 1 ? p[1] : ""));
        if (alvo.empty()) { enviar(c, "ERROR|Use /expulsar nome."); return; }
        if (alvo == paraMinusculas(c->nome)) { enviar(c, "ERROR|Voce nao pode expulsar a si mesmo."); return; }

        string nomeAlvo;
        int im = -1, ie = -1;
        for (size_t i = 0; i < s->membros.size() && im < 0; ++i)
            if (s->membros[i].presente && paraMinusculas(s->membros[i].nome).compare(0, alvo.size(), alvo) == 0) im = static_cast<int>(i);
        if (im < 0)
            for (size_t i = 0; i < s->espec.size() && ie < 0; ++i)
                if (paraMinusculas(s->espec[i].nome).compare(0, alvo.size(), alvo) == 0) ie = static_cast<int>(i);
        if (im < 0 && ie < 0) { enviar(c, "ERROR|Jogador '" + p[1] + "' nao encontrado na sala."); return; }

        nomeAlvo = im >= 0 ? s->membros[im].nome : s->espec[ie].nome;
        int alvoConn = im >= 0 ? s->membros[im].connId : s->espec[ie].connId;
        s->banidos.insert(paraMinusculas(nomeAlvo));
        Conn* ca = porId(alvoConn);
        if (ca) {
            enviar(ca, "KICKED|Voce foi expulso da sala " + s->codigo + " por " + c->nome + ".");
            enviar(ca, "LEFT");
            ca->sala.clear();
        }
        log(c->nome + " expulsou " + nomeAlvo + " da sala " + s->codigo);
        if (im >= 0) removerMembro(s, im, nomeAlvo + " foi expulso da sala.");
        else removerEspectador(s, ie, nomeAlvo + " foi expulso da sala.");
    }

    void cmdDono(Conn* c, const vector<string>& p) {
        Sala* s = salaDe(c);
        if (!s) { enviar(c, "ERROR|Voce nao esta em uma sala."); return; }
        if (!ehHost(s, c)) { enviar(c, "ERROR|Somente o dono da sala pode passar o comando."); return; }
        string alvo = paraMinusculas(aparar(p.size() > 1 ? p[1] : ""));
        if (alvo.empty()) { enviar(c, "ERROR|Use /dono nome."); return; }
        string nomeAlvo;
        for (size_t i = 0; i < s->membros.size() && nomeAlvo.empty(); ++i)
            if (s->membros[i].presente && !s->membros[i].desconectado &&
                paraMinusculas(s->membros[i].nome).compare(0, alvo.size(), alvo) == 0) nomeAlvo = s->membros[i].nome;
        for (size_t i = 0; i < s->espec.size() && nomeAlvo.empty(); ++i)
            if (paraMinusculas(s->espec[i].nome).compare(0, alvo.size(), alvo) == 0) nomeAlvo = s->espec[i].nome;
        if (nomeAlvo.empty()) { enviar(c, "ERROR|Jogador '" + p[1] + "' nao encontrado (ou desconectado)."); return; }
        if (paraMinusculas(nomeAlvo) == s->hostLc) { enviar(c, "ERROR|Voce ja e o dono."); return; }
        s->hostLc = paraMinusculas(nomeAlvo);
        sys(s, nomeAlvo + " agora e o dono da sala.");
        log(c->nome + " passou o dono da sala " + s->codigo + " para " + nomeAlvo);
        enviarRoomInfo(s);
        enviarRoster(s);
    }

    void cmdChat(Conn* c, const string& linhaInteira) {
        Sala* s = salaDe(c);
        if (!s) { enviar(c, "ERROR|Entre em uma sala para conversar."); return; }
        string texto = sanitizarTexto(linhaInteira.size() > 5 ? linhaInteira.substr(5) : "", 200);
        if (texto.empty()) return;
        s->historico.push_back(c->nome + "|" + texto);
        while (static_cast<int>(s->historico.size()) > MAX_HISTORICO_SALA) s->historico.pop_front();
        paraSala(s, "CHATMSG|" + c->nome + "|" + texto);
    }

    // ------------------------------------------------------------ sair/cair ---

    void promoverHost(Sala* s) {
        for (int passo = 0; passo < 2; ++passo) {
            for (size_t i = 0; i < s->membros.size(); ++i) {
                const Membro& m = s->membros[i];
                if (!m.presente || (passo == 0 && m.desconectado)) continue;
                s->hostLc = paraMinusculas(m.nome);
                sys(s, m.nome + " agora e o dono da sala.");
                return;
            }
        }
        if (!s->espec.empty()) {
            s->hostLc = paraMinusculas(s->espec[0].nome);
            sys(s, s->espec[0].nome + " agora e o dono da sala.");
        }
    }

    // Passa espectadores a jogadores. Quem escolheu so assistir fica de fora, a menos que 'todos' seja true
    // (usado quando nao sobrou nenhum jogador na sala).
    void promoverEspectadores(Sala* s, bool todos = false) {
        for (size_t k = 0; k < s->espec.size() && contarPresentes(s) < s->max;) {
            if (s->espec[k].voluntario && !todos) { ++k; continue; }
            Espec e = s->espec[k];
            s->espec.erase(s->espec.begin() + k);
            Membro m;
            m.connId = e.connId;
            m.nome = e.nome;
            Conn* c = porId(e.connId);
            if (c) m.token = c->token;
            m.equipe = proximaEquipe(s);
            s->membros.push_back(m);
            sys(s, e.nome + " entrou como jogador.");
        }
    }

    void destruirSala(Sala* s) {
        log("Sala " + s->codigo + " encerrada");
        string cod = s->codigo;
        salas.erase(cod);
        delete s;
    }

    void removerEspectador(Sala* s, int ie, const string& texto) {
        string nome = s->espec[ie].nome;
        Conn* c = porId(s->espec[ie].connId);
        if (c) c->sala.clear();
        bool eraHost = paraMinusculas(nome) == s->hostLc;
        s->espec.erase(s->espec.begin() + ie);
        if (s->membros.empty() && s->espec.empty()) { destruirSala(s); return; }
        if (eraHost) promoverHost(s);
        sys(s, texto);
        enviarRoomInfo(s);
        enviarRoster(s);
    }

    // Jogador caiu da conexao: guarda a vaga por um tempo.
    void aoDesconectar(Conn* c) {
        Sala* s = salaDe(c);
        if (!s) return;
        int ie = idxEspec(s, c->nome);
        if (ie >= 0) { removerEspectador(s, ie, c->nome + " parou de assistir."); return; }
        int i = idxMembro(s, c->nome);
        if (i < 0) return;
        Membro& m = s->membros[i];
        if (m.connId != c->id) return;
        m.desconectado = true;
        m.connId = 0;
        m.desconectadoEm = agoMs();
        c->sala.clear();
        log(m.nome + " perdeu a conexao na sala " + s->codigo);
        sys(s, m.nome + " perdeu a conexao (tem 2 minutos para voltar sem perder pontos).");
        enviarRoster(s);

        if (s->fase == FASE_JOGANDO && s->turno == i) passarVez(s);
        else if (s->fase == FASE_MESTRE && s->membros[i].mestre) palavraAutomatica(s, "O mestre caiu da conexao");
        else if (s->fase != FASE_ESPERA) enviarEstado(s);
    }

    // Remove um jogador da sala (saiu, foi expulso ou nao voltou a tempo). A sala pode ser destruida aqui.
    void removerMembro(Sala* s, int idx, const string& texto) {
        string nome = s->membros[idx].nome;
        bool eraHost = paraMinusculas(nome) == s->hostLc;
        Conn* c = porId(s->membros[idx].connId);
        if (c) c->sala.clear();
        log(nome + " saiu da sala " + s->codigo);

        if (s->fase != FASE_ESPERA) {
            Membro& m = s->membros[idx];
            m.presente = false;
            m.eliminado = true;
            m.desconectado = false;
            m.connId = 0;
            sys(s, texto);
            if (eraHost) promoverHost(s);
            enviarRoomInfo(s);
            enviarRoster(s);
            avaliarAposSaida(s, idx);
        } else {
            if (s->equipes) {
                s->pontosSaidos[s->membros[idx].equipe] += s->membros[idx].pontos;
            }
            s->membros.erase(s->membros.begin() + idx);
            if (s->membros.empty() && s->espec.empty()) { destruirSala(s); return; }
            if (s->membros.empty()) promoverEspectadores(s, true);
            if (eraHost || !ehHostPresente(s)) promoverHost(s);
            sys(s, texto);
            enviarRoomInfo(s);
            enviarRoster(s);
        }
    }

    // Depois que alguem saiu no meio da rodada.
    void avaliarAposSaida(Sala* s, int idxQueSaiu) {
        int presentes = 0, adivinhando = 0, ativos = 0;
        int porEquipe[2] = {0, 0};
        for (size_t k = 0; k < s->membros.size(); ++k) {
            const Membro& m = s->membros[k];
            if (!m.presente) continue;
            ++presentes;
            porEquipe[m.equipe]++;
            if (!m.mestre) {
                ++adivinhando;
                if (!m.eliminado) ++ativos;
            }
        }
        if (presentes < MIN_JOGADORES || adivinhando < 1 || (s->equipes && (porEquipe[0] == 0 || porEquipe[1] == 0))) {
            fimRodada(s, 4, -1);
            return;
        }
        if (s->fase == FASE_MESTRE) {
            if (s->mestreIdx == idxQueSaiu) palavraAutomatica(s, "O mestre saiu");
            else enviarEstado(s);
            return;
        }
        if (ativos == 0) { fimRodada(s, 3, -1); return; }
        if (s->turno == idxQueSaiu) passarVez(s);
        else enviarEstado(s);
    }

    // ---------------------------------------------------------------- jogo ---

    void definirPalavra(Sala* s, const Entrada& e, const string& cat) {
        s->disp = e.disp;
        s->palavra = e.base;
        s->glifos = glifosUtf8(e.disp);
        s->bases.clear();
        for (size_t i = 0; i < s->glifos.size(); ++i) s->bases.push_back(baseDoGlifo(s->glifos[i]));
        s->palavraCat = cat;
        s->usadas.clear();
        s->restantes = contarLetrasRestantes(s->palavra, s->usadas);
    }

    void iniciarPrazo(Sala* s) {
        s->prazo = s->tempo > 0 ? agoMs() + static_cast<long long>(s->tempo) * 1000 : 0;
    }

    void montarOrdem(Sala* s) {
        s->ordem.clear();
        if (s->equipes) {
            vector<int> a, b;
            for (size_t i = 0; i < s->membros.size(); ++i) {
                if (!s->membros[i].presente || s->membros[i].mestre) continue;
                (s->membros[i].equipe == 0 ? a : b).push_back(static_cast<int>(i));
            }
            size_t m = a.size() > b.size() ? a.size() : b.size();
            for (size_t k = 0; k < m; ++k) {
                if (k < a.size()) s->ordem.push_back(a[k]);
                if (k < b.size()) s->ordem.push_back(b[k]);
            }
        } else {
            for (size_t i = 0; i < s->membros.size(); ++i)
                if (s->membros[i].presente && !s->membros[i].mestre) s->ordem.push_back(static_cast<int>(i));
        }
    }

    // Passa a vez ao proximo jogador ativo.
    // 0 = ninguem pode jogar (rodada acabou), 1 = vez passou, 2 = so ha jogadores desconectados (pausa).
    int avancarTurno(Sala* s) {
        int n = static_cast<int>(s->ordem.size());
        if (n == 0) return 0;
        int pos = 0;
        for (int i = 0; i < n; ++i) if (s->ordem[i] == s->turno) pos = i;
        bool temOffline = false;
        for (int k = 1; k <= n; ++k) {
            int j = s->ordem[(pos + k) % n];
            const Membro& m = s->membros[j];
            if (ativo(m)) { s->turno = j; s->pausada = false; return 1; }
            if (m.presente && !m.eliminado && !m.mestre && m.desconectado) temOffline = true;
        }
        if (temOffline) { s->pausada = true; s->prazo = 0; return 2; }
        return 0;
    }

    void escolherPrimeiroTurno(Sala* s) {
        montarOrdem(s);
        if (s->ordem.empty()) { s->turno = 0; return; }
        s->turno = s->ordem[static_cast<size_t>((s->rodada - 1) % static_cast<int>(s->ordem.size()))];
        if (!ativo(s->membros[s->turno])) avancarTurno(s);
    }

    // Depois de uma jogada (ou queda, ou tempo esgotado) passa a vez e avisa todo mundo.
    void passarVez(Sala* s) {
        int r = avancarTurno(s);
        if (r == 0) { fimRodada(s, 3, -1); return; }
        if (r == 1) iniciarPrazo(s);
        enviarEstado(s);
    }

    void estourouTempo(Sala* s) {
        int idx = s->turno;
        Membro& m = s->membros[idx];
        m.inativo++;
        string nome = m.nome;
        if (m.inativo >= MAX_INATIVO) {
            m.eliminado = true;
            evento(s, "timeout", idx, 0, nome + " ficou sem jogar " + itos(MAX_INATIVO) + " vezes seguidas e foi eliminado.");
        } else {
            evento(s, "timeout", idx, 0, nome + " demorou demais e perdeu a vez.");
        }
        int ativos = 0;
        for (size_t k = 0; k < s->membros.size(); ++k) if (s->membros[k].presente && !s->membros[k].eliminado && !s->membros[k].mestre) ++ativos;
        if (ativos == 0) { fimRodada(s, 3, -1); return; }
        passarVez(s);
    }

    void mestreDemorou(Sala* s) { palavraAutomatica(s, "O tempo para escolher a palavra acabou"); }

    // O mestre nao escolheu (ou saiu): sorteia uma palavra e a rodada segue normal.
    void palavraAutomatica(Sala* s, const string& motivo) {
        if (s->mestreIdx >= 0 && s->mestreIdx < static_cast<int>(s->membros.size()))
            s->membros[s->mestreIdx].mestre = false;
        s->mestreIdx = -1;
        sys(s, motivo + ": a palavra foi sorteada.");
        sortearECome(s);
    }

    void sortearECome(Sala* s) {
        string cat;
        bool relaxou = false;
        Entrada e = banco.sortearPalavra(s->categoria, s->dificuldade, s->palavrasUsadas, cat, relaxou);
        if (relaxou) sys(s, "Nao ha palavras desse tamanho nesta categoria: sorteei de qualquer tamanho.");
        definirPalavra(s, e, cat);
        comecarJogo(s);
    }

    void comecarJogo(Sala* s) {
        s->fase = FASE_JOGANDO;
        s->pausada = false;
        escolherPrimeiroTurno(s);
        iniciarPrazo(s);
        log("Sala " + s->codigo + ": rodada " + itos(s->rodada) + " (" + s->palavraCat + ", " + itos(static_cast<long>(s->palavra.size())) + " letras)");
        evento(s, "start", -1, 0, "Rodada " + itos(s->rodada) + " comecou! Categoria: " + s->palavraCat +
                                   " - " + itos(static_cast<long>(s->palavra.size())) + " letras");
        enviarEstado(s);
    }

    void novaPartida(Sala* s) {
        for (size_t i = 0; i < s->membros.size(); ++i) {
            s->membros[i].pontos = 0;
            s->membros[i].vitorias = 0;
        }
        s->vitEquipe[0] = s->vitEquipe[1] = 0;
        s->pontosSaidos[0] = s->pontosSaidos[1] = 0;
        s->rodada = 0;
        s->fimPartida = false;
        s->champBloco.clear();
    }

    void cmdIniciar(Conn* c) {
        Sala* s = salaDe(c);
        if (!s) { enviar(c, "ERROR|Voce nao esta em uma sala."); return; }
        if (!ehHost(s, c)) { enviar(c, "ERROR|Somente o dono da sala pode iniciar a rodada."); return; }
        if (s->fase != FASE_ESPERA) { enviar(c, "ERROR|A rodada ja esta em andamento."); return; }

        promoverEspectadores(s);
        int conectados = 0;
        for (size_t i = 0; i < s->membros.size(); ++i)
            if (s->membros[i].presente && !s->membros[i].desconectado) ++conectados;
        if (conectados < MIN_JOGADORES) { enviar(c, "ERROR|Sao necessarios pelo menos 2 jogadores conectados para comecar."); return; }
        if (s->equipes) {
            int a = 0, b = 0;
            for (size_t i = 0; i < s->membros.size(); ++i) {
                if (!s->membros[i].presente) continue;
                if (s->membros[i].equipe == 0) ++a; else ++b;
            }
            if (a != b || a < 2 || a > 3) {
                enviar(c, "ERROR|Equipes precisam de 2x2 ou 3x3 jogadores (Time A: " + itos(a) + ", Time B: " + itos(b) + "). Use /time A ou /time B.");
                enviarRoomInfo(s);
                enviarRoster(s);
                return;
            }
        }
        if (s->fimPartida || s->rodada == 0) novaPartida(s);
        iniciarRodada(s);
    }

    void iniciarRodada(Sala* s) {
        s->rodada++;
        s->fim = 0;
        s->vencedor = -1;
        s->mestreIdx = -1;
        s->usadas.clear();
        s->palavra.clear();
        s->disp.clear();
        s->glifos.clear();
        s->bases.clear();
        s->restantes = 0;
        s->turno = 0;
        s->pausada = false;
        for (size_t i = 0; i < s->membros.size(); ++i) {
            Membro& m = s->membros[i];
            m.erros = 0;
            m.eliminado = !m.presente;
            m.pontosRodada = 0;
            m.inativo = 0;
            m.mestre = false;
        }
        if (s->modoPalavra == 1) {
            int n = static_cast<int>(s->membros.size());
            int idx = -1;
            for (int k = 0; k < n && idx < 0; ++k) {
                int j = (s->rodada - 1 + k) % n;
                if (s->membros[j].presente && !s->membros[j].desconectado) idx = j;
            }
            if (idx >= 0) {
                s->mestreIdx = idx;
                s->membros[idx].mestre = true;
                s->fase = FASE_MESTRE;
                s->prazo = agoMs() + static_cast<long long>(TEMPO_MESTRE_SEG) * 1000;
                log("Sala " + s->codigo + ": rodada " + itos(s->rodada) + ", " + s->membros[idx].nome + " escolhe a palavra");
                evento(s, "start", -1, 0, "Rodada " + itos(s->rodada) + ": " + s->membros[idx].nome + " esta escolhendo a palavra secreta...");
                enviarEstado(s);
                return;
            }
        }
        sortearECome(s);
    }

    void aplicarErro(Sala* s, int idx, int pts, int erros) {
        Membro& m = s->membros[idx];
        m.pontos -= pts;
        m.pontosRodada -= pts;
        m.erros += erros;
        if (m.erros >= MAX_ERROS) {
            m.erros = MAX_ERROS;
            m.eliminado = true;
            sys(s, m.nome + " chegou a 8 erros e esta fora da rodada!");
        }
    }

    // Jogada valida feita: zera inatividade e passa a vez.
    void concluirJogada(Sala* s, int idx) {
        s->membros[idx].inativo = 0;
        passarVez(s);
    }

    void cmdLetra(Conn* c, const vector<string>& p) {
        Sala* s = salaDe(c);
        if (!s || s->fase != FASE_JOGANDO) { enviar(c, "ERROR|Nao ha rodada em andamento."); return; }
        int idx = idxMembro(s, c->nome);
        if (idx < 0 || s->turno != idx || !ativo(s->membros[idx])) { enviar(c, "ERROR|Nao e a sua vez."); return; }
        string t = normalizarPalavra(p.size() > 1 ? p[1] : "");   // aceita 'ã', 'É'... como a letra base
        if (t.size() != 1 || !isalpha(static_cast<unsigned char>(t[0]))) {
            enviar(c, "ERROR|Digite somente uma letra.");
            return;
        }
        char letra = static_cast<char>(tolower(static_cast<unsigned char>(t[0])));
        if (contem(s->usadas, letra)) {
            enviar(c, string("ERROR|A letra '") + letra + "' ja foi usada. Escolha outra.");
            return;
        }

        bool fase = faseFinal(s);
        s->usadas += letra;
        s->restantes = contarLetrasRestantes(s->palavra, s->usadas);
        Membro& m = s->membros[idx];

        if (contem(s->palavra, letra)) {
            int pts = fase ? PTS_LETRA_FINAL : PTS_LETRA;
            m.pontos += pts;
            m.pontosRodada += pts;
            evento(s, "hit", idx, letra, m.nome + " acertou '" + string(1, letra) + "' (+" + itos(pts) + ")");
            if (s->restantes == 0) { fimRodada(s, 1, idx); return; }
        } else {
            aplicarErro(s, idx, PTS_ERRO, 1);
            evento(s, "miss", idx, letra, m.nome + " errou '" + string(1, letra) + "' (-1)");
        }
        concluirJogada(s, idx);
    }

    // Chute da palavra inteira: vale a qualquer momento da rodada.
    void cmdPalavra(Conn* c, const vector<string>& p) {
        Sala* s = salaDe(c);
        if (!s || s->fase != FASE_JOGANDO) { enviar(c, "ERROR|Nao ha rodada em andamento."); return; }
        int idx = idxMembro(s, c->nome);
        if (idx < 0 || s->turno != idx || !ativo(s->membros[idx])) { enviar(c, "ERROR|Nao e a sua vez."); return; }
        string palpite = normalizarPalavra(p.size() > 1 ? p[1] : "");
        if (palpite.empty()) { enviar(c, "ERROR|Digite uma palavra valida."); return; }
        if (palpite.size() != s->palavra.size()) {
            enviar(c, "ERROR|A palavra tem " + itos(static_cast<long>(s->palavra.size())) + " letras (voce digitou " +
                      itos(static_cast<long>(palpite.size())) + "). Nada foi descontado.");
            return;
        }

        bool fase = faseFinal(s);
        int faltando = s->restantes;
        Membro& m = s->membros[idx];
        if (palpite == s->palavra) {
            int extra = faltando > FASE_FINAL_LETRAS ? (faltando - FASE_FINAL_LETRAS) * PTS_BONUS_LETRA_FALTANDO : 0;
            int pts = PTS_PALAVRA + extra;
            m.pontos += pts;
            m.pontosRodada += pts;
            evento(s, "wordhit", idx, 0, m.nome + " acertou a palavra inteira! (+" + itos(pts) + ")");
            fimRodada(s, 2, idx);
            return;
        }
        int pts = fase ? PTS_ERRO : PTS_ERRO_PALAVRA_CEDO;
        int erros = fase ? 1 : ERROS_PALAVRA_CEDO;
        aplicarErro(s, idx, pts, erros);
        evento(s, "wordmiss", idx, 0, m.nome + " chutou '" + palpite + "' e errou (-" + itos(pts) + " e +" + itos(erros) +
                                       (erros > 1 ? " erros)" : " erro)"));
        concluirJogada(s, idx);
    }

    void cmdPalavraMestre(Conn* c, const vector<string>& p) {
        Sala* s = salaDe(c);
        if (!s || s->fase != FASE_MESTRE) { enviar(c, "ERROR|Ninguem precisa escolher a palavra agora."); return; }
        int idx = idxMembro(s, c->nome);
        if (idx < 0 || s->mestreIdx != idx) { enviar(c, "ERROR|Quem escolhe a palavra e " +
                                              (s->mestreIdx >= 0 && s->mestreIdx < static_cast<int>(s->membros.size()) ? s->membros[s->mestreIdx].nome : string("outro jogador")) + "."); return; }
        Entrada e;
        e.disp = sanitizarExibicao(p.size() > 1 ? p[1] : "", 24);
        e.base = normalizarPalavra(e.disp);
        if (e.base.size() < 3 || e.base.size() > 20) {
            enviar(c, "ERROR|A palavra precisa ter de 3 a 20 letras (sem numeros ou simbolos).");
            return;
        }
        definirPalavra(s, e, "Palavra de " + c->nome);
        log("Sala " + s->codigo + ": " + c->nome + " escolheu a palavra");
        comecarJogo(s);
    }

    // ------------------------------------------------------- fim da rodada ---

    struct Unidade {
        string nome;
        int pontos, vit, equipe;
        Unidade() : pontos(0), vit(0), equipe(0) {}
    };

    static bool unidadeMelhorRodadas(const Unidade& a, const Unidade& b) {
        if (a.vit != b.vit) return a.vit > b.vit;
        return a.pontos > b.pontos;
    }
    static bool unidadeMelhorPontos(const Unidade& a, const Unidade& b) {
        if (a.pontos != b.pontos) return a.pontos > b.pontos;
        return a.vit > b.vit;
    }

    // Verifica se a partida (melhor de N / primeiro a X pontos) acabou. Se sim, envia o campeao.
    bool avaliarPartida(Sala* s) {
        if (s->partidaTipo == PART_LIVRE) return false;

        vector<Unidade> us;
        if (s->equipes) {
            for (int e = 0; e < 2; ++e) {
                Unidade u;
                u.equipe = e;
                u.pontos = s->pontosSaidos[e];
                u.vit = s->vitEquipe[e];
                string nomes;
                for (size_t i = 0; i < s->membros.size(); ++i) {
                    const Membro& m = s->membros[i];
                    if (!m.presente || m.equipe != e) continue;
                    u.pontos += m.pontos;
                    if (!nomes.empty()) nomes += ", ";
                    nomes += m.nome;
                }
                u.nome = string("Time ") + (e == 0 ? "A" : "B") + " (" + nomes + ")";
                us.push_back(u);
            }
        } else {
            for (size_t i = 0; i < s->membros.size(); ++i) {
                const Membro& m = s->membros[i];
                if (!m.presente) continue;
                Unidade u;
                u.nome = m.nome;
                u.pontos = m.pontos;
                u.vit = m.vitorias;
                u.equipe = m.equipe;
                us.push_back(u);
            }
        }
        if (us.empty()) return false;

        bool terminou = false;
        if (s->partidaTipo == PART_MELHOR) {
            int alvo = s->partidaValor / 2 + 1;
            for (size_t i = 0; i < us.size(); ++i) if (us[i].vit >= alvo) terminou = true;
            if (s->rodada >= s->partidaValor) terminou = true;
            sort(us.begin(), us.end(), unidadeMelhorRodadas);
        } else {
            for (size_t i = 0; i < us.size(); ++i) if (us[i].pontos >= s->partidaValor) terminou = true;
            sort(us.begin(), us.end(), unidadeMelhorPontos);
        }
        if (!terminou) return false;

        bool empate = false;
        if (us.size() > 1) {
            if (s->partidaTipo == PART_MELHOR) empate = (us[0].vit == us[1].vit && us[0].pontos == us[1].pontos);
            else empate = (us[0].pontos == us[1].pontos && us[0].vit == us[1].vit);
        }
        string bloco = "CHAMP|" + (empate ? string("") : us[0].nome) + "|" + itos(static_cast<long>(us.size())) + "|" +
                       textoPartida(s->partidaTipo, s->partidaValor);
        for (size_t i = 0; i < us.size(); ++i)
            bloco += "\nCH|" + itos(static_cast<long>(i + 1)) + "|" + us[i].nome + "|" + itos(us[i].pontos) + "|" + itos(us[i].vit);
        s->fimPartida = true;
        s->champBloco = bloco;
        paraSala(s, bloco);
        log("Sala " + s->codigo + ": partida encerrada. Campeao: " + (empate ? string("empate") : us[0].nome));
        return true;
    }

    // Termina a rodada. A sala pode ser destruida aqui: nao use 's' depois.
    // tipo: 1 palavra completa por letras, 2 chute da palavra, 3 todos eliminados, 4 cancelada
    void fimRodada(Sala* s, int tipo, int vencedor) {
        s->fase = FASE_ESPERA;
        s->pausada = false;
        s->prazo = 0;
        s->fim = tipo;
        s->vencedor = vencedor;

        if (vencedor >= 0) {
            Membro& w = s->membros[vencedor];
            w.vitorias++;
            if (s->equipes) s->vitEquipe[w.equipe]++;
        }
        string extra;
        if (tipo == 3 && s->mestreIdx >= 0 && s->mestreIdx < static_cast<int>(s->membros.size())) {
            Membro& mestre = s->membros[s->mestreIdx];
            if (mestre.presente) {
                mestre.pontos += PTS_MESTRE_VENCEU;
                mestre.pontosRodada += PTS_MESTRE_VENCEU;
                extra = " " + mestre.nome + " (mestre) ganha +" + itos(PTS_MESTRE_VENCEU) + "!";
            }
        }
        if (tipo != 4) {
            for (size_t i = 0; i < s->membros.size(); ++i)
                ranking.registrar(s->membros[i].nome, s->membros[i].pontosRodada, static_cast<int>(i) == vencedor);
            ranking.salvar();
        }

        string texto;
        if (tipo == 1) texto = s->membros[vencedor].nome + " descobriu a palavra!";
        else if (tipo == 2) texto = s->membros[vencedor].nome + " acertou a palavra inteira!";
        else if (tipo == 3) texto = "Ninguem acertou! A palavra era " + s->disp + "." + extra;
        else texto = "Rodada cancelada: jogadores insuficientes.";
        log("Sala " + s->codigo + ": " + texto);

        if (tipo != 4) avaliarPartida(s);
        evento(s, tipo == 3 || tipo == 4 ? "lose" : "win", vencedor, 0, texto);
        enviarEstado(s);

        // remove quem saiu durante a rodada
        for (size_t i = 0; i < s->membros.size();) {
            if (!s->membros[i].presente) {
                if (s->equipes) s->pontosSaidos[s->membros[i].equipe] += s->membros[i].pontos;
                s->membros.erase(s->membros.begin() + static_cast<long>(i));
            } else {
                ++i;
            }
        }
        for (size_t i = 0; i < s->membros.size(); ++i) s->membros[i].mestre = false;
        s->mestreIdx = -1;
        if (s->membros.empty() && s->espec.empty()) { destruirSala(s); return; }
        if (s->membros.empty()) promoverEspectadores(s, true);
        if (!ehHostPresente(s)) promoverHost(s);
        enviarRoomInfo(s);
        enviarRoster(s);
    }
};


static void* threadConexaoEntrada(void* arg) {
    ArgThread* a = static_cast<ArgThread*>(arg);
    Servidor* srv = a->srv;
    Conn* c = a->c;
    delete a;
    srv->loopConexao(c);
    return NULL;
}
static void* threadAceiteEntrada(void* arg) { static_cast<Servidor*>(arg)->loopAceite(); return NULL; }
static void* threadRelogioEntrada(void* arg) { static_cast<Servidor*>(arg)->loopRelogio(); return NULL; }

// ============================================================================
//  CLIENTE (interface em modo texto)
// ============================================================================

static const char* LOGO[] = {
    " _____ ___  ____   ____    _    ",
    "|  ___/ _ \\|  _ \\ / ___|  / \\   ",
    "| |_ | | | | |_) | |     / _ \\  ",
    "|  _|| |_| |  _ <| |___ / ___ \\ ",
    "|_|   \\___/|_| \\_\\\\____/_/   \\_\\"
};
static const int LOGO_LINHAS = 5;

static const int LARGURA = 76;

static string linhaDupla() { return string(LARGURA, '='); }
static string linhaSimples() { return string(LARGURA, '-'); }

static const char* TROFEU[] = {
    "       ___________       ",
    "      '._==_==_=_.'      ",
    "      .-\\:      /-.      ",
    "     | (|:.     |) |     ",
    "      '-|:.     |-'      ",
    "        \\::.    /        ",
    "         '::. .'         ",
    "           ) (           ",
    "         _.' '._         ",
    "        `\"\"\"\"\"\"\"`        "
};
static const int TROFEU_LINHAS = 10;

// Desenhos da forca. Estilo 0 e 1 sao os personagens originais dos Times 1 e 2.
static vector<string> desenhoForca(int erros, int estiloForca) {
    static const char* S0[9][3] = {
        { "      |", "      |", "      |" },
        { "  O   |", "      |", "      |" },
        { "  O   |", "  |   |", "      |" },
        { "  O   |", " /|   |", "      |" },
        { "  O   |", " /|\\  |", "      |" },
        { "  O   |", " /|\\  |", " /    |" },
        { "  O   |", " /|\\  |", " / \\  |" },
        { " _O   |", " /|\\  |", " / \\  |" },
        { "  X   |", " /|\\  |", " / \\  |" }
    };
    static const char* S1[9][3] = {
        { "      |", "      |", "      |" },
        { "  o   |", "      |", "      |" },
        { " [o]  |", "      |", "      |" },
        { " [o]  |", "  |   |", "      |" },
        { " [o]  |", " /|   |", "      |" },
        { " [o]  |", " /|\\  |", "      |" },
        { " [o]  |", " /|\\  |", " /    |" },
        { " [o]  |", " /|\\  |", " / \\  |" },
        { " [x]  |", " /|\\  |", " / \\  |" }
    };
    if (erros < 0) erros = 0;
    if (erros > MAX_ERROS) erros = MAX_ERROS;

    vector<string> d;
    d.push_back(estiloForca == 0 ? "  +---+" : "  .---.");
    d.push_back("  |   |");
    const char* (*t)[3] = (estiloForca == 0) ? S0 : S1;
    d.push_back(t[erros][0]);
    d.push_back(t[erros][1]);
    d.push_back(t[erros][2]);
    d.push_back("=========");
    return d;
}

// ---- reacoes rapidas -----------------------------------------------------------

struct Reacao {
    const char* cmd;
    const char* texto;
};

static const Reacao REACOES[] = {
    { "gg",    "GG! Bom jogo!" },
    { "boa",   "\\o/ Boa jogada!" },
    { "ops",   "Ops... :-(" },
    { "rs",    "kkkkk" },
    { "uau",   "Uau! :-O" },
    { "f",     "F" },
    { "vamos", "Vamos la! >:)" },
    { "calma", "Calma, calma..." },
    { "sorte", "Boa sorte! :-)" },
    { "ufa",   "Ufa! Foi por pouco :-S" }
};
static const int NUM_REACOES = sizeof(REACOES) / sizeof(REACOES[0]);

static const char* acharReacao(const string& cmd) {
    for (int i = 0; i < NUM_REACOES; ++i)
        if (cmd == REACOES[i].cmd) return REACOES[i].texto;
    return NULL;
}

// ":gg:" no meio de uma mensagem vira o texto da reacao.
static string expandirReacoes(const string& msg) {
    string r = msg;
    for (int i = 0; i < NUM_REACOES; ++i) {
        string chave = string(":") + REACOES[i].cmd + ":";
        size_t pos = 0;
        while ((pos = r.find(chave, pos)) != string::npos) {
            r.replace(pos, chave.size(), REACOES[i].texto);
            pos += strlen(REACOES[i].texto);
        }
    }
    return r;
}

// ---- sessao salva (reconexao depois de fechar/cair) ----------------------------

struct SessaoSalva {
    string ip, nome, token, sala;
    int porta;
    long long quando;
    SessaoSalva() : porta(0), quando(0) {}
};

static const char* ARQ_SESSAO = "sessao.txt";

static void salvarSessaoArquivo(const SessaoSalva& s) {
    ofstream f(ARQ_SESSAO);
    if (!f) return;
    f << s.ip << '|' << s.porta << '|' << s.nome << '|' << s.token << '|' << s.sala << '|' << s.quando << '\n';
}

static void apagarSessaoArquivo() { remove(ARQ_SESSAO); }

// Le a sessao salva se ainda estiver dentro do tempo que o servidor guarda a vaga.
static bool lerSessaoArquivo(SessaoSalva& s) {
    ifstream f(ARQ_SESSAO);
    if (!f) return false;
    string linha;
    getline(f, linha);
    vector<string> p = dividir(linha, '|');
    if (p.size() != 6) return false;
    s.ip = p[0];
    s.porta = atoi(p[1].c_str());
    s.nome = p[2];
    s.token = p[3];
    s.sala = p[4];
    s.quando = atoll(p[5].c_str());
    long long agora = static_cast<long long>(time(NULL));
    if (s.ip.empty() || s.token.empty() || s.nome.empty()) return false;
    if (agora - s.quando > 110 || agora < s.quando) return false;
    return true;
}

// ---- conexao com limite de tempo -----------------------------------------------

static bool conectarComTimeout(socket_t s, const sockaddr_in& end, int ms) {
    tornarNaoBloqueante(s);
    bool ok = (connect(s, reinterpret_cast<const sockaddr*>(&end), sizeof(end)) == 0);
    if (!ok) {
#ifdef _WIN32
        bool andamento = (WSAGetLastError() == WSAEWOULDBLOCK);
#else
        bool andamento = (errno == EINPROGRESS);
#endif
        if (andamento) {
            fd_set wr, ex;
            FD_ZERO(&wr);
            FD_ZERO(&ex);
            FD_SET(s, &wr);
            FD_SET(s, &ex);
            timeval tv;
            tv.tv_sec = ms / 1000;
            tv.tv_usec = (ms % 1000) * 1000;
            int n = select(static_cast<int>(s) + 1, NULL, &wr, &ex, &tv);
            if (n > 0 && FD_ISSET(s, &wr)) {
                int err = 0;
#ifdef _WIN32
                int len = sizeof(err);
                getsockopt(s, SOL_SOCKET, SO_ERROR, reinterpret_cast<char*>(&err), &len);
#else
                socklen_t len = sizeof(err);
                getsockopt(s, SOL_SOCKET, SO_ERROR, &err, &len);
#endif
                ok = (err == 0);
            }
        }
    }
#ifdef _WIN32
    u_long modo = 0;
    ioctlsocket(s, FIONBIO, &modo);
#else
    int flags = fcntl(s, F_GETFL, 0);
    if (flags >= 0) fcntl(s, F_SETFL, flags & ~O_NONBLOCK);
#endif
    return ok;
}

// ---- dados que o cliente guarda -------------------------------------------------

struct JogV {
    string nome;
    int erros, pontos, status, vitorias, pontosRodada, equipe;   // status: 0 ativo, 1 eliminado, 2 saiu, 3 mestre
    bool offline;
    JogV() : erros(0), pontos(0), status(0), vitorias(0), pontosRodada(0), equipe(0), offline(false) {}
};

struct MembV {
    string nome;
    int pontos, vitorias, equipe;
    bool host, espec, offline;
    MembV() : pontos(0), vitorias(0), equipe(0), host(false), espec(false), offline(false) {}
};

struct ChampLinha {
    int pos, pontos, vit;
    string nome;
    ChampLinha() : pos(0), pontos(0), vit(0) {}
};

struct Pendencia {
    string tipo;
    int slot;
    char letra;
};

class Cliente {
public:
    Cliente() : sock(SOCK_INVALIDO), conectado(false), tela(T_LOGIN), passo(P_NOME),
                salaMax(0), salaPub(true), salaDif(0), salaTempo(0), partTipo(0), partValor(0),
                salaEquipes(false), salaModo(0), salaNEsp(0),
                temEstado(false), turno(0), restantes(0), rodada(0), fim(0), vencedor(-1),
                faseFinal(false), faseSala(0), tempoRest(-1), tempoLimite(0), mestreIdx(-1),
                comprimento(0), fimPartida(false), pausada(false), tempoRecebidoEm(0),
                lendo(0), faltam(0), precisaRender(false), sair(false), local(NULL),
                crMax(PADRAO_JOGADORES), vezAnterior(false), hlLetra(0), flashSlot(-1), bannerCor(-1),
                reconectando(false), desistiuReconectar(false), ultimoRx(0), ultimoSegExibido(-2),
                ultimoSalvarSessao(0), chatVis(6), evVis(3), tentativasReconexao(0) {}

    ~Cliente() { fecharSocket(sock); }

    bool conectar(const string& ip, string& erro) {
        if (sock != SOCK_INVALIDO) { fecharSocket(sock); sock = SOCK_INVALIDO; }
        sock = socket(AF_INET, SOCK_STREAM, 0);
        if (sock == SOCK_INVALIDO) { erro = "Erro ao criar socket."; return false; }

        sockaddr_in end;
        memset(&end, 0, sizeof(end));
        end.sin_family = AF_INET;
        end.sin_port = htons(static_cast<unsigned short>(g_porta));
        unsigned long addr = inet_addr(ip.c_str());
        if (addr == INADDR_NONE) {
            struct hostent* h = gethostbyname(ip.c_str());
            if (!h || h->h_addrtype != AF_INET) {
                erro = "Endereco invalido: " + ip;
                fecharSocket(sock);
                sock = SOCK_INVALIDO;
                return false;
            }
            memcpy(&end.sin_addr, h->h_addr_list[0], sizeof(end.sin_addr));
        } else {
            end.sin_addr.s_addr = addr;
        }
        if (!conectarComTimeout(sock, end, 4000)) {
            erro = "Nao foi possivel conectar em " + ip + ":" + itos(g_porta) +
                   ". Confira o IP, o servidor e o firewall.";
            fecharSocket(sock);
            sock = SOCK_INVALIDO;
            return false;
        }
        ipServidor = ip;
        conectado = true;
        ultimoRx = agoMs();
        entrada.clear();
        return true;
    }

    // Reconexao a partir da sessao salva em arquivo.
    bool retomar(const SessaoSalva& ss, string& erro) {
        g_porta = ss.porta;
        meuNome = ss.nome;
        token = ss.token;
        salaCod = ss.sala;
        if (!conectar(ss.ip, erro)) return false;
        reconectando = true;
        enviarLinha("HELLO|" + meuNome + "|" + itos(VERSAO_PROTOCOLO) + "|" + token);
        aviso = "Voltando para a sala " + ss.sala + "...";
        tela = T_MENU;
        passo = P_NENHUM;
        return true;
    }

    // Loop principal do cliente. 'srv' != NULL quando este processo tambem e o servidor.
    void executar(Servidor* srv, const string& ips) {
        local = srv;
        ipsLocais = ips;
        chatVis = cfg.chatLinhas;
        if (!reconectando) {
            tela = T_LOGIN;
            passo = P_NOME;
        }
        limparTelaTotal();
        renderizar();

        while (!sair && !g_eof) {
            processarRede();
            string linha;
            if (g_teclado.poll(linha)) tratarEntrada(linha);

            if (!conectado && !sair) {
                if (!tentarReconectar()) break;
            }
            verificarSilencio();
            atualizarRelogio();
            if (precisaRender) renderizar();
            dormir(15);
        }
        g_teclado.oculto = false;
        if (sair) apagarSessaoArquivo();
    }

private:
    enum Tela  { T_LOGIN, T_MENU, T_LOBBY, T_JOGO };
    enum Passo { P_NENHUM, P_NOME, P_CR_MAX, P_CR_CAT, P_CR_PUB, P_JOIN };

    socket_t sock;
    string entrada;
    bool conectado;
    Tela tela;
    Passo passo;
    string meuNome, token, ipServidor;
    vector<string> categorias;

    // sala
    string salaCod, salaCat, salaDono;
    int salaMax;
    bool salaPub;
    int salaDif, salaTempo, partTipo, partValor;
    bool salaEquipes;
    int salaModo, salaNEsp;
    vector<MembV> roster;

    // jogo
    bool temEstado;
    string cat, mascara, usadas, certas, palavraFinal;
    int turno, restantes, rodada, fim, vencedor;
    bool faseFinal;
    int faseSala;          // 0 espera/fim, 1 mestre escolhendo, 2 jogando
    int tempoRest, tempoLimite, mestreIdx, comprimento;
    bool fimPartida, pausada;
    long long tempoRecebidoEm;
    vector<JogV> jog;

    // campeao
    string champNome, champTitulo;
    vector<ChampLinha> champLinhas;

    // mensagens
    deque<string> chat, eventos;
    vector<string> painel;
    string aviso;

    // leitura de blocos multi-linha
    int lendo;       // 0 nada, 1 roster, 2 estado, 3 campeao
    int faltam;
    vector<MembV> tmpRoster;
    vector<JogV> tmpJog;
    vector<string> tmpPainel;
    vector<string> estadoCampos;
    vector<ChampLinha> tmpChamp;
    string tmpChampNome, tmpChampTitulo;

    bool precisaRender, sair;
    Servidor* local;
    string ipsLocais;
    int crMax;
    string crCat;

    // animacao
    vector<Pendencia> pendencias;
    bool vezAnterior;
    char hlLetra;
    int flashSlot;
    int bannerCor;

    // reconexao
    bool reconectando, desistiuReconectar;
    long long ultimoRx;
    int ultimoSegExibido;
    long long ultimoSalvarSessao;
    int chatVis, evVis;
    int tentativasReconexao;

    // ----------------------------------------------------------------- rede ---

    void enviarLinha(const string& l) {
        if (!conectado) return;
        string s = l + "\n";
        size_t env = 0;
        while (env < s.size()) {
            int n = enviarBytes(sock, s.data() + env, static_cast<int>(s.size() - env));
            if (n <= 0) { conectado = false; return; }
            env += static_cast<size_t>(n);
        }
    }

    void processarRede() {
        if (!conectado) return;
        while (true) {
            fd_set rd;
            FD_ZERO(&rd);
            FD_SET(sock, &rd);
            timeval tv;
            tv.tv_sec = 0;
            tv.tv_usec = 0;
            if (select(static_cast<int>(sock) + 1, &rd, NULL, NULL, &tv) <= 0) break;
            char buf[4096];
            int n = static_cast<int>(recv(sock, buf, sizeof(buf), 0));
            if (n <= 0) { conectado = false; return; }
            ultimoRx = agoMs();
            entrada.append(buf, static_cast<size_t>(n));

            size_t pos;
            while ((pos = entrada.find('\n')) != string::npos) {
                string linha = entrada.substr(0, pos);
                entrada.erase(0, pos + 1);
                if (!linha.empty() && linha[linha.size() - 1] == '\r') linha.erase(linha.size() - 1);
                if (!linha.empty()) tratarMsg(linha);
            }
        }
    }

    // Servidor mudo por muito tempo (cabo desconectado, Wi-Fi caiu): considera a conexao perdida.
    void verificarSilencio() {
        if (conectado && !local && agoMs() - ultimoRx > PING_LIMITE_MS) conectado = false;
    }

    // Tenta voltar para a mesma sala. false = desistiu (volta ao menu inicial).
    bool tentarReconectar() {
        if (local || meuNome.empty() || token.empty() || desistiuReconectar) {
            aviso = "Conexao com o servidor perdida.";
            renderizar();
            cout << "\n" << flush;
            dormir(1500);
            return false;
        }
        const int MAX_TENTATIVAS = 40;
        while (!sair && !g_eof && tentativasReconexao < MAX_TENTATIVAS) {
            ++tentativasReconexao;
            aviso = "Conexao perdida. Tentando voltar para a sala... (tentativa " + itos(tentativasReconexao) +
                    "/" + itos(MAX_TENTATIVAS) + ")  [Ctrl+C cancela]";
            renderizar();
            string erro;
            if (conectar(ipServidor, erro)) {
                reconectando = true;
                enviarLinha("HELLO|" + meuNome + "|" + itos(VERSAO_PROTOCOLO) + "|" + token);
                // espera a resposta do servidor por ate 4 segundos
                long long limite = agoMs() + 4000;
                while (agoMs() < limite && conectado && reconectando && !desistiuReconectar) {
                    processarRede();
                    dormir(20);
                }
                if (conectado && !desistiuReconectar) {
                    tentativasReconexao = 0;
                    aviso.clear();
                    precisaRender = true;
                    return true;
                }
                if (desistiuReconectar) break;
            }
            long long ate = agoMs() + 2000;
            string lixo;
            while (agoMs() < ate && !g_eof) {
                g_teclado.poll(lixo);
                dormir(30);
            }
        }
        aviso = "Nao foi possivel voltar para a sala.";
        renderizar();
        cout << "\n" << flush;
        dormir(1500);
        return false;
    }

    int meuSlot() const {
        for (size_t i = 0; i < jog.size(); ++i) if (jog[i].nome == meuNome && jog[i].status != 2) return static_cast<int>(i);
        return -1;
    }

    bool souEspectadorNaLista() const {
        for (size_t i = 0; i < roster.size(); ++i) if (roster[i].nome == meuNome) return roster[i].espec;
        return false;
    }

    bool souDono() const { return salaDono == meuNome; }

    bool jogandoAgora() const { return tela == T_JOGO && temEstado && faseSala == 2; }

    bool minhaVez() const {
        int s = meuSlot();
        return jogandoAgora() && !pausada && s >= 0 && s == turno && jog[s].status == 0 && !jog[s].offline;
    }

    bool souMestre() const {
        int s = meuSlot();
        return tela == T_JOGO && temEstado && faseSala == 1 && s >= 0 && s == mestreIdx;
    }

    int indiceCorNome(const string& nome) const {
        for (size_t i = 0; i < jog.size(); ++i) if (jog[i].nome == nome) return static_cast<int>(i % MAX_JOGADORES);
        for (size_t i = 0; i < roster.size(); ++i) if (roster[i].nome == nome) return static_cast<int>(i % MAX_JOGADORES);
        unsigned h = 0;
        for (size_t i = 0; i < nome.size(); ++i) h = h * 31 + static_cast<unsigned char>(nome[i]);
        return static_cast<int>(h % MAX_JOGADORES);
    }

    void addLimitado(deque<string>& d, const string& s, size_t max) {
        d.push_back(s);
        while (d.size() > max) d.pop_front();
    }

    void guardarSessao() {
        if (local || token.empty() || salaCod.empty() || ipServidor.empty()) return;
        SessaoSalva ss;
        ss.ip = ipServidor;
        ss.porta = g_porta;
        ss.nome = meuNome;
        ss.token = token;
        ss.sala = salaCod;
        ss.quando = static_cast<long long>(time(NULL));
        salvarSessaoArquivo(ss);
        ultimoSalvarSessao = ss.quando;
    }

    void tratarMsg(const string& linha) {
        vector<string> p = dividir(linha, '|');
        const string& cmd = p[0];

        // blocos multi-linha em andamento
        if (lendo == 1 && cmd == "M" && p.size() >= 8) {
            MembV m;
            m.nome = p[1]; m.pontos = atoi(p[2].c_str()); m.vitorias = atoi(p[3].c_str());
            m.host = p[4] == "1"; m.espec = p[5] == "1"; m.equipe = atoi(p[6].c_str()); m.offline = p[7] == "1";
            tmpRoster.push_back(m);
            if (--faltam <= 0) { lendo = 0; roster = tmpRoster; precisaRender = true; }
            return;
        }
        if (lendo == 2 && cmd == "P" && p.size() >= 10) {
            JogV j;
            j.nome = p[2]; j.erros = atoi(p[3].c_str()); j.pontos = atoi(p[4].c_str());
            j.status = atoi(p[5].c_str()); j.vitorias = atoi(p[6].c_str()); j.pontosRodada = atoi(p[7].c_str());
            j.equipe = atoi(p[8].c_str()); j.offline = p[9] == "1";
            tmpJog.push_back(j);
            if (--faltam <= 0) { lendo = 0; aplicarEstado(); }
            return;
        }
        if (lendo == 3 && cmd == "CH" && p.size() >= 5) {
            ChampLinha c;
            c.pos = atoi(p[1].c_str()); c.nome = p[2]; c.pontos = atoi(p[3].c_str()); c.vit = atoi(p[4].c_str());
            tmpChamp.push_back(c);
            if (--faltam <= 0) {
                lendo = 0;
                champLinhas = tmpChamp;
                champNome = tmpChampNome;
                champTitulo = tmpChampTitulo;
                precisaRender = true;
            }
            return;
        }
        lendo = 0;

        if (cmd == "PING") {
            enviarLinha("PONG");
        } else if (cmd == "WELCOME") {
            meuNome = p.size() > 1 ? p[1] : meuNome;
            token = p.size() > 2 ? p[2] : token;
            if (!reconectando) {
                tela = T_MENU;
                passo = P_NENHUM;
                aviso.clear();
            }
            precisaRender = true;
        } else if (cmd == "NOSESSION") {
            reconectando = false;
            apagarSessaoArquivo();
            temEstado = false;
            aviso = "A sala em que voce estava nao existe mais (ou o tempo para voltar acabou).";
            precisaRender = true;
        } else if (cmd == "CATS") {
            categorias.assign(p.begin() + 1, p.end());
        } else if (cmd == "ERROR") {
            aviso = p.size() > 1 ? p[1] : "Erro.";
            if (reconectando) {
                reconectando = false;
                desistiuReconectar = true;
                apagarSessaoArquivo();
                tela = T_LOGIN;
                passo = P_NOME;
            } else if (tela == T_LOGIN) {
                passo = P_NOME;
            }
            precisaRender = true;
        } else if (cmd == "SYS") {
            addLimitado(chat, estilo("* " + (p.size() > 1 ? p[1] : ""), "33"), 200);
            precisaRender = true;
        } else if (cmd == "JOINED") {
            bool volta = p.size() > 2 && p[2] == "1";
            reconectando = false;
            tentativasReconexao = 0;
            salaCod = p.size() > 1 ? p[1] : "";
            if (!volta) {
                roster.clear();
                chat.clear();
                eventos.clear();
                jog.clear();
                temEstado = false;
                fimPartida = false;
                champLinhas.clear();
                faseSala = 0;
                rodada = 0;
                tela = T_LOBBY;
            } else {
                tela = temEstado ? T_JOGO : T_LOBBY;
            }
            vezAnterior = false;
            painel.clear();
            aviso.clear();
            passo = P_NENHUM;
            guardarSessao();
            tocarSom(SOM_ENTRAR);
            precisaRender = true;
        } else if (cmd == "LEFT") {
            tela = T_MENU;
            passo = P_NENHUM;
            temEstado = false;
            g_teclado.oculto = false;
            apagarSessaoArquivo();
            precisaRender = true;
        } else if (cmd == "KICKED") {
            aviso = p.size() > 1 ? p[1] : "Voce foi expulso da sala.";
            apagarSessaoArquivo();
            precisaRender = true;
        } else if (cmd == "ROOMINFO" && p.size() >= 13) {
            salaCod = p[1]; salaCat = p[2]; salaMax = atoi(p[3].c_str());
            salaPub = p[4] == "1"; salaDono = p[5]; salaDif = atoi(p[6].c_str());
            salaTempo = atoi(p[7].c_str()); partTipo = atoi(p[8].c_str()); partValor = atoi(p[9].c_str());
            salaEquipes = p[10] == "1"; salaModo = atoi(p[11].c_str()); salaNEsp = atoi(p[12].c_str());
            precisaRender = true;
        } else if (cmd == "ROSTER" && p.size() >= 2) {
            faltam = atoi(p[1].c_str());
            tmpRoster.clear();
            if (faltam > 0) lendo = 1; else { roster.clear(); precisaRender = true; }
        } else if (cmd == "STATE" && p.size() >= 22) {
            estadoCampos = p;
            faltam = atoi(p[14].c_str());
            tmpJog.clear();
            if (faltam > 0) lendo = 2;
        } else if (cmd == "CHAMP" && p.size() >= 4) {
            tmpChampNome = p[1];
            tmpChampTitulo = p[3];
            tmpChamp.clear();
            faltam = atoi(p[2].c_str());
            if (faltam > 0) lendo = 3;
        } else if (cmd == "EVENT" && p.size() >= 5) {
            tratarEvento(p);
        } else if (cmd == "CHATMSG" && p.size() >= 3) {
            int ic = indiceCorNome(p[1]);
            addLimitado(chat, estilo(p[1], COR_JOGADOR[ic]) + ": " + p[2], 200);
            if (p[1] != meuNome) tocarSom(SOM_CHAT);
            precisaRender = true;
        } else if (cmd == "CHATHIST" && p.size() >= 3) {
            int ic = indiceCorNome(p[1]);
            addLimitado(chat, estilo(p[1], COR_JOGADOR[ic]) + ": " + p[2], 200);
        } else if (cmd == "ROOM" && p.size() >= 8) {
            string extra = p[7] != "0" ? "  +" + p[7] + " assistindo" : "";
            string l = "  " + estilo(p[1], "1;33") + "  dono: " + pad(p[2], 16) + " " +
                       p[3] + "/" + p[4] + "  " + pad(p[5], 18) + (p[6] == "1" ? "[em jogo]" : "[aguardando]") + extra;
            tmpPainel.push_back(l);
        } else if (cmd == "ROOMS_END") {
            painel.clear();
            painel.push_back(estilo("Salas publicas (entre com o codigo; se estiver em jogo voce assiste):", "1;36"));
            if (tmpPainel.empty()) painel.push_back("  (nenhuma sala publica no momento - crie a sua!)");
            for (size_t i = 0; i < tmpPainel.size(); ++i) painel.push_back(tmpPainel[i]);
            tmpPainel.clear();
            precisaRender = true;
        } else if (cmd == "RANK" && p.size() >= 6) {
            tmpPainel.push_back("  " + pad(p[1] + ".", 4) + pad(p[2], 18) + pad(p[3] + " pts", 10) +
                                pad(p[4] + " vit", 8) + p[5] + " rodadas");
        } else if (cmd == "RANK_END") {
            painel.clear();
            painel.push_back(estilo("RANKING GLOBAL (top 10)", "1;36"));
            if (tmpPainel.empty()) painel.push_back("  (ninguem jogou ainda)");
            for (size_t i = 0; i < tmpPainel.size(); ++i) painel.push_back(tmpPainel[i]);
            tmpPainel.clear();
            precisaRender = true;
        }
    }

    void tratarEvento(const vector<string>& p) {
        string tipo = p[1];
        int slot = atoi(p[2].c_str());
        char letra = p[3].empty() ? 0 : p[3][0];
        string txt = p[4];

        const char* cor = "0";
        if (tipo == "hit" || tipo == "wordhit") cor = "1;32";
        else if (tipo == "miss" || tipo == "wordmiss" || tipo == "timeout") cor = "1;31";
        else if (tipo == "start") cor = "1;36";
        else cor = "1;33";

        if (tipo == "start") { eventos.clear(); }
        addLimitado(eventos, estilo(txt, cor), 6);

        Pendencia pe;
        pe.tipo = tipo; pe.slot = slot; pe.letra = letra;
        pendencias.push_back(pe);
        precisaRender = true;
    }

    // Chamado quando um bloco STATE completo foi recebido.
    void aplicarEstado() {
        const vector<string>& p = estadoCampos;
        cat = p[2];
        mascara = p[3];
        usadas = p[4];
        certas = p[5];
        turno = atoi(p[6].c_str());
        restantes = atoi(p[7].c_str());
        faseFinal = p[8] == "1";
        fim = atoi(p[10].c_str());
        vencedor = atoi(p[11].c_str());
        palavraFinal = p[12];
        rodada = atoi(p[13].c_str());
        faseSala = atoi(p[15].c_str());
        tempoRest = atoi(p[16].c_str());
        tempoLimite = atoi(p[17].c_str());
        mestreIdx = atoi(p[18].c_str());
        comprimento = atoi(p[19].c_str());
        fimPartida = p[20] == "1";
        pausada = p[21] == "1";
        tempoRecebidoEm = agoMs();
        jog = tmpJog;
        temEstado = true;
        tela = T_JOGO;
        aviso.clear();
        painel.clear();
        if (!fimPartida) champLinhas.clear();
        g_teclado.oculto = souMestre();

        executarAnimacoes();
        precisaRender = false;
    }

    // segundos que faltam para o fim da jogada (-1 = sem relogio)
    int segundosRestantes() const {
        if (tempoRest < 0 || pausada) return -1;
        if (faseSala != 1 && faseSala != 2) return -1;
        long long rest = static_cast<long long>(tempoRest) * 1000 - (agoMs() - tempoRecebidoEm);
        if (rest < 0) rest = 0;
        return static_cast<int>((rest + 999) / 1000);
    }

    // Redesenha a cada segundo enquanto ha contagem regressiva na tela.
    void atualizarRelogio() {
        if (!g_ansi || tela != T_JOGO || !temEstado) return;
        int s = segundosRestantes();
        if (s != ultimoSegExibido) {
            ultimoSegExibido = s;
            if (s >= 0) precisaRender = true;
        }
        if (!local && !salaCod.empty() && tela != T_MENU && time(NULL) - ultimoSalvarSessao >= 15) guardarSessao();
    }

    // ------------------------------------------------------------ animacoes ---

    void executarAnimacoes() {
        vector<Pendencia> lista = pendencias;
        pendencias.clear();

        bool houveSom = false;
        for (size_t i = 0; i < lista.size(); ++i) {
            const Pendencia& pe = lista[i];
            if (pe.tipo == "hit" || pe.tipo == "wordhit") {
                tocarSom(SOM_ACERTO);
                houveSom = true;
                if (cfg.anim) {
                    for (int k = 0; k < 3; ++k) {
                        hlLetra = pe.letra; renderizar(); dormir(110);
                        hlLetra = 0;        renderizar(); dormir(70);
                    }
                }
            } else if (pe.tipo == "miss" || pe.tipo == "wordmiss" || pe.tipo == "timeout") {
                tocarSom(SOM_ERRO);
                houveSom = true;
                if (cfg.anim && pe.slot >= 0) {
                    for (int k = 0; k < 3; ++k) {
                        flashSlot = pe.slot; renderizar(); dormir(100);
                        flashSlot = -1;      renderizar(); dormir(70);
                    }
                }
            } else if (pe.tipo == "win" || pe.tipo == "lose") {
                bool euVenci = (pe.tipo == "win" && pe.slot >= 0 && pe.slot == meuSlot());
                tocarSom(pe.tipo == "win" ? SOM_VITORIA : SOM_DERROTA);
                houveSom = true;
                if (cfg.anim) {
                    int passos = fimPartida ? 26 : 16;
                    for (int k = 0; k < passos; ++k) {
                        bannerCor = k;
                        renderizar();
                        dormir(euVenci || fimPartida ? 70 : 110);
                    }
                }
            }
        }
        bannerCor = -1;
        hlLetra = 0;
        flashSlot = -1;
        renderizar();

        bool agora = minhaVez() || souMestre();
        if (agora && !vezAnterior && !houveSom) tocarSom(SOM_VEZ);
        vezAnterior = agora;
    }

    // ---------------------------------------------------------------- tela ---

    string cabecalho(const string& direita) {
        string esq = " FORCA MULTIPLAYER";
        string dir = direita + " ";
        int livre = LARGURA - static_cast<int>(esq.size()) - static_cast<int>(dir.size());
        if (livre < 1) {
            size_t max = static_cast<size_t>(LARGURA) - esq.size() - 2;
            dir = dir.substr(0, max) + " ";
            livre = 1;
        }
        string meio(static_cast<size_t>(livre), ' ');
        return estilo(linhaDupla(), "36") + "\n" +
               estilo(esq, "1;37") + meio + estilo(dir, "36") + "\n" +
               estilo(linhaDupla(), "36") + "\n";
    }

    string rodapeConfig() {
        return string("Som:") + (cfg.som ? "ON" : "off") + " Anim:" + (cfg.anim ? "ON" : "off") +
               " Cor:" + (cfg.cor ? "ON" : "off");
    }

    string blocoMensagens() {
        string r;
        for (size_t i = 0; i < painel.size(); ++i) r += painel[i] + "\n";
        if (!aviso.empty()) r += estilo("! " + aviso, "1;31") + "\n";
        return r;
    }

    string textoPartidaCli() const { return textoPartida(partTipo, partValor); }

    string promptAtual() {
        if (tela == T_LOGIN) return estilo("Seu nome: ", "1;33");
        if (tela == T_MENU) {
            switch (passo) {
                case P_CR_MAX: return estilo("Maximo de jogadores (2-6) [4]: ", "1;33");
                case P_CR_CAT: return estilo("Categoria (numero ou nome, 0 = aleatoria) [0]: ", "1;33");
                case P_CR_PUB: return estilo("Aparecer na lista de salas publicas? (s/n) [s]: ", "1;33");
                case P_JOIN:   return estilo("Codigo da sala (termine com * para so assistir; vazio cancela): ", "1;33");
                default:       return estilo("Escolha: ", "1;33");
            }
        }
        if (tela == T_JOGO && souMestre())
            return estilo("PALAVRA SECRETA (3 a 20 letras; so voce ve) > ", "1;33");
        if (tela == T_JOGO && minhaVez())
            return estilo("SUA JOGADA (uma letra ou a palavra de " + itos(comprimento) + " letras) > ", "1;33");
        if (tela == T_JOGO && meuSlot() < 0) return estilo("(assistindo) chat > ", "36");
        if (tela == T_JOGO && faseSala == 2) return estilo("chat > ", "36");
        return estilo("> ", "36");
    }

    void renderizar() {
        precisaRender = false;
        int alvo = g_ansi ? alturaTerminal() - 1 : 100000;
        chatVis = cfg.chatLinhas;
        evVis = 3;
        bool compacto = false;
        string q;
        while (true) {
            switch (tela) {
                case T_LOGIN: q = quadroLogin(); break;
                case T_MENU:  q = quadroMenu(); break;
                case T_LOBBY: q = quadroLobby(); break;
                case T_JOGO:  q = quadroJogo(compacto); break;
            }
            int linhas = 1;
            for (size_t i = 0; i < q.size(); ++i) if (q[i] == '\n') ++linhas;
            if (linhas <= alvo) break;
            if (chatVis > 0) { --chatVis; continue; }
            if (evVis > 1) { --evVis; continue; }
            if (!compacto) { compacto = true; continue; }
            break;
        }
        desenhar(q + promptAtual() + g_teclado.visivel());
    }

    string quadroLogin() {
        string q = cabecalho(rodapeConfig());
        q += "\n";
        for (int i = 0; i < LOGO_LINHAS; ++i) q += "      " + estilo(LOGO[i], "1;33") + "\n";
        q += "\n  Conectado ao servidor. Escolha um nome para jogar.\n\n";
        q += blocoMensagens();
        return q;
    }

    string quadroMenu() {
        string q = cabecalho("Jogador: " + meuNome);
        q += "\n";
        if (local && !ipsLocais.empty())
            q += "  Voce e o servidor. Amigos entram com o IP: " + estilo(ipsLocais, "1;32") + "  (porta " + itos(g_porta) + ")\n\n";
        else if (local)
            q += "  Voce e o servidor (porta " + itos(g_porta) + ").\n\n";
        q += "  " + estilo("1", "1;33") + " - Criar sala\n";
        q += "  " + estilo("2", "1;33") + " - Entrar em uma sala com codigo (ou assistir)\n";
        q += "  " + estilo("3", "1;33") + " - Ver salas publicas\n";
        q += "  " + estilo("4", "1;33") + " - Ranking\n";
        q += "  " + estilo("5", "1;33") + " - Desconectar\n\n";
        q += "  " + estilo("/ajuda", "2") + " mostra todos os comandos.   " + estilo("/som  /anim  /cor  /acentos", "2") + " ligam e desligam.\n";
        q += estilo(linhaSimples(), "2") + "\n";
        q += blocoMensagens();
        return q;
    }

    string tagEquipe(int e) {
        return e == 0 ? estilo("[A]", "1;36") : estilo("[B]", "1;33");
    }

    string linhaMembro(const MembV& m, size_t i) {
        string tag = salaEquipes ? string(m.equipe == 0 ? "[A] " : "[B] ") : string("");
        string l = "  " + itos(static_cast<long>(i + 1)) + ". " + tag + pad(m.nome, MAX_NOME + 1) +
                   pad(m.host ? "(dono)" : "", 8) + pad("Pontos: " + itos(m.pontos), 14) +
                   "Vitorias: " + itos(m.vitorias) + (m.offline ? "  [sem conexao]" : "");
        const char* cor = salaEquipes ? (m.equipe == 0 ? "1;36" : "1;33") : COR_JOGADOR[i % MAX_JOGADORES];
        return estilo(l, m.offline ? "2" : cor);
    }

    string blocoChat() {
        string q = estilo(linhaSimples(), "2") + "\n";
        size_t n = chat.size();
        size_t ini = n > static_cast<size_t>(chatVis) ? n - static_cast<size_t>(chatVis) : 0;
        if (chatVis <= 0) ini = n;
        for (size_t i = ini; i < n; ++i) q += " " + chat[i] + "\n";
        return q;
    }

    string textoModoPalavra() const { return salaModo == 1 ? "palavra escolhida por um jogador" : "palavra sorteada"; }
    string textoTempo() const { return salaTempo > 0 ? itos(salaTempo) + "s por jogada" : string("sem limite de tempo"); }

    string quadroLobby() {
        string q = cabecalho("Sala " + salaCod + "   " + rodapeConfig());
        q += "\n  CODIGO DA SALA:  " + estilo(" " + salaCod + " ", "1;30;43") + "   (passe o codigo para seus amigos)\n";
        q += "  Categoria: " + estilo(salaCat.empty() ? "Aleatoria" : salaCat, "1;36") +
             "    Maximo: " + itos(salaMax) + " jogadores    " + (salaPub ? "Sala publica" : "Sala privada") + "\n";
        q += "  " + nomeNivel(salaDif) + "  |  " + textoTempo() + "  |  Partida: " + textoPartidaCli() + "\n";
        q += "  Modo: " + textoModoPalavra() + (salaEquipes ? string("  |  ") + estilo("EQUIPES (A x B)", "1;35") : string("")) + "\n";
        if (local && !ipsLocais.empty()) q += "  IP do servidor: " + estilo(ipsLocais, "1;32") + "\n";

        size_t nj = 0;
        for (size_t i = 0; i < roster.size(); ++i) if (!roster[i].espec) ++nj;
        q += "\n  Jogadores (" + itos(static_cast<long>(nj)) + "/" + itos(salaMax) + "):\n";
        size_t k = 0;
        for (size_t i = 0; i < roster.size(); ++i) if (!roster[i].espec) q += linhaMembro(roster[i], k++) + "\n";
        string esp;
        for (size_t i = 0; i < roster.size(); ++i)
            if (roster[i].espec) esp += (esp.empty() ? "" : ", ") + roster[i].nome;
        if (!esp.empty()) q += "  Assistindo: " + estilo(esp, "2") + "\n";
        q += "\n";
        bool dono = souDono();
        if (souEspectadorNaLista()) {
            q += "  Voce esta assistindo. Use /jogar para entrar na partida (se houver vaga).\n";
            q += "  /sair deixa a sala   /ajuda mostra os comandos\n";
        } else if (dono) {
            if (nj < static_cast<size_t>(MIN_JOGADORES))
                q += "  Aguardando mais jogadores... (minimo 2)\n";
            else
                q += "  " + estilo("Digite /iniciar para comecar a rodada!", "1;32") + "\n";
            q += "  /config mostra e altera: /tempo /dif /partida /equipes /modo /max /cat /publica\n";
            q += "  /expulsar nome   /dono nome   /sair   /ajuda\n";
        } else {
            q += "  Aguardando " + salaDono + " iniciar a rodada...\n";
            if (salaEquipes) q += "  Troque de time com /time A ou /time B.   ";
            q += "/assistir   /sair   /ajuda\n";
        }
        q += blocoChat();
        q += blocoMensagens();
        return q;
    }

    string textoStatus(const JogV& j, bool ehVez) {
        if (j.status == 2) return "SAIU";
        if (j.status == 3) return "MESTRE";
        if (j.offline) return "SEM CONEXAO";
        if (j.status == 1) return "FORA";
        if (ehVez) return "VEZ!";
        return "";
    }

    vector<string> celulaJogador(size_t idx) {
        const JogV& j = jog[idx];
        bool ehVez = faseSala == 2 && !pausada && static_cast<int>(idx) == turno && j.status == 0 && !j.offline;
        string corBase = salaEquipes ? (j.equipe == 0 ? "1;36" : "1;33") : string(COR_JOGADOR[idx % MAX_JOGADORES]);

        vector<string> txt;
        string nome = j.nome;
        if (nome == meuNome) nome += "*";
        txt.push_back(pad((ehVez ? ">> " : "   ") + nome, 19));
        vector<string> d = desenhoForca(j.erros, static_cast<int>(idx % 2));
        string info[6];
        info[0] = "Erros " + itos(j.erros) + "/" + itos(MAX_ERROS);
        info[1] = "Pts " + itos(j.pontos);
        info[2] = "Vit " + itos(j.vitorias);
        info[3] = textoStatus(j, ehVez);
        info[4] = salaEquipes ? string(j.equipe == 0 ? "Time A" : "Time B") : string("");
        for (int k = 0; k < 6; ++k) txt.push_back(pad(pad(d[k], 9) + " " + info[k], 19));

        vector<string> out;
        string cor = corBase;
        if (j.status != 0 || j.offline) cor = "2";
        if (flashSlot == static_cast<int>(idx)) cor = "1;37;41";
        for (size_t k = 0; k < txt.size(); ++k) {
            string c = cor;
            if (k == 0 && ehVez && flashSlot != static_cast<int>(idx)) c = "7;" + corBase;
            out.push_back(estilo(txt[k], c.c_str()));
        }
        return out;
    }

    string glifoParaTela(const string& g) {
        string m = maiusculaGlifo(g);
        return cfg.acentos ? m : dobrarAcentos(m);
    }

    string exibirPalavra() {
        string r = "  ";
        if (faseSala == 0 && !palavraFinal.empty()) {
            vector<string> gs = glifosUtf8(palavraFinal);
            for (size_t i = 0; i < gs.size(); ++i) {
                char b = baseDoGlifo(gs[i]);
                if (b == 0) { r += gs[i] == " " ? "   " : "-  "; continue; }
                bool revelada = contem(usadas, b);
                r += estilo(glifoParaTela(gs[i]), revelada ? "1;37" : "1;31") + "  ";
            }
            return r;
        }
        vector<string> tokens = dividir(mascara, ' ');
        for (size_t i = 0; i < tokens.size(); ++i) {
            const string& t = tokens[i];
            if (t == "_") { r += estilo("_", "2") + "  "; continue; }
            if (t == "/") { r += "   "; continue; }
            if (t == "-") { r += "-  "; continue; }
            bool destaque = hlLetra && baseDoGlifo(t) == hlLetra;
            r += estilo(glifoParaTela(t), destaque ? "1;30;43" : "1;37") + "  ";
        }
        return r;
    }

    string exibirTeclado() {
        string r = "  ";
        for (char c = 'a'; c <= 'z'; ++c) {
            string s(1, static_cast<char>(toupper(c)));
            if (contem(usadas, c)) {
                bool acerto = contem(certas, c);
                r += estilo(s, acerto ? "1;32" : "9;31");
            } else {
                r += estilo(s, "37");
            }
            r += ' ';
        }
        return r;
    }

    string nomeJogador(int i) const {
        return (i >= 0 && i < static_cast<int>(jog.size())) ? jog[static_cast<size_t>(i)].nome : string("");
    }

    string bannerFinal() {
        string txt;
        string nomeVenc = nomeJogador(vencedor);
        if (fim == 1) txt = "*** " + nomeVenc + " DESCOBRIU A PALAVRA! ***";
        else if (fim == 2) txt = "*** " + nomeVenc + " ACERTOU A PALAVRA INTEIRA! ***";
        else if (fim == 3) txt = "*** NINGUEM ACERTOU! ***";
        else txt = "*** RODADA CANCELADA ***";
        static const char* ciclo[] = { "1;31", "1;33", "1;32", "1;36", "1;34", "1;35" };
        string cor = bannerCor >= 0 ? ciclo[bannerCor % 6] : ((fim == 1 || fim == 2) ? "1;32" : "1;31");
        return estilo(centralizar(txt, LARGURA), cor.c_str());
    }

    string placarEquipes() {
        int pts[2] = {0, 0}, vit[2] = {0, 0};
        for (size_t i = 0; i < jog.size(); ++i) {
            pts[jog[i].equipe ? 1 : 0] += jog[i].pontos;
            vit[jog[i].equipe ? 1 : 0] += jog[i].vitorias;
        }
        return "  " + estilo("Time A: " + itos(pts[0]) + " pts (" + itos(vit[0]) + " rodadas)", "1;36") + "   |   " +
               estilo("Time B: " + itos(pts[1]) + " pts (" + itos(vit[1]) + " rodadas)", "1;33");
    }

    string linhaRelogio() {
        int s = segundosRestantes();
        if (s < 0) return "";
        return estilo("Tempo: " + itos(s) + "s", s <= 5 ? "1;31" : (s <= 10 ? "1;33" : "1;32"));
    }

    string quadroCampeao(bool compacto) {
        string q = cabecalho("Sala " + salaCod + "  " + champTitulo);
        q += "\n";
        if (!compacto)
            for (int i = 0; i < TROFEU_LINHAS; ++i)
                q += centralizar(estilo(TROFEU[i], bannerCor >= 0 && (bannerCor % 2) ? "1;33" : "1;37"), LARGURA) + "\n";
        string titulo = champNome.empty() ? string("*** EMPATE! ***") : "*** CAMPEAO: " + champNome + " ***";
        static const char* ciclo[] = { "1;33", "1;32", "1;36", "1;35", "1;31", "1;34" };
        q += estilo(centralizar(titulo, LARGURA), bannerCor >= 0 ? ciclo[bannerCor % 6] : "1;33") + "\n\n";
        for (size_t i = 0; i < champLinhas.size(); ++i) {
            const ChampLinha& c = champLinhas[i];
            string medalha = c.pos == 1 ? "1o" : (c.pos == 2 ? "2o" : (c.pos == 3 ? "3o" : itos(c.pos) + "o"));
            string l = "   " + pad(medalha, 4) + pad(c.nome, 38) + pad(itos(c.pontos) + " pts", 10) + itos(c.vit) + " rodadas ganhas";
            q += estilo(l, c.pos == 1 && !champNome.empty() ? "1;33" : "37") + "\n";
        }
        q += "\n  A ultima palavra era: " + estilo(maiusculaUtf8(cfg.acentos ? palavraFinal : dobrarAcentos(palavraFinal)), "1;37") + "\n";
        if (souDono()) q += "  " + estilo("/iniciar", "1;32") + " comeca uma NOVA PARTIDA (placar zerado).   /config muda as regras.   /sair\n";
        else q += "  Aguardando " + salaDono + " iniciar uma nova partida.   /sair\n";
        q += blocoChat();
        q += blocoMensagens();
        return q;
    }

    string quadroJogo(bool compacto) {
        if (faseSala == 0 && fimPartida && !champLinhas.empty()) return quadroCampeao(compacto);

        string cab = "Sala " + salaCod + "  Rodada " + itos(rodada);
        if (partTipo != 0) cab += "  " + textoPartidaCli();
        string q = cabecalho(cab);
        int n = static_cast<int>(jog.size());
        int porLinha = n <= 4 ? (n > 0 ? n : 1) : 3;
        for (int ini = 0; ini < n; ini += porLinha) {
            int f = ini + porLinha < n ? ini + porLinha : n;
            vector<vector<string> > cel;
            for (int i = ini; i < f; ++i) cel.push_back(celulaJogador(static_cast<size_t>(i)));
            for (size_t k = 0; k < cel[0].size(); ++k) {
                string ln;
                for (size_t c = 0; c < cel.size(); ++c) ln += cel[c][k];
                q += ln + "\n";
            }
        }
        if (salaEquipes) q += placarEquipes() + "\n";
        q += estilo(linhaSimples(), "2") + "\n";

        if (faseSala == 1) {
            string mestre = nomeJogador(mestreIdx);
            if (souMestre()) {
                q += "  " + estilo("VOCE E O MESTRE DESTA RODADA!", "1;33") + " Digite a palavra secreta abaixo (ela fica oculta).\n";
                q += "  Se ninguem acertar, voce ganha +" + itos(PTS_MESTRE_VENCEU) + " pontos. Escolha uma palavra que todos conhecam!\n";
            } else {
                q += "  " + estilo(mestre, "1;36") + " esta escolhendo a palavra secreta...\n\n";
            }
            string rel = linhaRelogio();
            q += "  " + (rel.empty() ? string("") : rel) + "\n";
        } else {
            q += "  Categoria: " + estilo(cat, "1;36") + "   Letras: " + itos(comprimento);
            if (faseSala == 2) {
                string rel = linhaRelogio();
                if (!rel.empty()) q += "   " + rel;
            }
            q += "\n";
            q += exibirPalavra() + "\n";
            q += exibirTeclado() + "\n";
        }
        q += estilo(linhaSimples(), "2") + "\n";

        if (faseSala == 0) {
            q += bannerFinal() + "\n";
            q += "  A palavra era: " + estilo(maiusculaUtf8(cfg.acentos ? palavraFinal : dobrarAcentos(palavraFinal)), "1;37") + "\n";
            if (souDono()) q += "  " + estilo("/iniciar", "1;32") + " = proxima rodada      /config muda as regras      /sair = deixar a sala\n";
            else q += "  Aguardando " + salaDono + " iniciar a proxima rodada.      /sair = deixar a sala\n";
        } else if (faseSala == 2) {
            if (pausada) {
                q += "  " + estilo("JOGO PAUSADO: aguardando um jogador voltar da queda de conexao...", "1;33") + "\n";
            } else if (turno >= 0 && turno < n) {
                if (minhaVez()) q += "  " + estilo(">>> SUA VEZ! <<<", "1;33");
                else if (meuSlot() < 0) q += "  Voce esta assistindo. Vez de: " + estilo(jog[turno].nome, COR_JOGADOR[turno % MAX_JOGADORES]);
                else q += "  Vez de: " + estilo(jog[turno].nome, COR_JOGADOR[turno % MAX_JOGADORES]);
                if (faseFinal)
                    q += "   " + estilo("FASE FINAL: faltam " + itos(restantes) + " letra(s)! Chute a palavra (+5)", "1;35");
                q += "\n";
            }
        }
        size_t ne = eventos.size();
        size_t ev = static_cast<size_t>(evVis);
        for (size_t i = (ne > ev ? ne - ev : 0); i < ne; ++i) q += "  " + eventos[i] + "\n";
        q += blocoChat();
        q += blocoMensagens();
        return q;
    }

    // -------------------------------------------------------------- entrada ---

    void painelCategorias() {
        painel.clear();
        painel.push_back(estilo("Categorias:", "1;36"));
        for (size_t i = 0; i < categorias.size(); ++i)
            painel.push_back("  " + itos(static_cast<long>(i + 1)) + " - " + categorias[i]);
        painel.push_back("  0 - Aleatoria (todas)");
    }

    // Converte "3" ou "frutas" no nome da categoria. "" = aleatoria. ok=false se invalido.
    string resolverCategoria(const string& entradaCat, bool& ok) {
        ok = true;
        string t = aparar(entradaCat);
        if (t.empty() || t == "0") return "";
        bool numero = true;
        for (size_t i = 0; i < t.size(); ++i) if (!isdigit(static_cast<unsigned char>(t[i]))) numero = false;
        if (numero) {
            size_t k = static_cast<size_t>(atoi(t.c_str()));
            if (k >= 1 && k <= categorias.size()) return categorias[k - 1];
            ok = false;
            return "";
        }
        string lower = paraMinusculas(t);
        for (size_t i = 0; i < categorias.size(); ++i)
            if (paraMinusculas(categorias[i]) == lower) return categorias[i];
        ok = false;
        return "";
    }

    void mostrarAjuda() {
        painel.clear();
        painel.push_back(estilo("COMANDOS", "1;36"));
        painel.push_back("  Na sua vez: digite UMA letra, ou a PALAVRA INTEIRA (vale a qualquer momento).");
        painel.push_back("    Palavra certa: +5 (+2 por letra diferente que faltava alem de 2). Errada: -3 e +2 erros");
        painel.push_back("    (na fase final: -1 e +1 erro). Se o tamanho nao bater, nada e descontado.");
        painel.push_back("  /c texto  chat (na sua vez)   /gg /boa /ops /rs /uau /f ...  reacoes (/reacoes lista)");
        painel.push_back("  /historico  chat anterior    /chatlinhas N  linhas de chat na tela");
        painel.push_back("  /iniciar  (dono) comeca a rodada      /sair  deixa a sala     /ranking");
        painel.push_back("  /config  (dono) ver e mudar: /tempo N|off  /dif facil|medio|dificil|todas");
        painel.push_back("     /partida livre|melhor N|pontos N   /equipes on|off   /modo sorteada|mestre");
        painel.push_back("     /max N   /cat X   /publica   /privada");
        painel.push_back("  /time A|B  muda de time   /assistir  /jogar   /expulsar nome   /dono nome");
        painel.push_back("  /som /anim /cor /acentos  liga e desliga");
    }

    void mostrarReacoes() {
        painel.clear();
        painel.push_back(estilo("REACOES RAPIDAS (use /nome ou escreva :nome: no meio da mensagem)", "1;36"));
        for (int i = 0; i < NUM_REACOES; ++i)
            painel.push_back(string("  /") + pad(REACOES[i].cmd, 7) + REACOES[i].texto);
    }

    void mostrarHistorico() {
        painel.clear();
        painel.push_back(estilo("HISTORICO DO CHAT (ultimas mensagens)", "1;36"));
        size_t n = chat.size();
        size_t ini = n > 14 ? n - 14 : 0;
        if (n == 0) painel.push_back("  (nenhuma mensagem ainda)");
        for (size_t i = ini; i < n; ++i) painel.push_back(" " + chat[i]);
    }

    void mostrarConfig() {
        painel.clear();
        painel.push_back(estilo("CONFIGURACAO DA SALA " + salaCod + (souDono() ? " (voce pode mudar)" : " (so o dono muda)"), "1;36"));
        painel.push_back("  /max N                      jogadores: " + itos(salaMax));
        painel.push_back("  /cat X                      categoria: " + (salaCat.empty() ? string("Aleatoria") : salaCat));
        painel.push_back("  /dif facil|medio|dificil    " + nomeNivel(salaDif));
        painel.push_back("  /tempo N|off                " + textoTempo());
        painel.push_back("  /partida livre|melhor N|pontos N   " + textoPartidaCli());
        painel.push_back(string("  /equipes on|off             ") + (salaEquipes ? "equipes ligadas (2x2 ou 3x3)" : "cada um por si"));
        painel.push_back("  /modo sorteada|mestre       " + textoModoPalavra());
        painel.push_back(string("  /publica | /privada         ") + (salaPub ? "sala publica" : "sala privada"));
    }

    int parseNivel(const string& arg) {
        string a = paraMinusculas(arg);
        if (a == "facil" || a == "1") return 1;
        if (a == "medio" || a == "2") return 2;
        if (a == "dificil" || a == "3") return 3;
        if (a == "todas" || a == "todos" || a == "0" || a == "qualquer") return 0;
        return -1;
    }

    void tratarComando(const string& linha) {
        string cmd = linha, arg;
        size_t esp = linha.find(' ');
        if (esp != string::npos) { cmd = linha.substr(0, esp); arg = aparar(linha.substr(esp + 1)); }
        cmd = paraMinusculas(cmd);
        string nome = cmd.size() > 1 ? cmd.substr(1) : string("");
        bool naSala = (tela == T_LOBBY || tela == T_JOGO);

        if (cmd == "/som")       { cfg.som = !cfg.som;   aviso = string("Som ") + (cfg.som ? "ligado" : "desligado"); tocarSom(SOM_ACERTO); }
        else if (cmd == "/anim") { cfg.anim = !cfg.anim; aviso = string("Animacoes ") + (cfg.anim ? "ligadas" : "desligadas"); }
        else if (cmd == "/cor")  { cfg.cor = !cfg.cor;   aviso = string("Cores ") + (cfg.cor ? "ligadas" : "desligadas"); }
        else if (cmd == "/acentos") { cfg.acentos = !cfg.acentos; aviso = string("Acentos nas palavras ") + (cfg.acentos ? "ligados" : "desligados (se aparecerem simbolos estranhos, deixe desligado)"); }
        else if (cmd == "/ajuda" || cmd == "/help" || cmd == "/?") mostrarAjuda();
        else if (cmd == "/ranking") enviarLinha("RANKING");
        else if (cmd == "/reacoes") mostrarReacoes();
        else if (cmd == "/historico") mostrarHistorico();
        else if (cmd == "/chatlinhas") {
            int n = atoi(arg.c_str());
            if (arg.empty() || n < 0 || n > 15) aviso = "Use /chatlinhas N (de 0 a 15). Hoje: " + itos(cfg.chatLinhas);
            else { cfg.chatLinhas = n; aviso = "Linhas de chat na tela: " + itos(n); }
        }
        else if (!naSala) aviso = "Comando desconhecido ou disponivel so dentro de uma sala. Digite /ajuda.";
        else if (acharReacao(nome)) enviarLinha(string("CHAT|") + acharReacao(nome));
        else if (cmd == "/sair") enviarLinha("LEAVE");
        else if (cmd == "/iniciar") enviarLinha("START");
        else if (cmd == "/config") mostrarConfig();
        else if (cmd == "/cat") {
            if (arg.empty()) {
                painelCategorias();
                painel.push_back("  Use /cat NUMERO (ou nome) para escolher.");
            } else {
                bool ok;
                string c = resolverCategoria(arg, ok);
                if (!ok) aviso = "Categoria invalida. Use /cat para ver a lista.";
                else enviarLinha("CONFIG|cat|" + c);
            }
        }
        else if (cmd == "/max") enviarLinha("CONFIG|max|" + arg);
        else if (cmd == "/tempo") {
            string a = paraMinusculas(arg);
            if (a == "off" || a == "sem" || a == "nao") a = "0";
            if (a.empty()) aviso = "Use /tempo N (10 a 120 segundos) ou /tempo off.";
            else enviarLinha("CONFIG|tempo|" + a);
        }
        else if (cmd == "/dif") {
            int n = parseNivel(arg);
            if (n < 0) aviso = "Use /dif facil, medio, dificil ou todas.";
            else enviarLinha("CONFIG|dif|" + itos(n));
        }
        else if (cmd == "/partida") {
            vector<string> t;
            istringstream in(paraMinusculas(arg));
            string w;
            while (in >> w) t.push_back(w);
            if (!t.empty() && (t[0] == "livre" || t[0] == "off")) enviarLinha("CONFIG|partida|livre");
            else if (t.size() >= 2 && (t[0] == "melhor" || t[0] == "pontos")) enviarLinha("CONFIG|partida|" + t[0] + ":" + t[1]);
            else aviso = "Use /partida livre, /partida melhor 5 ou /partida pontos 50.";
        }
        else if (cmd == "/equipes") {
            string a = paraMinusculas(arg);
            if (a == "on" || a == "sim" || a == "1") enviarLinha("CONFIG|equipes|1");
            else if (a == "off" || a == "nao" || a == "0") enviarLinha("CONFIG|equipes|0");
            else aviso = "Use /equipes on ou /equipes off.";
        }
        else if (cmd == "/modo") {
            string a = paraMinusculas(arg);
            if (a == "mestre" || a == "jogador" || a == "palavra" || a == "1") enviarLinha("CONFIG|modo|1");
            else if (a == "sorteada" || a == "sorteio" || a == "normal" || a == "0") enviarLinha("CONFIG|modo|0");
            else aviso = "Use /modo sorteada ou /modo mestre.";
        }
        else if (cmd == "/publica") enviarLinha("CONFIG|pub|1");
        else if (cmd == "/privada") enviarLinha("CONFIG|pub|0");
        else if (cmd == "/time") {
            string a = paraMinusculas(arg);
            if (a == "a") enviarLinha("TEAM|0");
            else if (a == "b") enviarLinha("TEAM|1");
            else aviso = "Use /time A ou /time B.";
        }
        else if (cmd == "/assistir") enviarLinha("SPEC|1");
        else if (cmd == "/jogar") enviarLinha("SPEC|0");
        else if (cmd == "/expulsar" || cmd == "/kick") {
            if (arg.empty()) aviso = "Use /expulsar nome.";
            else enviarLinha("KICK|" + arg);
        }
        else if (cmd == "/dono") {
            if (arg.empty()) aviso = "Use /dono nome (passa o comando da sala).";
            else enviarLinha("HOST|" + arg);
        }
        else if (cmd == "/c" || cmd == "/chat") { if (!arg.empty()) enviarLinha("CHAT|" + expandirReacoes(arg)); }
        else aviso = "Comando desconhecido. Digite /ajuda.";
    }

    void tratarEntrada(string linha) {
        bool secreta = g_teclado.oculto;
        linha = sanitizarTexto(linha, 200);
        painel.clear();
        aviso.clear();

        if (!linha.empty() && linha[0] == '/') { tratarComando(linha); precisaRender = true; return; }

        if (tela == T_LOGIN) {
            string nome = sanitizarNome(linha);
            if (nome.empty()) { aviso = "Digite um nome."; }
            else enviarLinha("HELLO|" + nome + "|" + itos(VERSAO_PROTOCOLO));
        }
        else if (tela == T_MENU) tratarMenu(linha);
        else if (tela == T_LOBBY) { if (!linha.empty()) enviarLinha("CHAT|" + expandirReacoes(linha)); }
        else if (tela == T_JOGO) tratarJogada(linha, secreta);
        precisaRender = true;
    }

    void tratarJogada(const string& linha, bool secreta) {
        if (linha.empty()) return;
        if (secreta && souMestre()) {
            string base = normalizarPalavra(linha);
            if (base.size() < 3 || base.size() > 20) { aviso = "A palavra precisa ter de 3 a 20 letras."; return; }
            enviarLinha("SETWORD|" + linha);
            return;
        }
        if (!minhaVez()) { enviarLinha("CHAT|" + expandirReacoes(linha)); return; }

        if (glifosUtf8(linha).size() == 1) {   // uma letra (aceita 'ã', 'é'... como a letra base)
            string baseL = normalizarPalavra(linha);
            if (baseL.size() != 1) { aviso = "Digite somente uma letra."; return; }
            char l = baseL[0];
            if (contem(usadas, l)) { aviso = string("A letra '") + l + "' ja foi usada. Escolha outra."; return; }
            enviarLinha(string("LETTER|") + l);
        } else {
            string palpite = normalizarPalavra(linha);
            if (palpite.empty()) { aviso = "Digite uma letra ou a palavra inteira (para falar no chat use /c texto)."; return; }
            if (static_cast<int>(palpite.size()) != comprimento) {
                aviso = "A palavra tem " + itos(comprimento) + " letras (voce digitou " + itos(static_cast<long>(palpite.size())) +
                        "). Nada foi descontado. Para falar no chat use /c texto.";
                return;
            }
            enviarLinha("WORD|" + palpite);
        }
    }

    void tratarMenu(const string& linha) {
        switch (passo) {
            case P_NENHUM:
                if (linha == "1") {
                    passo = P_CR_MAX;
                } else if (linha == "2") {
                    passo = P_JOIN;
                } else if (linha == "3") {
                    enviarLinha("LIST");
                } else if (linha == "4") {
                    enviarLinha("RANKING");
                } else if (linha == "5") {
                    sair = true;
                } else if (!linha.empty()) {
                    aviso = "Opcao invalida. Digite 1, 2, 3, 4 ou 5.";
                }
                break;
            case P_CR_MAX: {
                int v = linha.empty() ? PADRAO_JOGADORES : atoi(linha.c_str());
                if (v < MIN_JOGADORES || v > MAX_JOGADORES) {
                    aviso = "Digite um numero de 2 a 6.";
                } else {
                    crMax = v;
                    passo = P_CR_CAT;
                    painelCategorias();
                }
                break;
            }
            case P_CR_CAT: {
                bool ok;
                string c = resolverCategoria(linha, ok);
                if (!ok) { aviso = "Categoria invalida. Digite o numero da lista."; painelCategorias(); }
                else { crCat = c; passo = P_CR_PUB; }
                break;
            }
            case P_CR_PUB: {
                string t = paraMinusculas(linha);
                bool pub = !(t == "n" || t == "nao");
                enviarLinha("CREATE|" + itos(crMax) + "|" + crCat + "|" + (pub ? "1" : "0"));
                passo = P_NENHUM;
                break;
            }
            case P_JOIN:
                if (!linha.empty()) {
                    string cod = linha;
                    bool assistir = false;
                    if (!cod.empty() && cod[cod.size() - 1] == '*') { assistir = true; cod.erase(cod.size() - 1); }
                    enviarLinha("JOIN|" + paraMaiusculas(aparar(cod)) + (assistir ? "|1" : ""));
                }
                passo = P_NENHUM;
                break;
            default:
                break;
        }
    }

};

// ============================================================================
//  MENU PRINCIPAL
// ============================================================================

static void esperarEnter() {
    string x;
    lerLinhaSimples("\nPressione Enter para continuar...", x);
}

static void animarLogo(const string& subtitulo) {
    limparTelaTotal();
    string q = estilo(linhaDupla(), "36") + "\n\n";
    if (cfg.anim && g_ansi) {
        cout << q;
        for (int i = 0; i < LOGO_LINHAS; ++i) {
            cout << "      " << estilo(LOGO[i], "1;33") << "\n" << flush;
            dormir(55);
        }
        cout << "\n";
    } else {
        for (int i = 0; i < LOGO_LINHAS; ++i) q += "      " + estilo(LOGO[i], "1;33") + "\n";
        q += "\n";
        cout << q;
    }
    cout << centralizar(subtitulo, LARGURA) << "\n\n";
}

static void telaComoJogar() {
    limparTelaTotal();
    cout << estilo(linhaDupla(), "36") << "\n";
    cout << estilo(" COMO JOGAR", "1;37") << "\n";
    cout << estilo(linhaDupla(), "36") << "\n\n";
    cout << " 1. Uma pessoa escolhe 'Hospedar' (vira o servidor e tambem joga). As outras\n"
         << "    escolhem 'Conectar' e digitam o IP dela (mesma rede ou VPN, porta TCP " << g_porta << ").\n"
         << " 2. Crie uma sala (codigo de 4 letras) ou entre com o codigo. Sala cheia ou em\n"
         << "    jogo? Voce entra como ESPECTADOR e vira jogador na proxima rodada.\n"
         << " 3. O dono digita /iniciar. Com /config ele muda: tempo por jogada, dificuldade,\n"
         << "    partida (melhor de N ou primeiro a X pontos), equipes 2x2/3x3 e o modo\n"
         << "    'mestre' (um jogador escolhe a palavra secreta e os outros adivinham).\n"
         << " 4. Na sua vez digite UMA letra ou a PALAVRA INTEIRA (vale a qualquer momento):\n"
         << "      letra certa +3 (+5 na fase final)    letra errada -1 e +1 erro\n"
         << "      palavra certa +5 (+2 por letra diferente que faltava alem de 2)\n"
         << "      palavra errada -3 e +2 erros (na fase final: -1 e +1 erro)\n"
         << "    Com 8 erros voce e eliminado. Se estourar o tempo, perde a vez.\n"
         << " 5. Fora da sua vez, tudo que voce digita vai para o chat. Use /gg /boa /rs ...\n"
         << " 6. Caiu da internet? Volte ao jogo e escolha 'Reconectar': a vaga e os pontos\n"
         << "    ficam guardados por 2 minutos.\n"
         << " 7. Os pontos de cada rodada entram no RANKING global do servidor.\n\n"
         << " Digite /ajuda dentro da sala para ver todos os comandos.\n";
    esperarEnter();
}

static void telaOpcoes() {
    while (!g_eof) {
        limparTelaTotal();
        cout << estilo(linhaDupla(), "36") << "\n" << estilo(" OPCOES", "1;37") << "\n"
             << estilo(linhaDupla(), "36") << "\n\n";
        cout << " 1 - Som:        " << (cfg.som ? "LIGADO" : "desligado") << "\n";
        cout << " 2 - Animacoes:  " << (cfg.anim ? "LIGADAS" : "desligadas") << "\n";
        cout << " 3 - Cores:      " << (cfg.cor ? "LIGADAS" : "desligadas") << "\n";
        cout << " 4 - Acentos:    " << (cfg.acentos ? "LIGADOS" : "desligados") << "  (palavras como 'coracao' com cedilha/til)\n";
        cout << " 0 - Voltar\n\n";
        if (!g_ansi) cout << " (este terminal nao aceita cores/ANSI: as cores e os acentos ficam desativados)\n\n";
        string op;
        if (!lerLinhaSimples("Escolha: ", op)) return;
        if (op == "1") { cfg.som = !cfg.som; tocarSom(SOM_ACERTO); }
        else if (op == "2") cfg.anim = !cfg.anim;
        else if (op == "3") cfg.cor = !cfg.cor;
        else if (op == "4") cfg.acentos = !cfg.acentos;
        else if (op == "0" || op.empty()) return;
    }
}

static void hospedarEJogar() {
    Servidor srv;
    string erro;
    if (!srv.iniciar(g_porta, false, erro)) {
        cout << "\n" << estilo(erro, "1;31") << "\n";
        esperarEnter();
        return;
    }
    Cliente c;
    if (!c.conectar("127.0.0.1", erro)) {
        cout << "\n" << estilo(erro, "1;31") << "\n";
        esperarEnter();
        return;
    }
    c.executar(&srv, listarIPsLocais());
}

static void conectarEmServidor() {
    limparTelaTotal();
    cout << estilo(linhaDupla(), "36") << "\n" << estilo(" CONECTAR A UM SERVIDOR", "1;37") << "\n"
         << estilo(linhaDupla(), "36") << "\n\n";
    string ip;
    if (!lerLinhaSimples("IP do servidor (ex.: 192.168.0.10) [127.0.0.1]: ", ip)) return;
    ip = aparar(ip);
    if (ip.empty()) ip = "127.0.0.1";
    cout << "\nConectando a " << ip << ":" << g_porta << "...\n" << flush;

    Cliente c;
    string erro;
    if (!c.conectar(ip, erro)) {
        cout << "\n" << estilo(erro, "1;31") << "\n";
        esperarEnter();
        return;
    }
    c.executar(NULL, "");
}

static void reconectarUltimaSala(const SessaoSalva& ss) {
    cout << "\nReconectando a " << ss.ip << ":" << ss.porta << "...\n" << flush;
    Cliente c;
    string erro;
    if (!c.retomar(ss, erro)) {
        cout << "\n" << estilo(erro, "1;31") << "\n";
        esperarEnter();
        return;
    }
    c.executar(NULL, "");
}

static void servidorDedicado() {
    Servidor srv;
    string erro;
    limparTelaTotal();
    if (!srv.iniciar(g_porta, true, erro)) {
        cout << "\n" << estilo(erro, "1;31") << "\n";
        esperarEnter();
        return;
    }
    srv.executarDedicado();
}

int main(int argc, char** argv) {
    setlocale(LC_ALL, "");
    iniciarTerminal();
    inicializarSockets();

    bool soServidor = false;
    for (int i = 1; i < argc; ++i) {
        string a = argv[i];
        if (a == "--servidor") soServidor = true;
        else if (a == "--porta" && i + 1 < argc) g_porta = atoi(argv[++i]);
        else if (a == "--sem-som") cfg.som = false;
        else if (a == "--sem-anim") cfg.anim = false;
        else if (a == "--sem-cor") cfg.cor = false;
        else if (a == "--sem-acento") cfg.acentos = false;
        else if (a == "--ajuda" || a == "-h") {
            cout << "Uso: forca [--servidor] [--porta N] [--sem-som] [--sem-anim] [--sem-cor] [--sem-acento]\n"
                 << "  --servidor   inicia somente o servidor dedicado (sem jogar)\n";
            finalizarSockets();
            return 0;
        }
    }
    if (g_porta < 1 || g_porta > 65535) g_porta = 54000;

    if (soServidor) {
        servidorDedicado();
        finalizarSockets();
        return 0;
    }

    while (!g_eof) {
        animarLogo("Jogo da Forca Multiplayer - versao 2.2");

        SessaoSalva ss;
        bool temSessao = lerSessaoArquivo(ss);

        cout << "  " << estilo("1", "1;33") << " - Hospedar (criar servidor e jogar)\n";
        cout << "  " << estilo("2", "1;33") << " - Conectar a um servidor\n";
        cout << "  " << estilo("3", "1;33") << " - Servidor dedicado (so hospeda, sem jogar)\n";
        cout << "  " << estilo("4", "1;33") << " - Opcoes (som, animacoes, cores, acentos)\n";
        cout << "  " << estilo("5", "1;33") << " - Como jogar\n";
        cout << "  " << estilo("6", "1;33") << " - Sair\n";
        if (temSessao)
            cout << "  " << estilo("7", "1;32") << " - Reconectar na sala " << ss.sala << " (" << ss.nome << " em " << ss.ip << ")\n";
        cout << "\n";

        string op;
        if (!lerLinhaSimples("Escolha: ", op)) break;
        op = aparar(op);

        if (op == "1") hospedarEJogar();
        else if (op == "2") conectarEmServidor();
        else if (op == "3") servidorDedicado();
        else if (op == "4") telaOpcoes();
        else if (op == "5") telaComoJogar();
        else if (op == "6") break;
        else if (op == "7" && temSessao) reconectarUltimaSala(ss);
    }

    cout << "\n" << flush;
    finalizarSockets();
    return 0;
}
