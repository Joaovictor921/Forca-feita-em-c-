@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Jogo da Forca Multiplayer

if /i "%~1"=="recompilar" del forca.exe >nul 2>nul
if exist forca.exe goto abrir

echo Primeira execucao: preparando o jogo...
call :achar_gpp
if not defined GPP (
  echo Compilador g++ nao encontrado. Tentando instalar o MinGW automaticamente...
  where winget >nul 2>nul
  if not errorlevel 1 (
    winget install -e --id BrechtSanders.WinLibs.POSIX.UCRT --accept-source-agreements --accept-package-agreements
    call :achar_gpp
  )
)
if not defined GPP (
  echo.
  echo Nao foi possivel achar nem instalar o compilador automaticamente.
  echo Instale o Dev-C++ 5.11 ^(ou o MinGW-w64^) e execute este arquivo de novo.
  pause
  exit /b 1
)

echo Usando o compilador: !GPP!
for %%I in ("!GPP!") do set "PATH=%%~dpI;%PATH%"
echo Compilando ^(o .exe fica independente, sem precisar de DLLs^)...
"!GPP!" jogo_forca_multiplayer.cpp -std=c++11 -O2 -static -static-libgcc -static-libstdc++ -pthread -o forca.exe -lws2_32
if errorlevel 1 (
  echo.
  echo Erro ao compilar. Veja as mensagens acima.
  pause
  exit /b 1
)
echo Pronto!

:abrir
mode con: cols=100 lines=38 >nul 2>nul
forca.exe
exit /b 0

:achar_gpp
set "GPP="
for /f "delims=" %%G in ('where g++ 2^>nul') do if not defined GPP set "GPP=%%G"
if defined GPP exit /b 0
for %%D in ("C:\Dev-Cpp\MinGW64\bin" "C:\Program Files (x86)\Dev-Cpp\MinGW64\bin" "C:\Program Files\Dev-Cpp\MinGW64\bin" "C:\Dev-Cpp\MinGW32\bin" "C:\MinGW\bin" "C:\msys64\ucrt64\bin" "C:\msys64\mingw64\bin" "C:\mingw64\bin") do (
  if not defined GPP if exist "%%~D\g++.exe" set "GPP=%%~D\g++.exe"
)
if defined GPP exit /b 0
for /d %%P in ("%LOCALAPPDATA%\Microsoft\WinGet\Packages\BrechtSanders.WinLibs*") do (
  if not defined GPP if exist "%%P\mingw64\bin\g++.exe" set "GPP=%%P\mingw64\bin\g++.exe"
)
exit /b 0
