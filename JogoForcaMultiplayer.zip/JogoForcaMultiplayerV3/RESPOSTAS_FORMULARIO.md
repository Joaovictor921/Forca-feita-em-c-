# Trabalho 02 – Respostas para o formulário

**Nome do jogo:** Jogo da Forca Multiplayer (v3.0)

**Linguagem:** C++ (C++11) com Winsock2 (`winsock2.h`) e `pthread.h`. Também compila no Linux/macOS.

## Explicação sobre o jogo
Forca online para 2 a 6 jogadores por sala (mais espectadores). Cada jogador roda o jogo em seu próprio
processo e se conecta por socket TCP a um servidor (um dos jogadores "hospeda" e também joga). Os jogadores
se revezam: na sua vez, digita-se uma letra ou a palavra inteira. Letra certa dá pontos, letra errada tira
pontos e conta erro; com 8 erros o jogador é eliminado. Há salas com código, tempo por jogada, partidas em
rodadas, equipes, modo "mestre" (um jogador escolhe a palavra), chat, ranking e reconexão.

## Como e quais informações são trocadas entre os processos?
Troca de mensagens de texto, uma por linha, campos separados por `|`, sobre sockets TCP.
O primeiro campo é o **código da mensagem**.

Cliente → Servidor (ações do jogador):
`HELLO|nome|versao`, `CREATE|max|cat|pub`, `JOIN|codigo`, `START`, `LETTER|x`, `WORD|palavra`,
`CHAT|texto`, `CONFIG|chave|valor`, `LEAVE`, ...

Servidor → Clientes (estado do jogo, enviado a todos da sala):
`STATE|cod|cat|mascara|usadas|certas|turno|restantes|faseFinal|...` + linhas `P|slot|nome|erros|pontos|status|...`,
`EVENT|tipo|slot|letra|texto`, `ERROR|texto`, `SYS|texto`, `ROSTER|...`

**Controle da vez:** o campo `turno` da mensagem `STATE` é o índice do jogador da vez (equivalente à variável
"vez" do enunciado). A variável existe nos dois lados: o servidor guarda `Sala::turno` e cada cliente guarda
`Cliente::turno`, atualizada a cada `STATE` recebido. O cliente só habilita a jogada quando `turno == meu slot`
e o servidor revalida: jogada fora da vez recebe `ERROR|Nao e a sua vez.` e não altera nada.

Exemplo: jogador 2 envia `LETTER|a` → servidor valida a vez, atualiza máscara/pontos/turno e envia
`EVENT|letra_certa|2|a|...` e `STATE|...|turno=3|...` para todos.

## Como é feito o gerenciamento da exclusão mútua?
- **Memória compartilhada:** todo o estado do jogo (conexões, salas, jogadores, `turno`, palavra, letras usadas,
  pontos e ranking) fica em uma única área de memória do processo servidor, compartilhada entre suas threads.
- **Threads (`pthread_create`):** 1 thread por jogador conectado (recebe e processa as mensagens dele),
  1 thread de aceite de conexões e 1 thread de relógio (tempo por jogada, ping, quedas de conexão).
- **Exclusão mútua:** um `pthread_mutex_t` protege o estado compartilhado. Toda leitura/alteração acontece na
  região crítica (`Trava`, uma classe RAII que faz `pthread_mutex_lock` no construtor e `pthread_mutex_unlock`
  no destrutor). O mutex é solto durante a espera de rede (`select`), então só o processamento rápido da
  mensagem é serializado. Com isso, duas jogadas simultâneas nunca corrompem a vez, os pontos ou as salas.
- **Encerramento:** as threads são finalizadas com `pthread_join` antes de liberar a memória; uma conexão só é
  apagada depois que sua thread terminou.
- Testado com ThreadSanitizer (0 corridas de dados) e com 6 clientes disparando jogadas ao mesmo tempo.

## Uploads
- Código sem executável: `JogoForcaMultiplayerV3_codigo.zip`
- Código com executável: `JogoForcaMultiplayerV3_com_exe.zip`
- Link do gameplay (1 min): gravar e colocar aqui.
